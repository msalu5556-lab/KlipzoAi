import 'dotenv/config';
import express from 'express';
import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import {
  CATEGORY_PROFILES,
  generateSrtContent,
  resolveLayoutForCategory,
  type AspectRatio,
  type CaptionCue,
  type CaptionStyleId,
  type ClipDurationPreset,
  type ClipLayoutMode,
  type ConcreteCategoryId,
  type DetectedWebcamPosition,
  type LayoutPreference,
  type NormalizedClip,
  type VideoCategoryId,
  type WebcamPosition,
} from './src/lib/clipEngine.ts';
import {
  CLIPS_DIR,
  ensureMediaDirs,
  generateSampleVideo,
  probeVideo,
  renderClipMp4,
  UPLOADS_DIR,
  type SampleKind,
  type VideoProbeInfo,
} from './src/server/ffmpegTools.ts';
import {
  analyzeVideoWithGemini,
  GeminiConfigError,
} from './src/server/geminiAnalyzer.ts';
import {
  analyzeVideoLocal,
  downloadSegment,
  downloadYouTubeMetadata,
  getLocalEngineStatus,
  LocalEngineError,
} from './src/server/localAnalyzer.ts';
import {
  ingestYouTubeUrl,
  type YouTubeTranscriptCue,
} from './src/server/youtubeIngestor.ts';
import { WORK_ROOT } from './src/server/ffmpegTools.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface StoredVideo {
  videoId: string;
  filePath: string;
  filename: string;
  originalName: string;
  mimeType: string;
  probe: VideoProbeInfo;
  isSample: boolean;
  sourceType: 'upload' | 'sample' | 'youtube';
  isLive?: boolean;
  thumbnailUrl?: string;
  youtubeUrl?: string;
  youtubeChannel?: string;
  streamAvailable?: boolean;
  streamWarning?: string;
  usedYouTubeDataApi?: boolean;
  youtubeContext?: {
    title: string;
    channelTitle?: string;
    description?: string;
    heatmapPeaks?: number[];
    transcriptSegments?: YouTubeTranscriptCue[];
  };
}

interface StoredClip {
  clip: NormalizedClip;
  videoId: string;
  outputPath: string;
  outputFilename: string;
}

interface AnalyzeJobResult {
  primaryCategory: ConcreteCategoryId;
  primaryCategoryLabel: string;
  secondaryCategories: ConcreteCategoryId[];
  categoryConfidence: number;
  categoryReasoning: string;
  contentSummary: string;
  detectedWebcamPosition: DetectedWebcamPosition;
  streamWarning?: string;
  clips: NormalizedClip[];
}

interface AnalyzeJob {
  jobId: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  stage: string;
  progress: number;
  result?: AnalyzeJobResult;
  error?: string;
  errorCode?: string;
}

interface ChunkUploadSession {
  uploadId: string;
  originalName: string;
  mimeType: string;
  totalChunks: number;
  tempDir: string;
}

interface UploadCompleteJob {
  jobId: string;
  kind: 'upload';
  status: 'queued' | 'running' | 'completed' | 'failed';
  stage: string;
  progress: number;
  video?: {
    videoId: string;
    filename: string;
    originalName: string;
    mimeType: string;
    previewUrl: string;
    probe: VideoProbeInfo;
    isSample: boolean;
    sourceType: 'upload' | 'sample' | 'youtube';
  };
  error?: string;
}

const videoRegistry = new Map<string, StoredVideo>();
const clipRegistry = new Map<string, StoredClip>();
const jobRegistry = new Map<string, AnalyzeJob | UploadCompleteJob>();
const chunkSessions = new Map<string, ChunkUploadSession>();

function sanitizeExtension(originalName: string, mimeType: string): string {
  const ext = path.extname(originalName).toLowerCase();
  if (['.mp4', '.mov', '.webm', '.mkv', '.m4v'].includes(ext)) return ext;
  if (mimeType.includes('webm')) return '.webm';
  if (mimeType.includes('quicktime')) return '.mov';
  return '.mp4';
}

async function executeAnalyzeAndRender(
  video: StoredVideo,
  options: {
    autoDetectCategory: boolean;
    selectedCategory: VideoCategoryId;
    autoDetectBestClips: boolean;
    numberOfClips: number;
    durationPreset: ClipDurationPreset;
    aspectRatio: AspectRatio;
    captionLanguage: string;
    captionStyle: CaptionStyleId;
    layoutPreference: LayoutPreference;
    webcamPreference: WebcamPosition;
    /** 'local' (default, no keys needed) or 'gemini' (opt-in, needs a key). */
    engine?: 'local' | 'gemini';
    /** Unique tag for the local engine's job work dir. */
    jobTag: string;
  },
  onProgress?: (stage: string, progress: number) => void
): Promise<AnalyzeJobResult> {
  const safeClipCount = Math.max(1, Math.min(10, Number(options.numberOfClips) || 4));

  // Engine choice: the local engine is the DEFAULT — it needs no API keys and
  // mirrors the proven yt-dlp + faster-whisper pipeline. Gemini is opt-in
  // (KLIPZ_USE_GEMINI=1 or engine: 'gemini') and only enhances classification.
  const useGemini = options.engine === 'gemini';
  const analysis = useGemini
    ? await analyzeVideoWithGemini({
        videoPath: video.filePath,
        mimeType: video.mimeType,
        videoDuration: video.probe.duration,
        sizeBytes: video.probe.sizeBytes,
        hasAudio: video.probe.hasAudio,
        autoDetectCategory: Boolean(options.autoDetectCategory),
        selectedCategory: options.selectedCategory,
        autoDetectBestClips: Boolean(options.autoDetectBestClips),
        numberOfClips: safeClipCount,
        durationPreset: options.durationPreset,
        aspectRatio: options.aspectRatio,
        captionLanguage: options.captionLanguage,
        captionStyle: options.captionStyle,
        layoutPreference: options.layoutPreference,
        webcamPreference: options.webcamPreference,
        youtubeContext: video.youtubeContext,
        onProgress,
      })
    : await analyzeVideoLocal({
        videoPath: video.filePath,
        isYouTube: video.sourceType === 'youtube',
        videoDuration: video.probe.duration,
        hasAudio: video.probe.hasAudio,
        selectedCategory: options.selectedCategory,
        numberOfClips: safeClipCount,
        durationPreset: options.durationPreset,
        aspectRatio: options.aspectRatio,
        captionLanguage: options.captionLanguage,
        captionStyle: options.captionStyle,
        layoutPreference: options.layoutPreference,
        webcamPreference: options.webcamPreference,
        jobTag: options.jobTag,
        onProgress,
      });

  const renderedClips: NormalizedClip[] = [];
  const total = Math.max(1, analysis.clips.length);
  let renderWarning = video.streamWarning;

  for (let i = 0; i < analysis.clips.length; i++) {
    const clip = analysis.clips[i];
    const uniqueId = `${video.videoId}_${clip.id}_${Date.now()}`;
    const outputFilename = `${uniqueId}.mp4`;
    const outputPath = path.join(CLIPS_DIR, outputFilename);

    // The local engine already rendered this clip (1080x1920, title banner,
    // karaoke captions) — serve its file directly instead of re-rendering.
    const preRendered = Boolean(clip.outputFilename && clip.outputPath);
    const finalFilename = preRendered ? clip.outputFilename! : outputFilename;
    const finalPath = preRendered ? clip.outputPath! : outputPath;

    let canRenderMp4 = preRendered || Boolean(video.filePath);
    if (!preRendered && canRenderMp4) {
      onProgress?.(
        `Rendering clip ${i + 1} of ${total}: "${clip.title}"...`,
        Math.min(98, 76 + Math.round(((i + 0.5) / total) * 22))
      );

      try {
        await renderClipMp4({
          sourcePath: video.filePath,
          outputPath,
          clipId: uniqueId,
          startTime: clip.startTime,
          endTime: clip.endTime,
          aspectRatio: clip.aspectRatio,
          layoutMode: clip.layoutMode,
          webcamPosition: clip.webcamPosition,
          captionStyle: clip.captionStyle,
          captions: clip.captions,
          title: clip.title,
          wordCues: clip.wordCues,
          hasAudio: video.probe.hasAudio,
        });
      } catch (err) {
        if (video.sourceType === 'youtube') {
          canRenderMp4 = false;
          renderWarning =
            err instanceof Error
              ? `YouTube stream restricted server MP4 rendering (${err.message.slice(0, 120)}). Highlight timestamps, AI scores, and SRT captions are ready.`
              : 'YouTube stream restricted server MP4 rendering.';
        } else {
          throw err;
        }
      }
    }

    const storedClip: NormalizedClip = {
      ...clip,
      id: uniqueId,
      renderUrl: canRenderMp4 ? `/api/media/clips/${encodeURIComponent(finalFilename)}` : undefined,
      srtUrl: `/api/clips/${encodeURIComponent(uniqueId)}/srt`,
      renderedAt: new Date().toISOString(),
    };

    clipRegistry.set(uniqueId, {
      clip: storedClip,
      videoId: video.videoId,
      outputPath: canRenderMp4 ? finalPath : '',
      outputFilename: canRenderMp4 ? finalFilename : '',
    });

    renderedClips.push(storedClip);
  }

  return {
    primaryCategory: analysis.primaryCategory,
    primaryCategoryLabel: CATEGORY_PROFILES[analysis.primaryCategory].label,
    secondaryCategories: analysis.secondaryCategories,
    categoryConfidence: analysis.categoryConfidence,
    categoryReasoning: analysis.categoryReasoning,
    contentSummary: analysis.contentSummary,
    detectedWebcamPosition: analysis.detectedWebcamPosition,
    streamWarning: renderWarning,
    clips: renderedClips,
  };
}

async function assembleAndProbeVideo(
  session: ChunkUploadSession,
  onProgress?: (stage: string, progress: number) => void
) {
  const videoId = `vid_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const ext = sanitizeExtension(session.originalName, session.mimeType);
  const filename = `${videoId}${ext}`;
  const finalPath = path.join(UPLOADS_DIR, filename);

  onProgress?.(`Assembling ${session.originalName}...`, 20);

  await new Promise<void>((resolve, reject) => {
    const ws = createWriteStream(finalPath);
    ws.on('error', reject);
    ws.on('finish', resolve);
    (async () => {
      try {
        for (let i = 0; i < session.totalChunks; i++) {
          const partPath = path.join(session.tempDir, `part_${i}`);
          const buf = await fs.readFile(partPath);
          if (!ws.write(buf)) {
            await new Promise<void>((r) => ws.once('drain', r));
          }
          await fs.unlink(partPath).catch(() => undefined);
          if (i % 15 === 0) {
            const pct = 20 + Math.round(((i + 1) / session.totalChunks) * 55);
            onProgress?.(
              `Assembling ${session.originalName} (${i + 1}/${session.totalChunks} parts)...`,
              pct
            );
          }
        }
        ws.end();
      } catch (err) {
        ws.destroy();
        reject(err);
      }
    })();
  });

  await fs.rm(session.tempDir, { recursive: true, force: true }).catch(() => undefined);
  chunkSessions.delete(session.uploadId);

  onProgress?.('Inspecting video resolution, duration, and audio track...', 85);
  const probe = await probeVideo(finalPath);
  if (probe.duration <= 0) {
    await fs.unlink(finalPath).catch(() => undefined);
    throw new Error('Could not read video duration. Ensure the file is a valid video.');
  }

  const entry: StoredVideo = {
    videoId,
    filePath: finalPath,
    filename,
    originalName: session.originalName,
    mimeType: session.mimeType || 'video/mp4',
    probe,
    isSample: false,
    sourceType: 'upload',
    streamAvailable: true,
  };
  videoRegistry.set(videoId, entry);

  return {
    videoId: entry.videoId,
    filename: entry.filename,
    originalName: entry.originalName,
    mimeType: entry.mimeType,
    previewUrl: `/api/media/uploads/${encodeURIComponent(entry.filename)}`,
    probe: entry.probe,
    isSample: false,
    sourceType: 'upload' as const,
  };
}

async function startServer(): Promise<void> {
  await ensureMediaDirs();

  const app = express();
  app.use(express.json({ limit: '10mb' }));

  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => {
      cb(null, UPLOADS_DIR);
    },
    filename: (_req, file, cb) => {
      const id = `vid_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const ext = sanitizeExtension(file.originalname, file.mimetype);
      cb(null, `${id}${ext}`);
    },
  });

  const upload = multer({
    storage,
    limits: { fileSize: 12 * 1024 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      if (
        file.mimetype.startsWith('video/') ||
        /\.(mp4|mov|webm|mkv|m4v)$/i.test(file.originalname)
      ) {
        cb(null, true);
      } else {
        cb(new Error('Unsupported file format. Please upload an MP4, MOV, WebM, or MKV video.'));
      }
    },
  });

  const chunkUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 20 * 1024 * 1024 },
  });

  app.get('/api/health', async (_req, res) => {
    const localEngine = await getLocalEngineStatus();
    res.json({
      status: 'ok',
      engine: process.env.KLIPZ_USE_GEMINI === '1' ? 'gemini' : 'local',
      localEngine,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim()),
      youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
    });
  });

  app.post('/api/videos/upload/init', async (req, res) => {
    try {
      const { filename, mimeType = 'video/mp4', totalChunks } = req.body as {
        filename?: string;
        mimeType?: string;
        totalChunks?: number;
      };
      if (!filename || !totalChunks || totalChunks < 1) {
        res.status(400).json({ error: 'Invalid upload initialization parameters.' });
        return;
      }
      const uploadId = `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const tempDir = path.join(UPLOADS_DIR, `${uploadId}_chunks`);
      await fs.mkdir(tempDir, { recursive: true });
      chunkSessions.set(uploadId, {
        uploadId,
        originalName: filename,
        mimeType,
        totalChunks,
        tempDir,
      });
      res.json({ uploadId });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to initialize upload.';
      res.status(500).json({ error: message });
    }
  });

  app.post(
    '/api/videos/upload/chunk-raw',
    express.raw({ type: 'application/octet-stream', limit: '6mb' }),
    async (req, res) => {
      try {
        const uploadId = String(req.query?.uploadId || '');
        const chunkIndex = Number(req.query?.chunkIndex);
        const session = chunkSessions.get(uploadId);
        const buf = req.body as Buffer;
        if (
          !session ||
          !Buffer.isBuffer(buf) ||
          buf.length === 0 ||
          !Number.isInteger(chunkIndex) ||
          chunkIndex < 0 ||
          chunkIndex >= session.totalChunks
        ) {
          res.status(400).json({ error: 'Invalid upload chunk.' });
          return;
        }
        const partPath = path.join(session.tempDir, `part_${chunkIndex}`);
        await fs.writeFile(partPath, buf);
        res.json({ ok: true, chunkIndex });
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to store video chunk.';
        res.status(500).json({ error: message });
      }
    }
  );

  app.post('/api/videos/upload/chunk', chunkUpload.single('chunk'), async (req, res) => {
    try {
      const uploadId = String(req.body?.uploadId || '');
      const chunkIndex = Number(req.body?.chunkIndex);
      const session = chunkSessions.get(uploadId);
      if (!session || !req.file || !Number.isInteger(chunkIndex) || chunkIndex < 0) {
        res.status(400).json({ error: 'Invalid upload chunk.' });
        return;
      }
      const partPath = path.join(session.tempDir, `part_${chunkIndex}`);
      await fs.writeFile(partPath, req.file.buffer);
      res.json({ ok: true, chunkIndex });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to store video chunk.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/videos/upload/complete', async (req, res) => {
    try {
      const { uploadId } = req.body as { uploadId?: string };
      const session = uploadId ? chunkSessions.get(uploadId) : undefined;
      if (!session) {
        res.status(404).json({ error: 'Upload session not found.' });
        return;
      }

      if (req.query.sync === '1') {
        const video = await assembleAndProbeVideo(session);
        res.json(video);
        return;
      }

      const jobId = `upjob_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const job: UploadCompleteJob = {
        jobId,
        kind: 'upload',
        status: 'running',
        stage: `Assembling ${session.originalName}...`,
        progress: 10,
      };
      jobRegistry.set(jobId, job);

      res.status(202).json({ jobId, status: job.status, stage: job.stage, progress: job.progress });

      assembleAndProbeVideo(session, (stage, progress) => {
        const current = jobRegistry.get(jobId) as UploadCompleteJob | undefined;
        if (current && current.status === 'running') {
          current.stage = stage;
          current.progress = progress;
        }
      })
        .then((video) => {
          const current = jobRegistry.get(jobId) as UploadCompleteJob | undefined;
          if (current) {
            current.status = 'completed';
            current.stage = 'Ready';
            current.progress = 100;
            current.video = video;
          }
        })
        .catch((err) => {
          const current = jobRegistry.get(jobId) as UploadCompleteJob | undefined;
          if (current) {
            current.status = 'failed';
            current.error = err instanceof Error ? err.message : 'Failed to finalize uploaded video.';
          }
        });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to finalize uploaded video.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/videos/upload', upload.single('video'), async (req, res) => {
    try {
      if (!req.file) {
        res.status(400).json({ error: 'No video file uploaded.' });
        return;
      }

      const probe = await probeVideo(req.file.path);
      if (probe.duration <= 0) {
        await fs.unlink(req.file.path).catch(() => undefined);
        res.status(400).json({ error: 'Could not read video duration. Ensure the file is a valid video.' });
        return;
      }

      const videoId = path.parse(req.file.filename).name;
      const entry: StoredVideo = {
        videoId,
        filePath: req.file.path,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype || 'video/mp4',
        probe,
        isSample: false,
        sourceType: 'upload',
        streamAvailable: true,
      };
      videoRegistry.set(videoId, entry);

      res.json({
        videoId: entry.videoId,
        filename: entry.filename,
        originalName: entry.originalName,
        mimeType: entry.mimeType,
        previewUrl: `/api/media/uploads/${encodeURIComponent(entry.filename)}`,
        probe: entry.probe,
        isSample: false,
        sourceType: 'upload',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to process uploaded video.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/videos/youtube', async (req, res) => {
    try {
      const { url } = req.body as { url?: string };
      if (!url || !url.trim()) {
        res.status(400).json({ error: 'Please paste a valid YouTube video or live stream URL.' });
        return;
      }
      if (url.length > 2048) {
        res.status(400).json({ error: 'That URL is too long. Please paste a plain YouTube video URL.' });
        return;
      }
      const trimmedUrl = url.trim();

      // Primary path: yt-dlp metadata (no download). The local engine downloads
      // only the needed 35s segments, so no stream URL is required up front.
      const meta = await downloadYouTubeMetadata(trimmedUrl).catch(() => null);
      if (meta) {
        const videoId = `yt_${meta.youtubeId}_${Date.now()}`;
        const entry: StoredVideo = {
          videoId,
          filePath: trimmedUrl, // the local engine passes this URL to yt-dlp
          filename: `${meta.youtubeId}.mp4`,
          originalName: meta.title,
          mimeType: 'video/mp4',
          probe: {
            duration: meta.durationSeconds,
            width: 1280,
            height: 720,
            fps: 30,
            hasAudio: true,
            codec: 'h264',
            sizeBytes: 0,
          },
          isSample: false,
          sourceType: 'youtube',
          thumbnailUrl: meta.thumbnailUrl,
          youtubeUrl: trimmedUrl,
          youtubeChannel: meta.channelTitle,
          streamAvailable: true,
          youtubeContext: {
            title: meta.title,
            channelTitle: meta.channelTitle,
            description: meta.description,
          },
        };
        videoRegistry.set(videoId, entry);
        res.json({
          videoId: entry.videoId,
          filename: entry.filename,
          originalName: entry.originalName,
          mimeType: entry.mimeType,
          previewUrl: '',
          probe: entry.probe,
          isSample: false,
          sourceType: 'youtube',
          youtubeId: meta.youtubeId,
          youtubeUrl: trimmedUrl,
          youtubeChannel: meta.channelTitle,
          thumbnailUrl: meta.thumbnailUrl,
          isLive: false,
          streamAvailable: true,
          transcriptCuesCount: 0,
          heatmapPeaksCount: 0,
        });
        return;
      }

      // Fallback path: youtubei.js (Innertube) — metadata, transcript, heatmap.
      const yt = await ingestYouTubeUrl(trimmedUrl);
      const videoId = `yt_${yt.youtubeId}_${Date.now()}`;

      const entry: StoredVideo = {
        videoId,
        filePath: yt.streamUrl || yt.canonicalUrl,
        filename: `${yt.youtubeId}.mp4`,
        originalName: yt.title,
        mimeType: 'video/mp4',
        probe: yt.probe,
        isSample: false,
        sourceType: 'youtube',
        isLive: yt.isLive,
        thumbnailUrl: yt.thumbnailUrl,
        youtubeUrl: yt.canonicalUrl,
        youtubeChannel: yt.channelTitle,
        streamAvailable: Boolean(yt.streamUrl),
        streamWarning: yt.streamWarning,
        usedYouTubeDataApi: yt.usedYouTubeDataApi,
        youtubeContext: {
          title: yt.title,
          channelTitle: yt.channelTitle,
          description: yt.description,
          heatmapPeaks: yt.heatmapPeaks,
          transcriptSegments: yt.transcriptSegments,
        },
      };

      videoRegistry.set(videoId, entry);

      res.json({
        videoId: entry.videoId,
        filename: entry.filename,
        originalName: entry.originalName,
        mimeType: entry.mimeType,
        previewUrl: '',
        probe: entry.probe,
        isSample: false,
        sourceType: 'youtube',
        youtubeId: yt.youtubeId,
        youtubeUrl: yt.canonicalUrl,
        youtubeChannel: yt.channelTitle,
        thumbnailUrl: yt.thumbnailUrl,
        isLive: yt.isLive,
        streamAvailable: Boolean(yt.streamUrl),
        streamWarning: yt.streamWarning,
        usedYouTubeDataApi: yt.usedYouTubeDataApi,
        transcriptCuesCount: yt.transcriptSegments.length,
        heatmapPeaksCount: yt.heatmapPeaks.length,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load YouTube URL.';
      const status = message.includes('Invalid YouTube') ? 400 : 500;
      res.status(status).json({ error: message });
    }
  });

  app.post('/api/videos/sample', async (req, res) => {
    try {
      const rawKind = String(req.body?.kind || 'gaming');
      const kind: SampleKind =
        rawKind === 'podcast' || rawKind === 'educational' ? rawKind : 'gaming';

      const samplePath = await generateSampleVideo(kind);
      const probe = await probeVideo(samplePath);
      const videoId = `sample_${kind}_${Date.now()}`;
      const filename = `sample_${kind}.mp4`;

      const titles: Record<SampleKind, string> = {
        gaming: 'Sample_GTA_District_Pursuit.mp4',
        podcast: 'Sample_Creator_Podcast_Ep42.mp4',
        educational: 'Sample_Attention_Curves_Explainer.mp4',
      };

      const entry: StoredVideo = {
        videoId,
        filePath: samplePath,
        filename,
        originalName: titles[kind],
        mimeType: 'video/mp4',
        probe,
        isSample: true,
        sourceType: 'sample',
        streamAvailable: true,
      };
      videoRegistry.set(videoId, entry);

      res.json({
        videoId: entry.videoId,
        filename: entry.filename,
        originalName: entry.originalName,
        mimeType: entry.mimeType,
        previewUrl: `/api/media/samples/${encodeURIComponent(entry.filename)}`,
        probe: entry.probe,
        isSample: true,
        sourceType: 'sample',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to generate sample video.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/analyze', async (req, res) => {
    try {
      const {
        videoId,
        autoDetectCategory = true,
        selectedCategory = 'auto',
        autoDetectBestClips = true,
        numberOfClips = 4,
        durationPreset = 'balanced',
        aspectRatio = '9:16',
        captionLanguage = 'English',
        captionStyle = 'clean_editorial',
        layoutPreference = 'auto',
        webcamPreference = 'auto',
        engine = 'local',
      } = req.body as {
        videoId?: string;
        autoDetectCategory?: boolean;
        selectedCategory?: VideoCategoryId;
        autoDetectBestClips?: boolean;
        numberOfClips?: number;
        durationPreset?: ClipDurationPreset;
        aspectRatio?: AspectRatio;
        captionLanguage?: string;
        captionStyle?: CaptionStyleId;
        layoutPreference?: LayoutPreference;
        webcamPreference?: WebcamPosition;
        engine?: 'local' | 'gemini';
      };

      if (!videoId || !videoRegistry.has(videoId)) {
        res.status(404).json({ error: 'Video session not found. Please upload or load a video first.' });
        return;
      }

      // Validate every enum input — unknown values are a client error, never
      // silently reinterpreted.
      const validDurationPresets: ClipDurationPreset[] = ['short', 'balanced', 'deep'];
      const validAspectRatios: AspectRatio[] = ['9:16', '16:9', '1:1', '4:5'];
      const validCaptionStyles: CaptionStyleId[] = ['clean_editorial', 'bold_kinetic', 'high_contrast_box', 'minimal_bottom', 'none'];
      const validLayouts: LayoutPreference[] = ['auto', 'full_frame', 'vertical_crop', 'speaker_focus', 'dual_speaker', 'split_cam_gameplay', 'picture_in_picture'];
      const validWebcam: WebcamPosition[] = ['auto', 'top_left', 'top_right', 'bottom_left', 'bottom_right', 'top_center', 'none'];
      const validCategories: VideoCategoryId[] = ['auto', 'gaming', 'podcast', 'interview', 'reaction', 'commentary', 'documentary', 'educational', 'storytelling', 'news', 'entertainment', 'other'];
      if (!validDurationPresets.includes(durationPreset)) {
        res.status(400).json({ error: `Invalid durationPreset "${durationPreset}". Use short, balanced, or deep.` });
        return;
      }
      if (!validAspectRatios.includes(aspectRatio)) {
        res.status(400).json({ error: `Invalid aspectRatio "${aspectRatio}". Use 9:16, 16:9, 1:1, or 4:5.` });
        return;
      }
      if (!validCaptionStyles.includes(captionStyle)) {
        res.status(400).json({ error: `Invalid captionStyle "${captionStyle}".` });
        return;
      }
      if (!validLayouts.includes(layoutPreference)) {
        res.status(400).json({ error: `Invalid layoutPreference "${layoutPreference}".` });
        return;
      }
      if (!validWebcam.includes(webcamPreference)) {
        res.status(400).json({ error: `Invalid webcamPreference "${webcamPreference}".` });
        return;
      }
      if (!validCategories.includes(selectedCategory)) {
        res.status(400).json({ error: `Invalid selectedCategory "${selectedCategory}".` });
        return;
      }
      if (engine !== 'local' && engine !== 'gemini') {
        res.status(400).json({ error: `Invalid engine "${engine}". Use local or gemini.` });
        return;
      }

      // Gemini is opt-in: only when explicitly requested (or KLIPZ_USE_GEMINI=1)
      // AND a key is configured. The local engine is the default and needs no key.
      const useGemini = engine === 'gemini' || process.env.KLIPZ_USE_GEMINI === '1';
      if (useGemini && !process.env.GEMINI_API_KEY?.trim()) {
        res.status(503).json({
          error:
            'GEMINI_API_KEY is not configured. The Gemini engine is optional — remove engine: "gemini" (or KLIPZ_USE_GEMINI=1) to use the local clipping engine, which needs no API key. To enable Gemini, add your key to .env.local.',
          code: 'API_KEY_MISSING',
        });
        return;
      }

      const video = videoRegistry.get(videoId)!;
      const options = {
        autoDetectCategory: Boolean(autoDetectCategory),
        selectedCategory,
        autoDetectBestClips: Boolean(autoDetectBestClips),
        numberOfClips: Math.max(1, Math.min(10, Number(numberOfClips) || 4)),
        durationPreset,
        aspectRatio,
        captionLanguage,
        captionStyle,
        layoutPreference,
        webcamPreference,
        engine: (useGemini ? 'gemini' : 'local') as 'local' | 'gemini',
        jobTag: '',
      };

      if (req.query.sync === '1') {
        options.jobTag = `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const result = await executeAnalyzeAndRender(video, options);
        res.json(result);
        return;
      }

      const jobId = `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      options.jobTag = jobId;
      const job: AnalyzeJob = {
        jobId,
        status: 'running',
        stage: useGemini ? 'Preparing video for multimodal AI analysis...' : 'Starting local clipping engine...',
        progress: 5,
      };
      jobRegistry.set(jobId, job);

      res.status(202).json({ jobId, status: job.status, stage: job.stage, progress: job.progress });

      executeAnalyzeAndRender(video, options, (stage, progress) => {
        const current = jobRegistry.get(jobId) as AnalyzeJob | undefined;
        if (current && current.status === 'running') {
          current.stage = stage;
          current.progress = progress;
        }
      })
        .then((result) => {
          const current = jobRegistry.get(jobId) as AnalyzeJob | undefined;
          if (current) {
            current.status = 'completed';
            current.stage = 'Completed';
            current.progress = 100;
            current.result = result;
          }
        })
        .catch((err) => {
          const current = jobRegistry.get(jobId) as AnalyzeJob | undefined;
          if (current) {
            current.status = 'failed';
            current.error = err instanceof Error ? err.message : 'Auto Clip analysis failed.';
            current.errorCode =
              err instanceof GeminiConfigError
                ? err.code
                : err instanceof LocalEngineError
                  ? err.code
                  : 'ANALYSIS_ERROR';
          }
        });
    } catch (err) {
      if (err instanceof GeminiConfigError) {
        res.status(err.statusCode).json({ error: err.message, code: err.code });
        return;
      }
      const message = err instanceof Error ? err.message : 'Auto clip analysis failed.';
      res.status(500).json({ error: message });
    }
  });

  app.get('/api/jobs/:jobId', (req, res) => {
    const job = jobRegistry.get(req.params.jobId);
    if (!job) {
      res.status(404).json({ error: 'Analysis job not found or expired.' });
      return;
    }
    res.json(job);
  });

  app.post('/api/clips/:clipId/render', async (req, res) => {
    try {
      const { clipId } = req.params;
      const existing = clipRegistry.get(clipId);
      if (!existing) {
        res.status(404).json({ error: 'Clip not found.' });
        return;
      }

      const video = videoRegistry.get(existing.videoId);
      if (!video) {
        res.status(404).json({ error: 'Source video for this clip is no longer available.' });
        return;
      }

      if (!video.filePath) {
        res.status(400).json({
          error:
            'Direct MP4 re-rendering is unavailable because YouTube restricted server-side media streaming for this video.',
        });
        return;
      }

      const body = req.body as {
        title?: string;
        startTime?: number;
        endTime?: number;
        aspectRatio?: AspectRatio;
        layoutMode?: ClipLayoutMode;
        webcamPosition?: DetectedWebcamPosition;
        captionStyle?: CaptionStyleId;
        captions?: CaptionCue[];
        category?: ConcreteCategoryId;
      };

      const startTime = Math.max(
        0,
        Math.min(video.probe.duration - 1, Number(body.startTime ?? existing.clip.startTime))
      );
      const endTime = Math.max(
        startTime + 1,
        Math.min(video.probe.duration, Number(body.endTime ?? existing.clip.endTime))
      );
      const duration = Number((endTime - startTime).toFixed(2));

      const aspectRatio = body.aspectRatio ?? existing.clip.aspectRatio;
      const category = body.category ?? existing.clip.detectedCategory;
      const webcamPosition = body.webcamPosition ?? existing.clip.webcamPosition ?? 'none';
      const layoutMode = resolveLayoutForCategory(
        category,
        aspectRatio,
        body.layoutMode ?? existing.clip.layoutMode,
        body.layoutMode ?? 'auto',
        webcamPosition
      );
      const captionStyle = body.captionStyle ?? existing.clip.captionStyle;
      const captions = (body.captions ?? existing.clip.captions)
        .map((c) => ({
          start: Math.max(0, Math.min(duration, Number(c.start))),
          end: Math.max(0, Math.min(duration, Number(c.end))),
          text: String(c.text ?? '').trim(),
        }))
        .filter((c) => c.text.length > 0 && c.end > c.start);

      // Resolve a LOCAL source file for the render. Uploads/samples render from
      // the stored file. YouTube clips render from the segment the local engine
      // already downloaded, or a fresh segment downloaded with yt-dlp — never
      // from a remote HLS URL.
      let sourcePath = video.filePath;
      let startOffset = 0;
      if (video.sourceType === 'youtube') {
        const clip = existing.clip;
        let reusedSegment = false;
        if (clip.segmentPath && typeof clip.segmentStart === 'number') {
          try {
            const segProbe = await probeVideo(clip.segmentPath);
            if (
              startTime >= clip.segmentStart &&
              endTime <= clip.segmentStart + segProbe.duration
            ) {
              sourcePath = clip.segmentPath;
              startOffset = clip.segmentStart;
              reusedSegment = true;
            }
          } catch {
            // fall through to a fresh segment download
          }
        }
        if (!reusedSegment) {
          if (!video.youtubeUrl) {
            res.status(400).json({
              error:
                'Direct MP4 re-rendering is unavailable because YouTube restricted server-side media streaming for this video.',
            });
            return;
          }
          try {
            const seg = await downloadSegment(
              video.youtubeUrl,
              startTime,
              endTime,
              path.join(WORK_ROOT, 'jobs', existing.videoId, 'segments')
            );
            sourcePath = seg.path;
            startOffset = seg.segmentStart;
          } catch (segErr) {
            res.status(502).json({
              error:
                segErr instanceof Error
                  ? segErr.message
                  : 'Could not download the clip segment from YouTube for re-rendering.',
            });
            return;
          }
        }
      }

      const newFilename = `${clipId}_v${Date.now()}.mp4`;
      const newOutputPath = path.join(CLIPS_DIR, newFilename);

      // Word cues are relative to the ORIGINAL clip start; shift them to the
      // new start time so karaoke stays in sync after an edit.
      const shiftedWordCues = (existing.clip.wordCues ?? [])
        .map((w) => ({
          start: w.start + (existing.clip.startTime - startTime),
          end: w.end + (existing.clip.startTime - startTime),
          text: w.text,
        }))
        .filter((w) => w.end > 0 && w.start < duration);

      await renderClipMp4({
        sourcePath,
        outputPath: newOutputPath,
        clipId,
        startTime: startTime - startOffset,
        endTime: endTime - startOffset,
        aspectRatio,
        layoutMode,
        webcamPosition,
        captionStyle,
        captions,
        title: (body.title ?? existing.clip.title).trim() || existing.clip.title,
        wordCues: shiftedWordCues.length > 0 ? shiftedWordCues : undefined,
        hasAudio: video.probe.hasAudio,
      });

      if (existing.outputPath && existing.outputPath !== newOutputPath) {
        await fs.unlink(existing.outputPath).catch(() => undefined);
      }

      const updatedClip: NormalizedClip = {
        ...existing.clip,
        title: (body.title ?? existing.clip.title).trim() || existing.clip.title,
        startTime: Number(startTime.toFixed(2)),
        endTime: Number(endTime.toFixed(2)),
        duration,
        detectedCategory: category,
        aspectRatio,
        layoutMode,
        webcamPosition,
        captionStyle,
        captions,
        renderUrl: `/api/media/clips/${encodeURIComponent(newFilename)}`,
        srtUrl: `/api/clips/${encodeURIComponent(clipId)}/srt`,
        renderedAt: new Date().toISOString(),
      };

      clipRegistry.set(clipId, {
        clip: updatedClip,
        videoId: existing.videoId,
        outputPath: newOutputPath,
        outputFilename: newFilename,
      });

      res.json({ clip: updatedClip });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to re-render clip.';
      res.status(500).json({ error: message });
    }
  });

  app.get('/api/clips/:clipId/srt', (req, res) => {
    const existing = clipRegistry.get(req.params.clipId);
    if (!existing) {
      res.status(404).json({ error: 'Clip not found.' });
      return;
    }

    const srt = generateSrtContent(existing.clip.captions);
    const safeName =
      existing.clip.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '') || 'clip';

    res.setHeader('Content-Type', 'application/x-subrip; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.srt"`);
    res.send(srt);
  });

  app.get('/api/media/uploads/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    res.sendFile(path.join(UPLOADS_DIR, safeName));
  });

  app.get('/api/media/samples/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    res.sendFile(path.join(path.dirname(UPLOADS_DIR), 'samples', safeName));
  });

  app.get('/api/media/clips/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const fullPath = path.join(CLIPS_DIR, safeName);
    if (req.query.download === '1') {
      res.download(fullPath, safeName);
      return;
    }
    res.sendFile(fullPath);
  });

  app.all('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use(
    (
      err: Error,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      res.status(400).json({ error: err.message || 'Invalid request.' });
    }
  );

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Klipz Ai studio server listening on http://0.0.0.0:${port}`);
  });
}

// Production hardening: a single failed job, download, or render must never
// take the server down. Unhandled promise rejections are logged and the
// server keeps serving; a truly uncaught exception is logged and the process
// exits non-zero so a process manager (systemd / PM2 / Docker restart policy)
// restarts it cleanly.
process.on('unhandledRejection', (reason) => {
  console.error('[Klipz Ai] Unhandled promise rejection (server kept running):', reason);
});
process.on('uncaughtException', (err) => {
  console.error('[Klipz Ai] Uncaught exception — exiting for a clean restart:', err);
  process.exit(1);
});

startServer().catch((err) => {
  console.error('Failed to start Klipz Ai server:', err);
  process.exit(1);
});
