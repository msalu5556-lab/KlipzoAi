# Klipz Ai — Universal Auto Clipping Engine

Paste a YouTube URL or upload a video and Klipz Ai finds the strongest
moments and renders finished **1080×1920 vertical clips** by itself — title
banner, word-by-word karaoke captions, facecam layout when a camera is
present, and every moment scored out of 100 with the evidence behind it.

**No API key is required to clip.** The default engine runs entirely on your
machine: yt-dlp for YouTube, faster-whisper for transcription, and measured
loudness + transcript signals for moment detection and verification. Gemini
is an optional enhancement (automatic category detection) when you add a key.

## What it produces

- **1080×1920, ~35s clips** (balanced preset; 25s short / 75s deep), h264 + AAC
- **Gameplay top / facecam bottom** when a facecam is detected (face found
  automatically with YuNet; corner fallback otherwise)
- **Title banner** — black bold text on a white box, top of the clip
- **Word-by-word karaoke captions** — active word yellow + 118% scale
- **Scores /100 with evidence** — loudness, transcript markers, chat burst,
  quotable lines. A moment must score **70+ with at least two independent
  signals** or it is rejected, not shipped.

## Quick start

### Prerequisites

| Tool | Version | Notes |
| --- | --- | --- |
| Node.js | 20+ | `npm install` runs the app |
| ffmpeg | 8+ (7 works) | Must be on PATH (`ffmpeg -version`) |
| Python | 3.10+ | Only for the local clipping engine |
| Python packages | see below | faster-whisper, yt-dlp, numpy, opencv, av |

### 1. Install

```bash
npm install
python3 -m venv .venv
.venv/bin/pip install -r src/server/python/requirements-python.txt
```

On Windows (PowerShell):

```powershell
npm install
py -3 -m venv .venv
.venv\Scripts\pip install -r src\server\python\requirements-python.txt
```

> **Do not upgrade PyAV.** The engine pins `av==14.2.0` because
> faster-whisper 1.2.1 calls `av.open()` with a keyword PyAV 19.x removed.
> Upgrading it breaks transcription.

### 2. Configure (optional)

```bash
cp .env.example .env.local
```

Everything in `.env.local` is optional. With no keys at all, clipping works.
Add `GEMINI_API_KEY` only if you want the Gemini engine
(`KLIPZ_USE_GEMINI=1` or `engine: "gemini"` per request).

### 3. Run

```bash
npm run dev      # development (Vite + tsx, hot reload)
```

Open http://localhost:3000, upload a video or paste a YouTube URL, pick a
category (or Auto), and click **Run Auto Clip**.

## Production (public launch)

```bash
npm run build    # vite build → dist/
npm start        # serves dist/ + the API on $PORT (default 3000)
```

Run it under a process manager so it restarts after a crash or a reboot:

```bash
# systemd (example unit)
#   ExecStart=/usr/bin/npm start
#   WorkingDirectory=/opt/klipz-ai
#   Restart=always
#   EnvironmentFile=/opt/klipz-ai/.env.local

# or PM2
npx pm2 start npm --name klipz-ai -- start
```

Set `PORT` in `.env.local` if 3000 is taken. Put a reverse proxy
(nginx / Caddy) in front for TLS and static-file caching in production.

### Where files live

All working files are under the OS temp dir (no database):

| Path | Contents |
| --- | --- |
| `<tmp>/klipz-studio/uploads/` | Uploaded source videos |
| `<tmp>/klipz-studio/clips/` | Finished clips served at `/api/media/clips/:file` |
| `<tmp>/klipz-studio/subs/` | Temporary ASS subtitle / title files (deleted after render) |
| `<tmp>/klipz-studio/samples/` | Generated sample videos |
| `<tmp>/klipz-studio/jobs/<jobId>/` | Per-job engine work dir (moments, verified scores, segments) |

On Linux `<tmp>` is `/tmp`; on Windows it is `%TEMP%`. Set `KLIPZ_WORK_ROOT`
in `.env.local` to move the work root to a disk-backed path — required on
machines where `/tmp` is a small tmpfs (containers, small VMs), where a single
large upload can otherwise fill `/tmp` and fail every job (observed on the
test VM: /tmp is a 512 MB tmpfs and a 431 MB upload filled it).

The video/clip registry is in-memory only — **restarting the server clears the video/clip
list** (files stay on disk until the OS cleans /tmp). For a public launch,
add a periodic cleanup job for `klipz-studio/` if you run many jobs.

## How clipping works

1. **Ingest** — upload (chunked, resumable) or YouTube URL. For YouTube,
   yt-dlp reads the metadata; only the needed 35s segments are ever
   downloaded (a 23-hour VOD is never downloaded in full).
2. **Detect** — the full audio loudness series is scanned for spikes and the
   transcript is scanned for markers (reactions, laughter, quotes, questions,
   numbers). Candidate moments are sampled across the whole timeline.
3. **Verify** — each candidate is transcribed with faster-whisper and scored
   /100 (reaction, cause, story, chat, quotable, technical). A moment is kept
   only with **score ≥ 70 and ≥ 2 signals**; duplicates of the same emotion
   within 10 minutes are dropped.
4. **Render** — ffmpeg renders 1080×1920: gameplay top / facecam bottom
   (face auto-detected), title banner, karaoke captions from word timestamps.

The Gemini engine (opt-in) replaces steps 2–3 with multimodal LLM analysis;
it is only used when a key is configured and requested.

## API overview

| Endpoint | What it does |
| --- | --- |
| `GET /api/health` | Engine status: local engine (Python + deps), Gemini configured or not |
| `POST /api/videos/upload/init` + `/chunk` + `/complete` | Chunked upload |
| `POST /api/videos/upload` | Single-file upload (≤ 12 GB) |
| `POST /api/videos/youtube` | Import a YouTube URL (metadata via yt-dlp, youtubei.js fallback) |
| `POST /api/videos/sample` | Generate a sample video (gaming / podcast / educational) |
| `POST /api/analyze` | Start an analysis job → `{ jobId }` (202); `?sync=1` waits for the result |
| `GET /api/jobs/:jobId` | Job stage / progress / result / error |
| `POST /api/clips/:clipId/render` | Re-render a clip with edited title / times / captions |
| `GET /api/clips/:clipId/srt` | Download the clip's SRT captions |
| `GET /api/media/clips/:file` | Stream / download a finished clip (`?download=1`) |

`POST /api/analyze` body: `videoId`, `selectedCategory` (`auto` or a
category id), `numberOfClips` (1–10), `durationPreset` (`short` | `balanced` |
`deep`), `aspectRatio` (`9:16` | `16:9` | `1:1` | `4:5`),
`captionLanguage`, `captionStyle`, `layoutPreference`, `webcamPreference`,
`engine` (`local` default | `gemini` opt-in).

## Testing

```bash
npx tsc --noEmit
npm run build
npx tsx --test src/lib/clipEngine.test.ts src/server/ffmpegTools.test.ts src/server/localAnalyzer.test.ts
```

`TEST-REPORT.md` (in the repo root of this delivery) records the last
verified end-to-end run: real video → analyze → rendered clips, with
ffprobe + full-decode checks and the edge cases covered.

## Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `/api/health` says the local engine is unavailable | Python or a dependency is missing. Run the venv install above, or set `KLIPZ_PYTHON` to a Python with the packages. |
| `npm install` fails with ERESOLVE | Fixed in this version (esbuild pinned to ^0.28.0 for vite 8). If you see it, delete `node_modules` and `package-lock.json` and retry. |
| YouTube import fails with a bot-check message | YouTube is blocking downloads from this server. Wait 1–2 hours and retry, or upload the video file instead. Do not hammer retries — it makes the block worse. |
| Analysis finds no clips | No moment passed verification (score 70+, 2+ signals). Try a busier section of the video, or a different video. This is by design — weak moments are rejected, not shipped. |
| `npm start` fails | `start` runs `tsx server.ts`. Make sure `npm install` completed (tsx is a dependency). |
| Clips look low-res in a chat/Drive preview | Download the file first — previews transcode to low resolution. The files themselves are 1080×1920; verify with `ffprobe`. |

## Security notes

- No secrets are stored in code. `.env.local` is git-ignored; never commit it.
- Uploads accept video files only (MP4/MOV/WebM/MKV, ≤ 12 GB) and are stored
  outside the web root.
- The server never executes user input as code; YouTube URLs are passed to
  yt-dlp as a single argument, never through a shell.
- For a public deployment, put the app behind a reverse proxy with TLS and
  consider adding authentication / rate limiting in front of `/api/*` —
  the app itself has no auth.

## License

This is the user's own tool, rebuilt on their instruction. It bundles the
user's own proven Python clipping pipeline (`src/server/python/clip_stream.py`,
yt-dlp + faster-whisper + OpenCV/YuNet). Third-party dependencies keep their
own licenses (see `package.json` and `src/server/python/requirements-python.txt`).
