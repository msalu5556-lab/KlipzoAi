# Klipz Ai — Deploy guide (go live)

## Why Netlify does NOT work

Netlify serves **static files only**. Klipz Ai needs a real server — Node.js
for the app + API, Python for the clipping engine, and ffmpeg for rendering.
On Netlify there is no server, so `/api/health` (and every `/api/*` route)
does not exist, and the app shows "Local clipping engine is not ready /
Could not reach the server health endpoint". Any static host (Netlify,
Vercel static, GitHub Pages) will fail the same way. Use one of the options
below — all of them run the real server.

No API keys are needed for any option. The local engine (yt-dlp +
faster-whisper) clips with zero keys.

## Option A — Railway (easiest, recommended)

1. Push this folder to a GitHub repo.
2. Go to railway.app → New Project → Deploy from GitHub → pick the repo.
   Railway detects the `Dockerfile` and builds it automatically.
3. No environment variables are required. (Optional: `GEMINI_API_KEY` only
   if you want the Gemini engine; clipping works without it.)
4. Open the Railway URL. Check `/api/health` in the browser — it should say
   the local engine is available. The first clip is slower: it downloads
   the Whisper "base" model (~145 MB) once, then caches it.
5. Add your own domain in Railway → Settings → Domains if you want one.

## Option B — Render

1. Push to GitHub. Go to render.com → New → Web Service → pick the repo →
   Environment: **Docker**.
2. No environment variables are required. Deploy.
3. Same first-run check as Railway (step 4 above).

## Option C — VPS with Docker

1. On the server, install Docker, then copy this folder to the server.
2. Run: `docker compose up -d --build`
3. Open `http://YOUR-SERVER-IP:3000`.
4. For a domain + HTTPS, put Caddy or nginx in front (TLS + static caching).

## Option D — VPS without Docker

1. Install Node.js 20+, Python 3.12, ffmpeg.
2. `npm install`
3. `python3 -m venv .venv && .venv/bin/pip install -r src/server/python/requirements-python.txt`
4. `npm run build` then `npm start` (or run under PM2/systemd so it
   restarts after a crash or reboot — see README "Production").
5. Set `KLIPZ_WORK_ROOT` to a disk-backed path in `.env.local` (do not use
   `/tmp` if it is a small tmpfs — a large upload can fill it).

## Memory — read this first

Railway's **default memory limit is 512 MB**. The clipping engine needs
~400 MB just to load the Whisper `base` model, plus the Node server and
ffmpeg — so on 512 MB the engine is killed before it prints anything and
the app shows "Local clipping engine failed (exit null). Details: no
output". That is an out-of-memory kill, not a code bug.

- **Best fix:** service → Settings → Resources → Memory → **2 GB**
  (1 GB minimum). Then `base` works fine.
- **Staying on 512 MB:** set the variable `KLIPZ_WHISPER_MODEL=tiny`
  (service → Variables). Tiny needs ~260 MB to load and can fit, but
  captions are slightly less accurate than base. 1 GB is still safer.
- Confirm it in the dashboard → Metrics tab: if memory flatlines at
  512 MB and the job dies, that is the OOM kill.

## Troubleshooting

- **"Local clipping engine failed (exit null)"** — the engine process was
  killed instead of exiting with an error. Usually out of memory, or a
  stalled model download. Check the logs (`railway logs` or the Render log
  tab) for a "Killed" / out-of-memory line. Fixes: (1) raise the service
  memory to **2 GB or more** (Railway: service → Settings → Resources),
  (2) set `HF_TOKEN` (below). The Dockerfile pre-downloads the Whisper
  model at build time, so no model download happens at runtime.
- **"You are sending unauthenticated requests to the HF Hub"** — a warning,
  not an error by itself, but unauthenticated downloads are rate-limited
  and slow. Create a free token at huggingface.co → sign up → Settings →
  Access Tokens → New token (read) → add it as a variable named `HF_TOKEN`
  in Railway/Render and redeploy.
- **First clip is slow** — model load + transcription on CPU takes minutes;
  later clips reuse the cached model and are faster.

## Before you share the link

- Open the site and confirm the green "ready" banner (the app checks
  `/api/health` on load). If it shows the amber "engine not ready" alert,
  the server is not running — that is the same error as on Netlify.
- The first clip takes a few minutes (model download + transcription).
- The video/clip list clears when the server restarts (in-memory registry);
  finished clip files stay on disk.
- **The app has no login.** Do not expose it to the public without some
  protection in front (reverse proxy + auth / rate limiting) — see README
  "Production".
