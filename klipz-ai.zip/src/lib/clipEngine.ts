export type VideoCategoryId =
  | 'auto'
  | 'gaming'
  | 'podcast'
  | 'interview'
  | 'reaction'
  | 'commentary'
  | 'documentary'
  | 'educational'
  | 'storytelling'
  | 'news'
  | 'entertainment'
  | 'other';

export type ConcreteCategoryId = Exclude<VideoCategoryId, 'auto'>;

export type AspectRatio = '9:16' | '16:9' | '1:1' | '4:5';

export type ClipDurationPreset = 'short' | 'balanced' | 'deep';

export type CaptionStyleId =
  | 'clean_editorial'
  | 'bold_kinetic'
  | 'high_contrast_box'
  | 'minimal_bottom'
  | 'none';

export type ClipLayoutMode =
  | 'full_frame'
  | 'vertical_crop'
  | 'speaker_focus'
  | 'dual_speaker'
  | 'split_cam_gameplay'
  | 'picture_in_picture';

export type LayoutPreference = 'auto' | ClipLayoutMode;

export type WebcamPosition =
  | 'auto'
  | 'top_left'
  | 'top_right'
  | 'bottom_left'
  | 'bottom_right'
  | 'top_center'
  | 'none';

export type DetectedWebcamPosition = Exclude<WebcamPosition, 'auto'>;

export interface ScoreBreakdown {
  hookStrength: number;
  contextCompleteness: number;
  emotionalIntensity: number;
  valueScore: number;
  visualInterest: number;
  audioInterest: number;
  standaloneQuality: number;
  retentionPotential: number;
}

export interface CaptionCue {
  start: number; // seconds relative to clip start (0..duration)
  end: number;   // seconds relative to clip start
  text: string;
}

/** One word with its timing, from faster-whisper word timestamps. Used for
 * word-by-word karaoke captions (local engine) and karaoke re-renders. */
export interface WordCue {
  start: number;
  end: number;
  text: string;
}

export interface RawHighlightCandidate {
  title: string;
  startTime: number;
  endTime: number;
  detectedCategory?: ConcreteCategoryId;
  reason: string;
  recommendedLayout?: ClipLayoutMode;
  webcamPosition?: DetectedWebcamPosition;
  scores: ScoreBreakdown;
  captions: Array<{ start: number; end: number; text: string }>;
}

export interface NormalizedClip {
  id: string;
  index: number;
  title: string;
  startTime: number;
  endTime: number;
  duration: number;
  detectedCategory: ConcreteCategoryId;
  reason: string;
  layoutMode: ClipLayoutMode;
  webcamPosition: DetectedWebcamPosition;
  aspectRatio: AspectRatio;
  captionStyle: CaptionStyleId;
  captionLanguage: string;
  scores: ScoreBreakdown;
  overallScore: number;
  captions: CaptionCue[];
  renderUrl?: string;
  srtUrl?: string;
  renderedAt?: string;
  /** Set by the local engine when the clip was already rendered by the Python
   * pipeline: the server skips its own re-render and serves this file. */
  outputPath?: string;
  outputFilename?: string;
  /** Local segment file (YouTube sources) covering [segmentStart, ...], used
   * by the clip editor re-render path so it never re-downloads unnecessarily. */
  segmentPath?: string;
  segmentStart?: number;
  /** Word-level timings (faster-whisper), for karaoke re-renders. */
  wordCues?: WordCue[];
}

export interface CategoryProfile {
  id: ConcreteCategoryId;
  label: string;
  shortLabel: string;
  description: string;
  detectSignals: string[];
  avoidSignals: string[];
  allowSplitGameplayLayout: boolean;
  preferredVerticalLayout: ClipLayoutMode;
  weights: ScoreBreakdown;
}

export const CATEGORY_LIST: Array<{ id: VideoCategoryId; label: string }> = [
  { id: 'auto', label: 'Auto Detect Category' },
  { id: 'gaming', label: 'Gaming & GTA 6 Gameplay' },
  { id: 'podcast', label: 'Podcasts' },
  { id: 'interview', label: 'Interviews' },
  { id: 'reaction', label: 'Reaction Videos' },
  { id: 'commentary', label: 'YouTube Commentary' },
  { id: 'documentary', label: 'Documentaries' },
  { id: 'educational', label: 'Educational Videos' },
  { id: 'storytelling', label: 'Storytelling' },
  { id: 'news', label: 'News & Discussions' },
  { id: 'entertainment', label: 'General Entertainment' },
  { id: 'other', label: 'Other / Mixed Content' },
];

export const CATEGORY_PROFILES: Record<ConcreteCategoryId, CategoryProfile> = {
  gaming: {
    id: 'gaming',
    label: 'Gaming & GTA 6 Gameplay',
    shortLabel: 'Gaming',
    description:
      'Prioritizes unexpected in-game events, police chases, crashes, explosions, funny NPC interactions, close calls, and high-energy player reactions—including purely visual sequences without speech.',
    detectSignals: [
      'Unexpected in-game events, glitches, or rare emergent gameplay',
      'Funny NPC interactions, unscripted dialogue, or chaotic physics',
      'Police chases, high-speed escapes, explosions, and vehicle crashes',
      'Intense combat, boss fights, clutch wins, failures, and close calls',
      'Genuine player reactions, excitement, shock, or laughter',
      'Visually striking action sequences even when commentary is silent',
    ],
    avoidSignals: [
      'Routine map traversal or driving with nothing notable happening',
      'Inventory/menu browsing or loading screens',
      'Random movement selected purely for pixel motion without narrative payoff',
    ],
    allowSplitGameplayLayout: true,
    preferredVerticalLayout: 'split_cam_gameplay',
    weights: {
      hookStrength: 0.14,
      contextCompleteness: 0.08,
      emotionalIntensity: 0.14,
      valueScore: 0.10,
      visualInterest: 0.22,
      audioInterest: 0.12,
      standaloneQuality: 0.10,
      retentionPotential: 0.10,
    },
  },
  podcast: {
    id: 'podcast',
    label: 'Podcasts',
    shortLabel: 'Podcast',
    description:
      'Targets complete conversational arcs: strong opinions, unexpected revelations, heated debates, memorable quotes, humor, and emotional storytelling with full setup and payoff.',
    detectSignals: [
      'Strong opinions, hot takes, or controversial statements with reasoning',
      'Debate, disagreement, or sharp back-and-forth exchanges',
      'Unexpected revelations, personal confessions, or emotional shifts',
      'Funny anecdotes or infectious host/guest laughter',
      'Memorable, quotable insights with clear conversational setup and payoff',
    ],
    avoidSignals: [
      'Sponsor reads, housekeeping, or intro/outro pleasantries',
      'Cutting mid-thought before the speaker finishes their argument',
      'Filler small talk without a clear point or emotional beat',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.14,
      contextCompleteness: 0.18,
      emotionalIntensity: 0.14,
      valueScore: 0.16,
      visualInterest: 0.04,
      audioInterest: 0.10,
      standaloneQuality: 0.14,
      retentionPotential: 0.10,
    },
  },
  interview: {
    id: 'interview',
    label: 'Interviews',
    shortLabel: 'Interview',
    description:
      'Captures complete question-and-answer moments, candid admissions, emotional turning points, and memorable soundbites without detaching answers from the question context.',
    detectSignals: [
      'Sharp, probing questions paired with candid or surprising answers',
      'Personal breakthroughs, vulnerability, or emotional moments',
      'Behind-the-scenes stories or previously untold details',
      'Direct challenges, pushback, or memorable one-line takeaways',
    ],
    avoidSignals: [
      'Answers sliced away from the question needed to understand them',
      'Generic bio recaps or pleasantry greetings',
      'Long pauses or off-topic warmups',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.13,
      contextCompleteness: 0.20,
      emotionalIntensity: 0.14,
      valueScore: 0.16,
      visualInterest: 0.05,
      audioInterest: 0.09,
      standaloneQuality: 0.13,
      retentionPotential: 0.10,
    },
  },
  reaction: {
    id: 'reaction',
    label: 'Reaction Videos',
    shortLabel: 'Reaction',
    description:
      'Detects genuine shock, laughter, emotional responses, sharp commentary, and the exact source moment that triggers the reaction.',
    detectSignals: [
      'Visceral surprise, jaw-drop moments, or sudden emotional shifts',
      'Funny spontaneous responses or sharp comedic timing',
      'Crucial pause-and-analyze commentary that adds perspective',
      'Unexpected visual twists in the source media paired with creator reaction',
    ],
    avoidSignals: [
      'Passive watching with no facial, vocal, or analytical reaction',
      'Reactions divorced from the visual/audio trigger that caused them',
    ],
    allowSplitGameplayLayout: true,
    preferredVerticalLayout: 'split_cam_gameplay',
    weights: {
      hookStrength: 0.16,
      contextCompleteness: 0.12,
      emotionalIntensity: 0.20,
      valueScore: 0.09,
      visualInterest: 0.14,
      audioInterest: 0.11,
      standaloneQuality: 0.08,
      retentionPotential: 0.10,
    },
  },
  commentary: {
    id: 'commentary',
    label: 'YouTube Commentary',
    shortLabel: 'Commentary',
    description:
      'Finds razor-sharp thesis statements, takedowns, comedic observations, visual receipts, and structured argument payoffs.',
    detectSignals: [
      'Punchy opening hooks and thesis statements',
      'Clever analogies, satirical observations, or memorable punchlines',
      'Key evidence reveals or turning points in an argument',
      'High-retention rhetorical payoffs that stand alone cleanly',
    ],
    avoidSignals: [
      'Channel updates, patreon plugs, or repetitive transitions',
      'Incomplete premises missing their punchline or conclusion',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.17,
      contextCompleteness: 0.16,
      emotionalIntensity: 0.12,
      valueScore: 0.16,
      visualInterest: 0.08,
      audioInterest: 0.09,
      standaloneQuality: 0.12,
      retentionPotential: 0.10,
    },
  },
  documentary: {
    id: 'documentary',
    label: 'Documentaries',
    shortLabel: 'Documentary',
    description:
      'Preserves narrative authority: suspenseful revelations, historical/factual turning points, surprising archival facts, and complete self-contained story chapters.',
    detectSignals: [
      'Compelling narrative hooks and atmospheric chapter openers',
      'Suspenseful revelations, investigative turns, or surprising facts',
      'Concise historical or scientific explanations with visual backing',
      'Resonant story payoffs with complete causal context',
    ],
    avoidSignals: [
      'Sentences cut away from preceding factual setup',
      'Forced split-screen clutter over cinematic framing',
      'Slow ambient establishing shots with no narrative progression',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.13,
      contextCompleteness: 0.21,
      emotionalIntensity: 0.11,
      valueScore: 0.17,
      visualInterest: 0.11,
      audioInterest: 0.06,
      standaloneQuality: 0.13,
      retentionPotential: 0.08,
    },
  },
  educational: {
    id: 'educational',
    label: 'Educational Videos',
    shortLabel: 'Educational',
    description:
      'Extracts clear demonstrations, actionable tips, "aha" conceptual explanations, and direct answers to common questions.',
    detectSignals: [
      'Clear, self-contained explanations of complex concepts',
      'Step-by-step demonstrations or live visual walkthroughs',
      'Actionable tips, frameworks, or myth-busting insights',
      'Direct, authoritative answers to common audience questions',
    ],
    avoidSignals: [
      'Mid-equation cuts or partial tutorials missing the final result',
      'Course promos or housekeeping announcements',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.14,
      contextCompleteness: 0.19,
      emotionalIntensity: 0.05,
      valueScore: 0.25,
      visualInterest: 0.11,
      audioInterest: 0.06,
      standaloneQuality: 0.13,
      retentionPotential: 0.07,
    },
  },
  storytelling: {
    id: 'storytelling',
    label: 'Storytelling',
    shortLabel: 'Storytelling',
    description:
      'Isolates gripping story arcs with clear inciting tension, vivid pacing, emotional resonance, and satisfying endings.',
    detectSignals: [
      'Magnetic opening lines that establish stakes immediately',
      'Rising tension, unexpected plot twists, or vivid sensory details',
      'Emotional catharsis, humor, or unforgettable endings',
      'Complete mini-stories that require no outside context',
    ],
    avoidSignals: [
      'Cliffhangers cut right before the payoff',
      'Rambling preambles with delayed setup',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.16,
      contextCompleteness: 0.19,
      emotionalIntensity: 0.17,
      valueScore: 0.11,
      visualInterest: 0.07,
      audioInterest: 0.08,
      standaloneQuality: 0.13,
      retentionPotential: 0.09,
    },
  },
  news: {
    id: 'news',
    label: 'News & Discussions',
    shortLabel: 'News',
    description:
      'Highlights breaking updates, clear analytical takeaways, sharp panel disagreements, and concise contextual summaries.',
    detectSignals: [
      'Key factual developments and clear impact explanations',
      'Sharp analyst disagreements or contrasting viewpoints',
      'Crisp, quotable summaries of complex events',
    ],
    avoidSignals: [
      'Anchor handoffs, bumper music, or repetitive recap loops',
      'Claims clipped without their key evidence or qualifier',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.15,
      contextCompleteness: 0.20,
      emotionalIntensity: 0.08,
      valueScore: 0.20,
      visualInterest: 0.07,
      audioInterest: 0.08,
      standaloneQuality: 0.14,
      retentionPotential: 0.08,
    },
  },
  entertainment: {
    id: 'entertainment',
    label: 'General Entertainment',
    shortLabel: 'Entertainment',
    description:
      'Selects high-energy comedic bits, unexpected stunts, crowd reactions, challenges, and viral-paced visual payoffs.',
    detectSignals: [
      'High-energy comedic moments, pranks, or challenge payoffs',
      'Unexpected twists, impressive skills, or visual spectacles',
      'Infectious group energy or memorable crowd reactions',
    ],
    avoidSignals: [
      'Dead air, setup logistics, or repetitive filler banter',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.18,
      contextCompleteness: 0.10,
      emotionalIntensity: 0.16,
      valueScore: 0.12,
      visualInterest: 0.16,
      audioInterest: 0.10,
      standaloneQuality: 0.09,
      retentionPotential: 0.09,
    },
  },
  other: {
    id: 'other',
    label: 'Other / Mixed Content',
    shortLabel: 'Mixed',
    description:
      'Balanced multi-signal scoring across hook strength, clarity, visual/audio dynamics, and standalone viewer retention.',
    detectSignals: [
      'Strongest opening hooks and visually/aurally distinct segments',
      'Complete, self-contained moments with clear beginning and ending',
      'High informational or entertainment payoff',
    ],
    avoidSignals: [
      'Excessive silence, incomplete sentences, or repetitive footage',
    ],
    allowSplitGameplayLayout: false,
    preferredVerticalLayout: 'full_frame',
    weights: {
      hookStrength: 0.15,
      contextCompleteness: 0.15,
      emotionalIntensity: 0.12,
      valueScore: 0.15,
      visualInterest: 0.12,
      audioInterest: 0.10,
      standaloneQuality: 0.11,
      retentionPotential: 0.10,
    },
  },
};

export const DURATION_PRESETS: Record<
  ClipDurationPreset,
  { label: string; minSeconds: number; targetSeconds: number; maxSeconds: number }
> = {
  short: { label: 'Short (15–30s)', minSeconds: 8, targetSeconds: 22, maxSeconds: 35 },
  balanced: { label: 'Balanced (30–60s)', minSeconds: 15, targetSeconds: 42, maxSeconds: 65 },
  deep: { label: 'Deep (60–90s)', minSeconds: 30, targetSeconds: 72, maxSeconds: 100 },
};

export const CAPTION_STYLES: Array<{ id: CaptionStyleId; label: string; description: string }> = [
  { id: 'clean_editorial', label: 'Clean Editorial', description: 'Crisp white sans text with subtle drop shadow' },
  { id: 'bold_kinetic', label: 'Bold Kinetic', description: 'High-impact uppercase studio captions' },
  { id: 'high_contrast_box', label: 'High Contrast Box', description: 'Dark translucent backdrop behind readable text' },
  { id: 'minimal_bottom', label: 'Minimal Subtitle', description: 'Subtle lower-third broadcast captioning' },
  { id: 'none', label: 'No Captions', description: 'Clean video render without burned-in captions' },
];

export const CAPTION_LANGUAGES = [
  'English',
  'Auto / Original Language',
  'Spanish',
  'French',
  'German',
  'Arabic',
  'Hindi',
  'Urdu',
  'Portuguese',
  'Japanese',
];

export const LAYOUT_LABELS: Record<ClipLayoutMode, string> = {
  full_frame: 'Exact Full Frame (No Cut)',
  vertical_crop: 'Smart Center Crop',
  speaker_focus: 'Speaker Focus',
  dual_speaker: 'Dual Speaker Split',
  split_cam_gameplay: 'Gameplay Top + Facecam Bottom',
  picture_in_picture: 'Picture-in-Picture',
};

export const WEBCAM_POSITION_LABELS: Record<WebcamPosition, string> = {
  auto: 'Auto Detect Facecam',
  top_left: 'Top Left Cam',
  top_right: 'Top Right Cam',
  bottom_left: 'Bottom Left Cam',
  bottom_right: 'Bottom Right Cam',
  top_center: 'Top Center Cam',
  none: 'No Webcam (Full Screen)',
};

export function clampScore(value: number): number {
  if (!Number.isFinite(value)) return 50;
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function computeWeightedClipScore(
  scores: ScoreBreakdown,
  category: ConcreteCategoryId
): number {
  const profile = CATEGORY_PROFILES[category] ?? CATEGORY_PROFILES.other;
  const w = profile.weights;
  const total =
    clampScore(scores.hookStrength) * w.hookStrength +
    clampScore(scores.contextCompleteness) * w.contextCompleteness +
    clampScore(scores.emotionalIntensity) * w.emotionalIntensity +
    clampScore(scores.valueScore) * w.valueScore +
    clampScore(scores.visualInterest) * w.visualInterest +
    clampScore(scores.audioInterest) * w.audioInterest +
    clampScore(scores.standaloneQuality) * w.standaloneQuality +
    clampScore(scores.retentionPotential) * w.retentionPotential;
  return Math.max(0, Math.min(100, Math.round(total)));
}

/**
 * Guarantees exact content-appropriate framing:
 * - 16:9 always uses full_frame (unless PiP for reaction) with zero border cutting.
 * - Podcasts, interviews, documentaries, educational, storytelling, and news NEVER get split_cam_gameplay
 *   and default to exact full_frame (or dual_speaker for side-by-side podcasts) so faces/borders aren't cut.
 * - Gaming & reaction in 9:16 use Streamer Top + Gameplay Bottom when a facecam is present,
 *   or exact full_frame when no webcam is present so HUD/edges aren't cropped out.
 */
export function resolveLayoutForCategory(
  category: ConcreteCategoryId,
  aspectRatio: AspectRatio,
  suggestedLayout?: ClipLayoutMode,
  preferredLayout: LayoutPreference = 'auto',
  webcamPosition: DetectedWebcamPosition = 'none'
): ClipLayoutMode {
  const profile = CATEGORY_PROFILES[category] ?? CATEGORY_PROFILES.other;

  // Explicit user override (respecting safety rule: no gameplay split on non-gaming/non-reaction)
  if (preferredLayout !== 'auto') {
    if (preferredLayout === 'split_cam_gameplay' && !profile.allowSplitGameplayLayout) {
      return aspectRatio === '16:9' ? 'full_frame' : profile.preferredVerticalLayout;
    }
    if (aspectRatio === '16:9' && preferredLayout === 'split_cam_gameplay') {
      return 'full_frame';
    }
    return preferredLayout;
  }

  if (aspectRatio === '16:9') {
    return 'full_frame';
  }

  if (!profile.allowSplitGameplayLayout) {
    if (suggestedLayout === 'dual_speaker' && (category === 'podcast' || category === 'interview')) {
      return 'dual_speaker';
    }
    // Always prefer full_frame over blind center-cropping so borders & side speakers are never cut
    return 'full_frame';
  }

  // Gaming / Reaction in vertical formats (9:16, 4:5)
  if (aspectRatio === '9:16' && webcamPosition !== 'none') {
    return 'split_cam_gameplay';
  }

  if (suggestedLayout === 'split_cam_gameplay' && aspectRatio === '9:16' && webcamPosition !== 'none') {
    return 'split_cam_gameplay';
  }

  return 'full_frame';
}

export function computeIntervalOverlapRatio(
  aStart: number,
  aEnd: number,
  bStart: number,
  bEnd: number
): number {
  const overlapStart = Math.max(aStart, bStart);
  const overlapEnd = Math.min(aEnd, bEnd);
  if (overlapEnd <= overlapStart) return 0;
  const overlap = overlapEnd - overlapStart;
  const minDur = Math.min(aEnd - aStart, bEnd - bStart);
  if (minDur <= 0) return 0;
  return overlap / minDur;
}

export interface NormalizeClipsOptions {
  videoDuration: number;
  selectedCategory: VideoCategoryId;
  detectedPrimaryCategory: ConcreteCategoryId;
  maxClips: number;
  durationPreset: ClipDurationPreset;
  aspectRatio: AspectRatio;
  captionStyle: CaptionStyleId;
  captionLanguage: string;
  layoutPreference?: LayoutPreference;
  webcamPreference?: WebcamPosition;
  detectedWebcamPosition?: DetectedWebcamPosition;
}

export function validateAndNormalizeClips(
  candidates: RawHighlightCandidate[],
  options: NormalizeClipsOptions
): NormalizedClip[] {
  const {
    videoDuration,
    selectedCategory,
    detectedPrimaryCategory,
    maxClips,
    durationPreset,
    aspectRatio,
    captionStyle,
    captionLanguage,
    layoutPreference = 'auto',
    webcamPreference = 'auto',
    detectedWebcamPosition = 'none',
  } = options;

  const safeVideoDuration = Math.max(1, videoDuration);
  const preset = DURATION_PRESETS[durationPreset];
  const effectiveMinDuration =
    safeVideoDuration < preset.minSeconds * 1.5
      ? Math.max(3, Math.min(preset.minSeconds, safeVideoDuration * 0.25))
      : preset.minSeconds;

  const scored: Array<Omit<NormalizedClip, 'index'>> = [];

  for (let i = 0; i < candidates.length; i++) {
    const raw = candidates[i];
    const start = Math.max(0, Math.min(safeVideoDuration - 1, Number(raw.startTime) || 0));
    const end = Math.max(start, Math.min(safeVideoDuration, Number(raw.endTime) || 0));
    const duration = Number((end - start).toFixed(2));

    if (duration < effectiveMinDuration) {
      continue;
    }

    const effectiveCategory: ConcreteCategoryId =
      selectedCategory !== 'auto'
        ? selectedCategory
        : raw.detectedCategory && raw.detectedCategory in CATEGORY_PROFILES
          ? raw.detectedCategory
          : detectedPrimaryCategory;

    const cleanScores: ScoreBreakdown = {
      hookStrength: clampScore(raw.scores?.hookStrength ?? 70),
      contextCompleteness: clampScore(raw.scores?.contextCompleteness ?? 70),
      emotionalIntensity: clampScore(raw.scores?.emotionalIntensity ?? 70),
      valueScore: clampScore(raw.scores?.valueScore ?? 70),
      visualInterest: clampScore(raw.scores?.visualInterest ?? 70),
      audioInterest: clampScore(raw.scores?.audioInterest ?? 70),
      standaloneQuality: clampScore(raw.scores?.standaloneQuality ?? 70),
      retentionPotential: clampScore(raw.scores?.retentionPotential ?? 70),
    };

    const overallScore = computeWeightedClipScore(cleanScores, effectiveCategory);
    const effectiveWebcam: DetectedWebcamPosition =
      webcamPreference !== 'auto'
        ? webcamPreference
        : raw.webcamPosition && raw.webcamPosition !== ('auto' as string)
          ? raw.webcamPosition
          : detectedWebcamPosition;

    const layoutMode = resolveLayoutForCategory(
      effectiveCategory,
      aspectRatio,
      raw.recommendedLayout,
      layoutPreference,
      effectiveWebcam
    );

    const normalizedCaptions: CaptionCue[] = (raw.captions ?? [])
      .map((cue) => {
        const looksAbsolute = cue.start >= start - 0.5 && cue.end <= end + 1.0 && start > 1.0;
        const relStart = looksAbsolute ? cue.start - start : cue.start;
        const relEnd = looksAbsolute ? cue.end - start : cue.end;
        return {
          start: Math.max(0, Math.min(duration, Number(relStart.toFixed(2)))),
          end: Math.max(0, Math.min(duration, Number(relEnd.toFixed(2)))),
          text: String(cue.text ?? '').trim(),
        };
      })
      .filter((cue) => cue.text.length > 0 && cue.end > cue.start)
      .sort((a, b) => a.start - b.start);

    scored.push({
      id: `clip_${i + 1}_${Math.round(start)}_${Math.round(end)}`,
      title: (raw.title || `Highlight ${i + 1}`).trim(),
      startTime: Number(start.toFixed(2)),
      endTime: Number(end.toFixed(2)),
      duration,
      detectedCategory: effectiveCategory,
      reason: (raw.reason || 'High engagement moment with complete context.').trim(),
      layoutMode,
      webcamPosition: effectiveWebcam,
      aspectRatio,
      captionStyle,
      captionLanguage,
      scores: cleanScores,
      overallScore,
      captions: normalizedCaptions,
    });
  }

  scored.sort((a, b) => b.overallScore - a.overallScore);

  const selected: NormalizedClip[] = [];
  for (const candidate of scored) {
    if (selected.length >= Math.max(1, maxClips)) break;
    const overlapsExisting = selected.some(
      (existing) =>
        computeIntervalOverlapRatio(
          candidate.startTime,
          candidate.endTime,
          existing.startTime,
          existing.endTime
        ) > 0.35
    );
    if (!overlapsExisting) {
      selected.push({
        ...candidate,
        index: selected.length + 1,
      });
    }
  }

  return selected;
}

/**
 * Selects evenly-distributed + peak-centered analysis windows across videos up to 10+ hours.
 */
export function selectCandidateWindows(
  totalDuration: number,
  options: {
    windowSeconds?: number;
    maxWindows?: number;
    activityPeaks?: number[];
  } = {}
): Array<{ start: number; end: number }> {
  const safeDuration = Math.max(1, totalDuration);
  const windowSeconds = Math.min(safeDuration, options.windowSeconds ?? 150);
  const maxWindows = Math.max(1, options.maxWindows ?? 6);

  if (safeDuration <= windowSeconds * 1.25) {
    return [{ start: 0, end: Number(safeDuration.toFixed(2)) }];
  }

  const windows: Array<{ start: number; end: number }> = [];
  const half = windowSeconds / 2;

  // 1. Add peak-centered windows first (from audio RMS spikes or YouTube heatmap)
  for (const peak of options.activityPeaks ?? []) {
    if (windows.length >= maxWindows) break;
    if (!Number.isFinite(peak) || peak < 0 || peak > safeDuration) continue;
    let start = Math.max(0, peak - half);
    let end = start + windowSeconds;
    if (end > safeDuration) {
      end = safeDuration;
      start = Math.max(0, end - windowSeconds);
    }
    const overlaps = windows.some(
      (w) => computeIntervalOverlapRatio(start, end, w.start, w.end) > 0.3
    );
    if (!overlaps) {
      windows.push({ start: Number(start.toFixed(2)), end: Number(end.toFixed(2)) });
    }
  }

  // 2. Fill remaining slots evenly across the entire timeline (from early to late hours)
  if (windows.length < maxWindows) {
    const remainingSlots = maxWindows - windows.length;
    const usableSpan = Math.max(0, safeDuration - windowSeconds);
    for (let i = 0; i < remainingSlots && windows.length < maxWindows; i++) {
      const ratio = remainingSlots === 1 ? 0.5 : i / (remainingSlots - 1);
      const start = Math.max(0, Math.min(usableSpan, ratio * usableSpan));
      const end = Math.min(safeDuration, start + windowSeconds);
      const overlaps = windows.some(
        (w) => computeIntervalOverlapRatio(start, end, w.start, w.end) > 0.3
      );
      if (!overlaps) {
        windows.push({ start: Number(start.toFixed(2)), end: Number(end.toFixed(2)) });
      }
    }
  }

  return windows.sort((a, b) => a.start - b.start);
}

export function extractYouTubeVideoId(input: string): string | null {
  const trimmed = input.trim();
  if (!trimmed) return null;
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;

  try {
    const url = new URL(trimmed);
    const host = url.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'youtu.be') {
      const id = url.pathname.split('/').filter(Boolean)[0];
      return id && /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }
    if (host.endsWith('youtube.com')) {
      const vParam = url.searchParams.get('v');
      if (vParam && /^[a-zA-Z0-9_-]{11}$/.test(vParam)) return vParam;
      const parts = url.pathname.split('/').filter(Boolean);
      if (
        parts.length >= 2 &&
        (parts[0] === 'live' || parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'v')
      ) {
        return /^[a-zA-Z0-9_-]{11}$/.test(parts[1]) ? parts[1] : null;
      }
    }
  } catch {
    return null;
  }
  return null;
}

export function parseIsoDurationSeconds(iso: string): number {
  const match = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i.exec(iso.trim());
  if (!match) return 0;
  const hours = Number(match[1] ?? 0);
  const mins = Number(match[2] ?? 0);
  const secs = Number(match[3] ?? 0);
  return hours * 3600 + mins * 60 + secs;
}

export function formatTimestamp(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function formatSrtTimestamp(seconds: number): string {
  const safeMs = Math.max(0, Math.round(seconds * 1000));
  const hrs = Math.floor(safeMs / 3600000);
  const mins = Math.floor((safeMs % 3600000) / 60000);
  const secs = Math.floor((safeMs % 60000) / 1000);
  const ms = safeMs % 1000;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

export function formatAssTimestamp(seconds: number): string {
  const safeCs = Math.max(0, Math.round(seconds * 100));
  const hrs = Math.floor(safeCs / 360000);
  const mins = Math.floor((safeCs % 360000) / 6000);
  const secs = Math.floor((safeCs % 6000) / 100);
  const cs = safeCs % 100;
  return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

export function generateSrtContent(captions: CaptionCue[]): string {
  return captions
    .map((cue, idx) => {
      return `${idx + 1}\n${formatSrtTimestamp(cue.start)} --> ${formatSrtTimestamp(cue.end)}\n${cue.text}\n`;
    })
    .join('\n');
}

export function getTargetDimensions(aspectRatio: AspectRatio): { width: number; height: number } {
  switch (aspectRatio) {
    case '9:16':
      return { width: 1080, height: 1920 };
    case '16:9':
      return { width: 1920, height: 1080 };
    case '1:1':
      return { width: 1080, height: 1080 };
    case '4:5':
      return { width: 1080, height: 1350 };
  }
}

function escapeAssText(text: string): string {
  return text.replace(/\\/g, '\\\\').replace(/\{/g, '\\{').replace(/\}/g, '\\}').replace(/\r?\n/g, '\\N');
}

export function generateAssSubtitles(
  captions: CaptionCue[],
  style: CaptionStyleId,
  width: number,
  height: number
): string {
  if (style === 'none' || captions.length === 0) return '';

  const isVertical = height > width;
  const baseFontSize = isVertical ? Math.round(width * 0.048) : Math.round(height * 0.05);
  const marginV = isVertical ? Math.round(height * 0.11) : Math.round(height * 0.07);
  const marginH = Math.round(width * 0.06);

  let styleLine = '';
  switch (style) {
    case 'bold_kinetic':
      styleLine = `Style: Default,DejaVu Sans,${Math.round(baseFontSize * 1.15)},&H0018E5FF,&H00FFFFFF,&H00080B10,&H99000000,-1,0,0,0,100,100,0,0,1,4,2,2,${marginH},${marginH},${marginV},1`;
      break;
    case 'high_contrast_box':
      styleLine = `Style: Default,DejaVu Sans,${baseFontSize},&H00FFFFFF,&H00FFFFFF,&H000B0F17,&HC80B0F17,-1,0,0,0,100,100,0,0,3,12,0,2,${marginH},${marginH},${marginV},1`;
      break;
    case 'minimal_bottom':
      styleLine = `Style: Default,DejaVu Sans,${Math.round(baseFontSize * 0.85)},&H00F1F5F9,&H00F1F5F9,&H000B0F17,&H66000000,0,0,0,0,100,100,0,0,1,2,1,2,${marginH},${marginH},${Math.round(marginV * 0.65)},1`;
      break;
    case 'clean_editorial':
    default:
      styleLine = `Style: Default,DejaVu Sans,${baseFontSize},&H00FFFFFF,&H00FFFFFF,&H000B0F17,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,2,${marginH},${marginH},${marginV},1`;
      break;
  }

  const events = captions
    .map((cue) => {
      const text = style === 'bold_kinetic' ? cue.text.toUpperCase() : cue.text;
      return `Dialogue: 0,${formatAssTimestamp(cue.start)},${formatAssTimestamp(cue.end)},Default,,0,0,0,,${escapeAssText(text)}`;
    })
    .join('\n');

  return `[Script Info]
ScriptType: v4.00+
PlayResX: ${width}
PlayResY: ${height}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
${styleLine}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
${events}
`;
}

/**
 * Word-by-word karaoke captions — a faithful port of the proven pipeline's
 * build_ass: words are grouped in threes, and for each word's window one
 * Dialogue line is emitted with that word highlighted yellow and scaled to
 * 118% while the other words in the group stay white. Upper-cased, bold,
 * top-centred at the seam line (the game/face boundary for split layouts).
 * Returns '' when there are no word timings.
 */
export function generateKaraokeAss(
  words: WordCue[],
  width: number,
  height: number,
  seamY: number
): string {
  if (!words || words.length === 0) return '';
  const fontSize = 84; // matches the proven pipeline's delivered look at 1080 wide
  const head = `[Script Info]
ScriptType: v4.00+
PlayResX: ${width}
PlayResY: ${height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,DejaVu Sans,${fontSize},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,8,2,5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;
  const groups: WordCue[][] = [];
  let current: WordCue[] = [];
  for (const w of words) {
    if (current.length > 0 && (current.length >= 3 || w.start - current[current.length - 1].end > 0.7)) {
      groups.push(current);
      current = [];
    }
    current.push(w);
  }
  if (current.length > 0) groups.push(current);

  const lines: string[] = [];
  for (let gi = 0; gi < groups.length; gi++) {
    const g = groups[gi];
    const nextStart = gi + 1 < groups.length ? groups[gi + 1][0].start : 1e9;
    const texts = g.map((w) => escapeAssText(w.text.toUpperCase()));
    for (let wi = 0; wi < g.length; wi++) {
      const w = g[wi];
      let end = wi + 1 < g.length ? g[wi + 1].start : Math.min(w.end + 0.25, nextStart);
      if (end <= w.start) end = w.start + 0.15;
      const parts = texts.map((tx, j) =>
        j === wi ? `{\\1c&H00FFFF&\\fscx118\\fscy118}${tx}{\\r}` : tx
      );
      const body = `{\\pos(${Math.round(width / 2)},${Math.round(seamY)})}` + parts.join(' ');
      lines.push(`Dialogue: 0,${formatAssTimestamp(w.start)},${formatAssTimestamp(end)},Cap,,0,0,0,,${body}`);
    }
  }
  return head + lines.join('\n') + '\n';
}

export interface PromptBuildOptions {
  videoDuration: number;
  selectedCategory: VideoCategoryId;
  autoDetectCategory: boolean;
  autoDetectBestClips: boolean;
  numberOfClips: number;
  durationPreset: ClipDurationPreset;
  aspectRatio: AspectRatio;
  captionLanguage: string;
}

export function buildGeminiAnalysisPrompt(options: PromptBuildOptions): string {
  const {
    videoDuration,
    selectedCategory,
    autoDetectCategory,
    autoDetectBestClips,
    numberOfClips,
    durationPreset,
    aspectRatio,
    captionLanguage,
  } = options;

  const preset = DURATION_PRESETS[durationPreset];
  const minTarget =
    videoDuration < preset.minSeconds * 1.5
      ? Math.max(4, Math.round(videoDuration * 0.2))
      : preset.minSeconds;
  const maxTarget = Math.min(videoDuration, preset.maxSeconds);

  const categorySection =
    !autoDetectCategory && selectedCategory !== 'auto'
      ? `USER OVERRIDE CATEGORY: "${selectedCategory}" (${CATEGORY_PROFILES[selectedCategory].label}).
Apply this category's exact highlight criteria:
Detect: ${CATEGORY_PROFILES[selectedCategory].detectSignals.join('; ')}
Avoid: ${CATEGORY_PROFILES[selectedCategory].avoidSignals.join('; ')}`
      : `AUTOMATIC MULTI-CATEGORY DETECTION ENABLED:
Classify this video into one primary category and optional secondary categories from:
gaming, podcast, interview, reaction, commentary, documentary, educational, storytelling, news, entertainment, other.
Then apply that category's highlight rubric rigorously.`;

  const rubricGuide = Object.values(CATEGORY_PROFILES)
    .map(
      (p) =>
        `- ${p.id}: Detect [${p.detectSignals.slice(0, 3).join('; ')}] | Avoid [${p.avoidSignals[0]}] | Split gameplay allowed: ${p.allowSplitGameplayLayout}`
    )
    .join('\n');

  return `You are Klipz Ai's Universal Multi-Category Auto Clipping Engine.
Analyze BOTH the visual video frames AND the audio track of this video segment (duration: ${videoDuration.toFixed(2)} seconds).

${categorySection}

CATEGORY RUBRICS & LAYOUT RULES:
${rubricGuide}

WEBCAM & FRAMING DETECTION:
- Inspect the video frames to detect whether a streamer/creator webcam box is overlaid on the screen.
- Report "webcamPosition" as one of: "top_left", "top_right", "bottom_left", "bottom_right", "top_center", or "none" if no webcam overlay exists.
- If a podcast/interview shows two speakers side-by-side (left half + right half), recommend "dual_speaker" or "full_frame" (never "split_cam_gameplay").
- For gaming/reaction with a webcam overlay in 9:16, recommend "split_cam_gameplay" (streamer facecam on top, full gameplay on bottom).
- For documentaries, educational videos, commentary, and standalone footage, ALWAYS recommend "full_frame" so zero borders or text are cut off.

CLIP SELECTION RULES:
- Target number of clips: ${numberOfClips} (return up to ${numberOfClips + 2} distinct non-overlapping candidates if available, within [0, ${videoDuration.toFixed(2)}]).
- Auto Detect Best Clips mode: ${autoDetectBestClips ? 'ON — select the highest-retention standalone moments.' : 'ON — select chronological standout moments.'}
- Target duration per clip: ${minTarget}s to ${maxTarget}s (ideal around ${Math.min(preset.targetSeconds, videoDuration)}s).
- Target output aspect ratio: ${aspectRatio}.
- NEVER suggest "split_cam_gameplay" for podcasts, interviews, documentaries, educational, storytelling, news, or commentary.
- Never select repeated/overlapping highlights, incomplete sentences cut mid-thought, random low-value footage, or excessive dead silence.
- For gaming/GTA 6 footage: catch unexpected events, crashes, explosions, police chases, funny NPC moments, close calls, and visual action even when nobody is speaking.
- Captions: Generate accurate, punchy, time-synced captions in "${captionLanguage}" with timestamps relative to the start of each clip (starting at 0.0 up to clip duration). Break captions into short readable 2–6 word phrases (1.5–3.5s per cue).

Return strictly valid JSON matching the provided schema. Every timestamp must be in seconds within [0, ${videoDuration.toFixed(2)}].`;
}
