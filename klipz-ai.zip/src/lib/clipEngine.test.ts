import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildGeminiAnalysisPrompt,
  CATEGORY_PROFILES,
  computeWeightedClipScore,
  extractYouTubeVideoId,
  formatAssTimestamp,
  formatSrtTimestamp,
  formatTimestamp,
  generateAssSubtitles,
  generateSrtContent,
  parseIsoDurationSeconds,
  resolveLayoutForCategory,
  selectCandidateWindows,
  validateAndNormalizeClips,
  type RawHighlightCandidate,
} from './clipEngine.ts';

test('CATEGORY_PROFILES enforces non-split layout rules and zero-border-cutting defaults', () => {
  assert.equal(CATEGORY_PROFILES.podcast.allowSplitGameplayLayout, false);
  assert.equal(CATEGORY_PROFILES.documentary.allowSplitGameplayLayout, false);
  assert.equal(CATEGORY_PROFILES.interview.allowSplitGameplayLayout, false);
  assert.equal(CATEGORY_PROFILES.educational.allowSplitGameplayLayout, false);
  assert.equal(CATEGORY_PROFILES.gaming.allowSplitGameplayLayout, true);

  // Podcasts never get split_cam_gameplay and default to full_frame or dual_speaker so edges/faces aren't cut
  assert.equal(
    resolveLayoutForCategory('podcast', '9:16', 'split_cam_gameplay'),
    'full_frame'
  );
  assert.equal(
    resolveLayoutForCategory('podcast', '9:16', 'dual_speaker'),
    'dual_speaker'
  );
  assert.equal(
    resolveLayoutForCategory('documentary', '9:16', 'split_cam_gameplay'),
    'full_frame'
  );
  // Gaming 9:16 uses Streamer Top + Gameplay Bottom when webcam is detected, else full_frame
  assert.equal(
    resolveLayoutForCategory('gaming', '9:16', 'split_cam_gameplay', 'auto', 'top_right'),
    'split_cam_gameplay'
  );
  assert.equal(
    resolveLayoutForCategory('gaming', '9:16', 'split_cam_gameplay', 'auto', 'none'),
    'full_frame'
  );
  assert.equal(
    resolveLayoutForCategory('podcast', '16:9', 'vertical_crop'),
    'full_frame'
  );
});

test('computeWeightedClipScore weights visual action higher for gaming and context higher for podcasts', () => {
  const visualHeavy = {
    hookStrength: 70,
    contextCompleteness: 40,
    emotionalIntensity: 75,
    valueScore: 50,
    visualInterest: 98,
    audioInterest: 90,
    standaloneQuality: 65,
    retentionPotential: 80,
  };
  const contextHeavy = {
    hookStrength: 80,
    contextCompleteness: 96,
    emotionalIntensity: 80,
    valueScore: 95,
    visualInterest: 35,
    audioInterest: 60,
    standaloneQuality: 94,
    retentionPotential: 85,
  };

  const gamingVisualScore = computeWeightedClipScore(visualHeavy, 'gaming');
  const podcastVisualScore = computeWeightedClipScore(visualHeavy, 'podcast');
  assert.ok(gamingVisualScore > podcastVisualScore);

  const podcastContextScore = computeWeightedClipScore(contextHeavy, 'podcast');
  const gamingContextScore = computeWeightedClipScore(contextHeavy, 'gaming');
  assert.ok(podcastContextScore > gamingContextScore);
});

test('validateAndNormalizeClips deduplicates overlapping segments, clamps bounds, aligns captions, and preserves webcamPosition', () => {
  const candidates: RawHighlightCandidate[] = [
    {
      title: 'Top Police Chase Escape',
      startTime: 10,
      endTime: 48,
      detectedCategory: 'gaming',
      reason: 'High-speed escape with near miss crash and explosion.',
      recommendedLayout: 'split_cam_gameplay',
      webcamPosition: 'top_right',
      scores: {
        hookStrength: 92,
        contextCompleteness: 85,
        emotionalIntensity: 90,
        valueScore: 80,
        visualInterest: 96,
        audioInterest: 88,
        standaloneQuality: 90,
        retentionPotential: 94,
      },
      captions: [
        { start: 10.5, end: 13.0, text: 'No way we survive this!' },
        { start: 13.2, end: 16.0, text: 'Watch the chopper!' },
      ],
    },
    {
      title: 'Duplicate Police Chase Segment',
      startTime: 14,
      endTime: 45,
      detectedCategory: 'gaming',
      reason: 'Overlapping segment',
      scores: {
        hookStrength: 60,
        contextCompleteness: 60,
        emotionalIntensity: 60,
        valueScore: 60,
        visualInterest: 60,
        audioInterest: 60,
        standaloneQuality: 60,
        retentionPotential: 60,
      },
      captions: [],
    },
    {
      title: 'Micro Fragment',
      startTime: 60,
      endTime: 62,
      reason: 'Brief transition fragment',
      scores: {
        hookStrength: 90,
        contextCompleteness: 90,
        emotionalIntensity: 90,
        valueScore: 90,
        visualInterest: 90,
        audioInterest: 90,
        standaloneQuality: 90,
        retentionPotential: 90,
      },
      captions: [],
    },
    {
      title: 'Second Distinct Stunt',
      startTime: 80,
      endTime: 125,
      detectedCategory: 'gaming',
      reason: 'Clean jump landing after pursuit.',
      scores: {
        hookStrength: 86,
        contextCompleteness: 82,
        emotionalIntensity: 84,
        valueScore: 78,
        visualInterest: 90,
        audioInterest: 82,
        standaloneQuality: 85,
        retentionPotential: 88,
      },
      captions: [{ start: 0.2, end: 2.8, text: 'Stunt jump landed clean.' }],
    },
  ];

  const clips = validateAndNormalizeClips(candidates, {
    videoDuration: 120,
    selectedCategory: 'auto',
    detectedPrimaryCategory: 'gaming',
    maxClips: 4,
    durationPreset: 'balanced',
    aspectRatio: '9:16',
    captionStyle: 'clean_editorial',
    captionLanguage: 'English',
    detectedWebcamPosition: 'top_right',
  });

  assert.equal(clips.length, 2);
  assert.equal(clips[0].title, 'Top Police Chase Escape');
  assert.equal(clips[0].layoutMode, 'split_cam_gameplay');
  assert.equal(clips[0].webcamPosition, 'top_right');
  assert.equal(clips[0].captions[0].start, 0.5);
  assert.equal(clips[0].captions[0].end, 3.0);
  assert.equal(clips[1].endTime, 120);
  assert.equal(clips[1].duration, 40);
});

test('10-hour timeline window selector and YouTube URL/ISO duration parsers work accurately', () => {
  // 10-hour (36,000s) stream with peaks at 1.5h and 8.5h
  const windows = selectCandidateWindows(36_000, {
    windowSeconds: 120,
    maxWindows: 6,
    activityPeaks: [5400, 30600],
  });
  assert.equal(windows.length, 6);
  assert.ok(windows.some((w) => w.start <= 5400 && w.end >= 5400));
  assert.ok(windows.some((w) => w.start <= 30600 && w.end >= 30600));
  assert.ok(windows[0].start < 3600);
  assert.ok(windows[windows.length - 1].end > 32000);

  assert.equal(extractYouTubeVideoId('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), 'dQw4w9WgXcQ');
  assert.equal(extractYouTubeVideoId('https://youtu.be/dQw4w9WgXcQ?t=42'), 'dQw4w9WgXcQ');
  assert.equal(extractYouTubeVideoId('https://www.youtube.com/live/jfKfPfyJRdk?feature=share'), 'jfKfPfyJRdk');
  assert.equal(extractYouTubeVideoId('https://example.com/not-youtube'), null);

  assert.equal(parseIsoDurationSeconds('PT10H14M20S'), 36860);
  assert.equal(parseIsoDurationSeconds('PT45M10S'), 2710);
});

test('timestamp and subtitle generators produce valid SRT and ASS outputs', () => {
  assert.equal(formatTimestamp(65), '01:05');
  assert.equal(formatTimestamp(3665), '01:01:05');
  assert.equal(formatSrtTimestamp(12.345), '00:00:12,345');
  assert.equal(formatAssTimestamp(62.5), '0:01:02.50');

  const srt = generateSrtContent([
    { start: 0, end: 2.5, text: 'First line' },
    { start: 2.5, end: 5.0, text: 'Second line' },
  ]);
  assert.ok(srt.includes('00:00:00,000 --> 00:00:02,500'));
  assert.ok(srt.includes('Second line'));

  const ass = generateAssSubtitles(
    [{ start: 0, end: 2, text: 'Hello world' }],
    'bold_kinetic',
    1080,
    1920
  );
  assert.ok(ass.includes('PlayResX: 1080'));
  assert.ok(ass.includes('HELLO WORLD'));
  assert.equal(generateAssSubtitles([{ start: 0, end: 2, text: 'x' }], 'none', 1080, 1920), '');
});

test('buildGeminiAnalysisPrompt embeds category override vs auto-detect and webcam framing rules', () => {
  const autoPrompt = buildGeminiAnalysisPrompt({
    videoDuration: 180,
    selectedCategory: 'auto',
    autoDetectCategory: true,
    autoDetectBestClips: true,
    numberOfClips: 4,
    durationPreset: 'balanced',
    aspectRatio: '9:16',
    captionLanguage: 'Spanish',
  });
  assert.ok(autoPrompt.includes('AUTOMATIC MULTI-CATEGORY DETECTION ENABLED'));
  assert.ok(autoPrompt.includes('WEBCAM & FRAMING DETECTION'));
  assert.ok(autoPrompt.includes('Spanish'));

  const podcastPrompt = buildGeminiAnalysisPrompt({
    videoDuration: 180,
    selectedCategory: 'podcast',
    autoDetectCategory: false,
    autoDetectBestClips: true,
    numberOfClips: 3,
    durationPreset: 'deep',
    aspectRatio: '16:9',
    captionLanguage: 'English',
  });
  assert.ok(podcastPrompt.includes('USER OVERRIDE CATEGORY: "podcast"'));
  assert.ok(podcastPrompt.includes('NEVER suggest "split_cam_gameplay" for podcasts'));
});
