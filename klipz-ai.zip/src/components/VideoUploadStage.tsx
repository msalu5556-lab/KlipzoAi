import { useState } from 'react';
import { ExternalLink, Film, Link2, RefreshCw, Upload } from 'lucide-react';
import { formatTimestamp } from '../lib/clipEngine';
import type { UploadedVideoInfo } from '../types/studio';

interface VideoUploadStageProps {
  video: UploadedVideoInfo | null;
  isUploading: boolean;
  isImportingYoutube: boolean;
  isGeneratingSample: boolean;
  onSelectFile: (file: File) => void;
  onImportYoutubeUrl: (url: string) => void;
  onLoadSample: (kind: 'gaming' | 'podcast' | 'educational') => void;
  onTriggerUpload: () => void;
  onClearVideo: () => void;
  onRunAutoClip: () => void;
  isAnalyzing: boolean;
}

export function VideoUploadStage({
  video,
  isUploading,
  isImportingYoutube,
  isGeneratingSample,
  onSelectFile,
  onImportYoutubeUrl,
  onLoadSample,
  onTriggerUpload,
  onClearVideo,
  onRunAutoClip,
  isAnalyzing,
}: VideoUploadStageProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [ingestMode, setIngestMode] = useState<'upload' | 'youtube'>('upload');
  const [youtubeUrl, setYoutubeUrl] = useState('');

  const handleSubmitYoutube = (e: React.FormEvent) => {
    e.preventDefault();
    if (!youtubeUrl.trim() || isImportingYoutube || isUploading) return;
    onImportYoutubeUrl(youtubeUrl.trim());
  };

  if (video) {
    const isYouTube = video.sourceType === 'youtube';
    const sizeMb =
      video.probe.sizeBytes > 0
        ? `${(video.probe.sizeBytes / (1024 * 1024)).toFixed(1)} MB`
        : null;

    return (
      <section
        aria-label="Source video preview"
        className="rounded-xl border border-slate-800 bg-[#121823] p-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="min-w-0">
            <h2 className="truncate font-display text-base font-semibold text-slate-50">
              {video.originalName}
            </h2>
            <p className="mt-1 font-mono text-xs text-slate-400 tabular-nums">
              {formatTimestamp(video.probe.duration)}
              <span aria-hidden="true"> · </span>
              {video.probe.width}x{video.probe.height}
              <span aria-hidden="true"> · </span>
              {video.probe.fps} fps
              {isYouTube ? (
                <>
                  <span aria-hidden="true"> · </span>
                  {video.isLive ? 'YouTube Live Stream' : 'YouTube VOD'}
                  {video.youtubeChannel && (
                    <>
                      <span aria-hidden="true"> · </span>
                      {video.youtubeChannel}
                    </>
                  )}
                  {typeof video.transcriptCuesCount === 'number' && video.transcriptCuesCount > 0 && (
                    <>
                      <span aria-hidden="true"> · </span>
                      {video.transcriptCuesCount} transcript cues
                    </>
                  )}
                </>
              ) : (
                <>
                  <span aria-hidden="true"> · </span>
                  {video.probe.hasAudio ? 'Audio + Video' : 'Video Only'}
                  {sizeMb && (
                    <>
                      <span aria-hidden="true"> · </span>
                      {sizeMb}
                    </>
                  )}
                </>
              )}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onClearVideo}
              disabled={isUploading || isImportingYoutube || isAnalyzing}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0B0F17] px-3.5 py-2 text-xs font-medium text-slate-200 whitespace-nowrap transition-colors duration-150 hover:border-slate-600 hover:text-white disabled:opacity-50"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Change Source</span>
            </button>
            <button
              type="button"
              onClick={onRunAutoClip}
              disabled={isAnalyzing}
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors duration-150 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500"
            >
              <span>{isAnalyzing ? 'Processing...' : 'Auto Clip Now'}</span>
            </button>
          </div>
        </div>

        {isYouTube ? (
          <div className="mt-4 overflow-hidden rounded-lg border border-slate-800 bg-black">
            <div className="relative mx-auto flex max-h-[340px] aspect-video w-full items-center justify-center bg-[#06090F]">
              {video.thumbnailUrl ? (
                <img
                  src={video.thumbnailUrl}
                  alt={video.originalName}
                  className="h-full w-full object-contain"
                />
              ) : (
                <Film className="h-10 w-10 text-slate-600" aria-hidden="true" />
              )}
              {video.youtubeUrl && (
                <a
                  href={video.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="absolute right-3 bottom-3 inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-black/80 px-3 py-1.5 text-xs font-medium text-slate-100 hover:border-blue-500"
                >
                  <span>Open on YouTube</span>
                  <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              )}
            </div>
            {video.streamWarning && (
              <p className="border-t border-slate-800 bg-[#0E1420] px-4 py-2.5 text-xs text-amber-200/90">
                {video.streamWarning}
              </p>
            )}
          </div>
        ) : (
          <div className="mt-4 overflow-hidden rounded-lg border border-slate-800 bg-black">
            <video
              key={video.previewUrl}
              src={video.previewUrl}
              controls
              preload="metadata"
              className="mx-auto max-h-[340px] w-full object-contain"
            />
          </div>
        )}
      </section>
    );
  }

  return (
    <section
      aria-label="Upload or import video"
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setIsDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) onSelectFile(file);
      }}
      className={`rounded-xl border-2 border-dashed p-8 sm:p-10 text-center transition-colors duration-150 ${
        isDragging
          ? 'border-blue-500 bg-blue-950/20'
          : 'border-slate-800 bg-[#121823]'
      }`}
    >
      <div className="mx-auto flex max-w-xl flex-col items-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-700/80 bg-[#0B0F17] text-blue-400">
          {isUploading || isImportingYoutube ? (
            <RefreshCw className="h-5 w-5 animate-spin" aria-hidden="true" />
          ) : ingestMode === 'youtube' ? (
            <Link2 className="h-5 w-5" aria-hidden="true" />
          ) : (
            <Film className="h-5 w-5" aria-hidden="true" />
          )}
        </div>

        <h1 className="mt-4 font-display text-2xl font-bold tracking-tight text-slate-50">
          Universal Multi-Category Auto Clipping
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-400">
          Upload files or import YouTube VODs and live streams up to 10 hours long. Klipz Ai
          auto-detects the category, frames streamer facecams above uncropped gameplay, and renders
          captioned clips.
        </p>

        {/* Source Switcher */}
        <div
          role="tablist"
          aria-label="Video source mode"
          className="mt-5 inline-flex rounded-lg border border-slate-800 bg-[#0B0F17] p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={ingestMode === 'upload'}
            onClick={() => setIngestMode('upload')}
            className={`rounded-md px-3.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
              ingestMode === 'upload'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            Upload Video File (Up to 10h)
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={ingestMode === 'youtube'}
            onClick={() => setIngestMode('youtube')}
            className={`rounded-md px-3.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
              ingestMode === 'youtube'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            YouTube / Live Stream URL
          </button>
        </div>

        {ingestMode === 'upload' ? (
          <>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onTriggerUpload}
                disabled={isUploading || isGeneratingSample}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white whitespace-nowrap transition-colors duration-150 hover:bg-blue-500 disabled:opacity-50"
              >
                <Upload className="h-4 w-4" aria-hidden="true" />
                <span>{isUploading ? 'Uploading & Probing...' : 'Choose Video File'}</span>
              </button>
            </div>
            <p className="mt-3 font-mono text-xs text-slate-500">
              MP4 · MOV · WebM · MKV · Chunked upload up to 10 hours
            </p>
          </>
        ) : (
          <form onSubmit={handleSubmitYoutube} className="mt-5 w-full max-w-lg">
            <div className="flex flex-col gap-2 sm:flex-row">
              <label htmlFor="youtube-url-input" className="sr-only">
                YouTube video or live stream URL
              </label>
              <input
                id="youtube-url-input"
                type="url"
                required
                placeholder="https://www.youtube.com/watch?v=... or /live/..."
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                className="flex-1 rounded-lg border border-slate-700 bg-[#0B0F17] px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isImportingYoutube || !youtubeUrl.trim()}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-500 disabled:opacity-50"
              >
                <Link2 className="h-4 w-4" aria-hidden="true" />
                <span>{isImportingYoutube ? 'Fetching Stream...' : 'Load YouTube URL'}</span>
              </button>
            </div>
            <p className="mt-2.5 font-mono text-xs text-slate-500">
              Supports VODs &amp; 10h+ Live Streams · Heatmap + Transcript + Stream Extraction
            </p>
          </form>
        )}

        <div className="mt-7 w-full max-w-[720px] border-t border-slate-800 pt-5">
          <p className="text-xs font-medium text-slate-400">
            Or load a synthesized pipeline test recording:
          </p>
          <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            <button
              type="button"
              onClick={() => onLoadSample('gaming')}
              disabled={isGeneratingSample || isUploading || isImportingYoutube}
              className="rounded-lg border border-slate-700/80 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-300 whitespace-nowrap transition-colors hover:border-slate-600 hover:text-white disabled:opacity-50"
            >
              GTA-Style Gameplay Sample
            </button>
            <button
              type="button"
              onClick={() => onLoadSample('podcast')}
              disabled={isGeneratingSample || isUploading || isImportingYoutube}
              className="rounded-lg border border-slate-700/80 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-300 whitespace-nowrap transition-colors hover:border-slate-600 hover:text-white disabled:opacity-50"
            >
              Podcast Debate Sample
            </button>
            <button
              type="button"
              onClick={() => onLoadSample('educational')}
              disabled={isGeneratingSample || isUploading || isImportingYoutube}
              className="rounded-lg border border-slate-700/80 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-300 whitespace-nowrap transition-colors hover:border-slate-600 hover:text-white disabled:opacity-50"
            >
              Educational Explainer Sample
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
