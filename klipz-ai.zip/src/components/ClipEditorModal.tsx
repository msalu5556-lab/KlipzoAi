import { useState } from 'react';
import { X } from 'lucide-react';
import {
  CAPTION_STYLES,
  CATEGORY_PROFILES,
  LAYOUT_LABELS,
  resolveLayoutForCategory,
  WEBCAM_POSITION_LABELS,
  type AspectRatio,
  type CaptionCue,
  type CaptionStyleId,
  type ClipLayoutMode,
  type DetectedWebcamPosition,
  type NormalizedClip,
} from '../lib/clipEngine';

interface ClipEditorModalProps {
  clip: NormalizedClip;
  videoDuration: number;
  onClose: () => void;
  onSaved: (updated: NormalizedClip) => void;
}

const WEBCAM_OPTIONS: DetectedWebcamPosition[] = [
  'top_right',
  'top_left',
  'bottom_right',
  'bottom_left',
  'top_center',
  'none',
];

export function ClipEditorModal({
  clip,
  videoDuration,
  onClose,
  onSaved,
}: ClipEditorModalProps) {
  const [title, setTitle] = useState(clip.title);
  const [startTime, setStartTime] = useState(clip.startTime);
  const [endTime, setEndTime] = useState(clip.endTime);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(clip.aspectRatio);
  const [layoutMode, setLayoutMode] = useState<ClipLayoutMode>(clip.layoutMode);
  const [webcamPosition, setWebcamPosition] = useState<DetectedWebcamPosition>(
    clip.webcamPosition ?? 'none'
  );
  const [captionStyle, setCaptionStyle] = useState<CaptionStyleId>(clip.captionStyle);
  const [captions, setCaptions] = useState<CaptionCue[]>(clip.captions);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const profile = CATEGORY_PROFILES[clip.detectedCategory];
  const allowedLayouts: ClipLayoutMode[] = profile.allowSplitGameplayLayout
    ? ['full_frame', 'split_cam_gameplay', 'vertical_crop', 'picture_in_picture']
    : ['full_frame', 'dual_speaker', 'speaker_focus', 'vertical_crop'];

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (endTime <= startTime + 1) {
      setError('End time must be at least 1 second after start time.');
      return;
    }

    setIsSaving(true);
    try {
      const resolvedLayout = resolveLayoutForCategory(
        clip.detectedCategory,
        aspectRatio,
        layoutMode,
        layoutMode,
        webcamPosition
      );

      const response = await fetch(
        `/api/clips/${encodeURIComponent(clip.id)}/render`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title,
            startTime,
            endTime,
            aspectRatio,
            layoutMode: resolvedLayout,
            webcamPosition,
            captionStyle,
            captions,
            category: clip.detectedCategory,
          }),
        }
      );

      const rawText = await response.text();
      let data: { clip?: NormalizedClip; error?: string } = {};
      try {
        data = JSON.parse(rawText) as { clip?: NormalizedClip; error?: string };
      } catch {
        throw new Error(
          `Server returned HTTP ${response.status} while re-rendering clip.`
        );
      }
      if (!response.ok || !data.clip) {
        throw new Error(data.error || 'Failed to re-render clip.');
      }
      onSaved(data.clip);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update clip.');
    } finally {
      setIsSaving(false);
    }
  };

  const updateCaptionText = (index: number, text: string) => {
    setCaptions((prev) =>
      prev.map((c, idx) => (idx === index ? { ...c, text } : c))
    );
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="clip-editor-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-slate-800 bg-[#121823] p-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2
              id="clip-editor-title"
              className="font-display text-lg font-semibold text-slate-50"
            >
              Edit &amp; Re-Render Clip
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              {profile.label}
              <span aria-hidden="true"> · </span>
              Source duration {videoDuration.toFixed(1)}s
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close clip editor"
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-5 space-y-5">
          <div>
            <label
              htmlFor="edit-clip-title"
              className="block text-xs font-medium text-slate-300"
            >
              Highlight Title
            </label>
            <input
              id="edit-clip-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="edit-start-time"
                className="block text-xs font-medium text-slate-300"
              >
                Start Time (seconds)
              </label>
              <input
                id="edit-start-time"
                type="number"
                step="0.1"
                min={0}
                max={Math.max(0, videoDuration - 1)}
                value={startTime}
                onChange={(e) => setStartTime(Number(e.target.value))}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 font-mono text-sm text-slate-100 tabular-nums focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="edit-end-time"
                className="block text-xs font-medium text-slate-300"
              >
                End Time (seconds)
              </label>
              <input
                id="edit-end-time"
                type="number"
                step="0.1"
                min={1}
                max={videoDuration}
                value={endTime}
                onChange={(e) => setEndTime(Number(e.target.value))}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 font-mono text-sm text-slate-100 tabular-nums focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="edit-aspect-ratio"
                className="block text-xs font-medium text-slate-300"
              >
                Aspect Ratio
              </label>
              <select
                id="edit-aspect-ratio"
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
              >
                <option value="9:16">9:16 Vertical</option>
                <option value="16:9">16:9 Landscape</option>
                <option value="4:5">4:5 Portrait</option>
                <option value="1:1">1:1 Square</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="edit-layout-mode"
                className="block text-xs font-medium text-slate-300"
              >
                Content Layout
              </label>
              <select
                id="edit-layout-mode"
                value={layoutMode}
                onChange={(e) => setLayoutMode(e.target.value as ClipLayoutMode)}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
              >
                {allowedLayouts.map((mode) => (
                  <option key={mode} value={mode}>
                    {LAYOUT_LABELS[mode]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="edit-webcam-position"
                className="block text-xs font-medium text-slate-300"
              >
                Streamer Webcam Corner
              </label>
              <select
                id="edit-webcam-position"
                value={webcamPosition}
                onChange={(e) => setWebcamPosition(e.target.value as DetectedWebcamPosition)}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
              >
                {WEBCAM_OPTIONS.map((pos) => (
                  <option key={pos} value={pos}>
                    {WEBCAM_POSITION_LABELS[pos]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="edit-caption-style"
                className="block text-xs font-medium text-slate-300"
              >
                Caption Style
              </label>
              <select
                id="edit-caption-style"
                value={captionStyle}
                onChange={(e) => setCaptionStyle(e.target.value as CaptionStyleId)}
                className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
              >
                {CAPTION_STYLES.map((style) => (
                  <option key={style.id} value={style.id}>
                    {style.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {captions.length > 0 && (
            <div>
              <span className="block text-xs font-medium text-slate-300">
                Edit Captions
              </span>
              <div className="mt-2 max-h-48 space-y-2 overflow-y-auto pr-1">
                {captions.map((cue, idx) => (
                  <div key={`${idx}-${cue.start}`} className="flex items-center gap-2">
                    <span className="w-24 font-mono text-xs text-slate-500 tabular-nums shrink-0">
                      {cue.start.toFixed(1)}s–{cue.end.toFixed(1)}s
                    </span>
                    <input
                      type="text"
                      aria-label={`Caption cue ${idx + 1}`}
                      value={cue.text}
                      onChange={(e) => updateCaptionText(idx, e.target.value)}
                      className="flex-1 rounded-lg border border-slate-700 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && (
            <p role="alert" className="text-xs font-medium text-red-400">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-3 border-t border-slate-800 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-[#0B0F17] px-4 py-2 text-xs font-medium text-slate-300 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500 disabled:opacity-50"
            >
              {isSaving ? 'Rendering MP4...' : 'Apply & Re-Render'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
