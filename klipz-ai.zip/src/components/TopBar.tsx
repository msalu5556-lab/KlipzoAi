import { Upload } from 'lucide-react';
import type { ActiveTab } from '../types/studio';

interface TopBarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onTriggerUpload: () => void;
  clipCount: number;
}

export function TopBar({
  activeTab,
  onTabChange,
  onTriggerUpload,
  clipCount,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800/90 bg-[#0B0F17]/95 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between gap-8 px-6">
        <a
          href="#workspace"
          onClick={(e) => {
            e.preventDefault();
            onTabChange('workspace');
          }}
          className="font-display text-lg font-bold tracking-tight text-slate-50 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500"
        >
          Klipz Ai
        </a>

        <nav
          aria-label="Primary studio navigation"
          className="hidden md:flex items-center gap-6"
        >
          <button
            type="button"
            onClick={() => onTabChange('workspace')}
            className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500 ${
              activeTab === 'workspace'
                ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            Auto Clip
          </button>
          <button
            type="button"
            onClick={() => onTabChange('library')}
            className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500 ${
              activeTab === 'library'
                ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            Clip Library ({clipCount})
          </button>
          <button
            type="button"
            onClick={() => onTabChange('categories')}
            className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500 ${
              activeTab === 'categories'
                ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            Category Engine
          </button>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onTriggerUpload}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-blue-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400"
          >
            <Upload className="h-4 w-4" aria-hidden="true" />
            <span>Upload Video</span>
          </button>
        </div>
      </div>
    </header>
  );
}
