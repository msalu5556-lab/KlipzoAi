import { useMemo, useState } from 'react';
import { ChevronDown, ChevronUp, Download, FileText, Film, SlidersHorizontal } from 'lucide-react';
import {
  CATEGORY_PROFILES,
  formatTimestamp,
  LAYOUT_LABELS,
  WEBCAM_POSITION_LABELS,
  type NormalizedClip,
} from '../lib/clipEngine';

interface ClipCardProps {
  clip: NormalizedClip;
  onEdit: (clip: NormalizedClip) => void;
}

const SCORE_LABELS: Array<{ key: keyof NormalizedClip['scores']; label: string }> = [
  { key: 'hookStrength', label: 'Hook Strength' },
  { key: 'contextCompleteness', label: 'Context Completeness' },
  { key: 'emotionalIntensity', label: 'Emotional Intensity' },
  { key: 'valueScore', label: 'Entertainment / Value' },
  { key: 'visualInterest', label: 'Visual Interest' },
  { key: 'audioInterest', label: 'Audio Interest' },
  { key: 'standaloneQuality', label: 'Standalone Quality' },
  { key: 'retentionPotential', label: 'Audience Retention' },
];

export function ClipCard({ clip, onEdit }: ClipCardProps) {
  const [currentTime, setCurrentTime] = useState(0);
  const [showScores, setShowScores] = useState(false);

  const activeCaption = useMemo(() => {
    return clip.captions.find(
      (c) => currentTime >= c.start && currentTime <= c.end
    );
  }, [clip.captions, currentTime]);

  const categoryLabel =
    CATEGORY_PROFILES[clip.detectedCategory]?.label ?? 'Mixed Content';

  const aspectContainerClass =
    clip.aspectRatio === '9:16'
      ? 'aspect-[9/16] max-h-[380px]'
      : clip.aspectRatio === '4:5'
        ? 'aspect-[4/5] max-h-[360px]'
        : clip.aspectRatio === '1:1'
          ? 'aspect-square max-h-[340px]'
          : 'aspect-video max-h-[260px]';

  return (
    <article
      data-testid="generated-clip-card"
      className="flex flex-col rounded-xl border border-slate-800 bg-[#121823] overflow-hidden"
    >
      {/* Video Preview Stage */}
      <div className="relative flex items-center justify-center bg-black px-4 pt-4 pb-3 border-b border-slate-800/80">
        {clip.renderUrl ? (
          <div className={`relative w-full mx-auto overflow-hidden rounded-lg bg-[#05070B] ${aspectContainerClass}`}>
            <video
              key={clip.renderUrl}
              src={clip.renderUrl}
              controls
              preload="metadata"
              onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
              className="h-full w-full object-contain"
            />
            {activeCaption && (
              <div className="pointer-events-none absolute inset-x-3 bottom-11 flex justify-center">
                <p className="rounded bg-black/75 px-2.5 py-1 text-center text-xs font-medium text-white shadow">
                  {activeCaption.text}
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex w-full flex-col items-center justify-center rounded-lg bg-[#05070B] px-6 py-10 text-center">
            <Film className="h-7 w-7 text-slate-600" aria-hidden="true" />
            <p className="mt-2 text-xs font-medium text-slate-300">
              AI Highlight &amp; SRT Captions Ready
            </p>
            <p className="mt-1 max-w-xs text-[11px] text-slate-500">
              Direct MP4 preview unavailable for stream-restricted YouTube URLs. Download SRT or
              upload source video for MP4 render.
            </p>
          </div>
        )}
      </div>

      {/* Clip Details */}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs font-medium text-blue-400">
              {categoryLabel}
              <span aria-hidden="true"> · </span>
              <span className="text-slate-400">{LAYOUT_LABELS[clip.layoutMode]}</span>
              {clip.layoutMode === 'split_cam_gameplay' && clip.webcamPosition !== 'none' && (
                <>
                  <span aria-hidden="true"> · </span>
                  <span className="text-slate-400">
                    {WEBCAM_POSITION_LABELS[clip.webcamPosition]}
                  </span>
                </>
              )}
            </p>
            <h3 className="mt-1 font-display text-base font-semibold leading-snug text-slate-50">
              {clip.index}. {clip.title}
            </h3>
          </div>
          <div className="text-right shrink-0">
            <span className="font-mono text-lg font-bold text-slate-50 tabular-nums">
              {clip.overallScore}
            </span>
            <span className="font-mono text-xs text-slate-500">/100</span>
          </div>
        </div>

        <p className="mt-2 font-mono text-xs text-slate-400 tabular-nums">
          {formatTimestamp(clip.startTime)} – {formatTimestamp(clip.endTime)}
          <span aria-hidden="true"> · </span>
          {clip.duration.toFixed(1)}s
          <span aria-hidden="true"> · </span>
          {clip.aspectRatio}
          <span aria-hidden="true"> · </span>
          {clip.captionLanguage}
        </p>

        <p className="mt-3 text-sm leading-relaxed text-slate-300">
          {clip.reason}
        </p>

        {/* Expandable 8-Factor Score Breakdown */}
        <div className="mt-4 border-t border-slate-800/80 pt-3">
          <button
            type="button"
            aria-expanded={showScores}
            onClick={() => setShowScores((prev) => !prev)}
            className="flex w-full items-center justify-between text-xs font-medium text-slate-400 hover:text-slate-200"
          >
            <span>AI Scoring Breakdown</span>
            {showScores ? (
              <ChevronUp className="h-3.5 w-3.5" aria-hidden="true" />
            ) : (
              <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
            )}
          </button>

          {showScores && (
            <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
              {SCORE_LABELS.map((item) => (
                <div key={item.key} className="flex items-center justify-between">
                  <dt className="text-slate-400">{item.label}</dt>
                  <dd className="font-mono font-medium text-slate-200 tabular-nums">
                    {clip.scores[item.key]}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        {/* Captions Snippet */}
        {clip.captions.length > 0 && (
          <div className="mt-3 border-t border-slate-800/80 pt-3">
            <p className="text-xs font-medium text-slate-400">
              Auto Captions ({clip.captions.length} cues)
            </p>
            <div className="mt-2 max-h-24 space-y-1 overflow-y-auto pr-1 text-xs">
              {clip.captions.map((cue, idx) => (
                <div key={`${idx}-${cue.start}`} className="flex gap-2.5 text-slate-300">
                  <span className="font-mono text-slate-500 tabular-nums shrink-0">
                    {formatTimestamp(cue.start)}
                  </span>
                  <span>{cue.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="mt-5 flex flex-wrap items-center gap-2.5 border-t border-slate-800 pt-4">
          {clip.renderUrl && (
            <button
              type="button"
              onClick={() => onEdit(clip)}
              aria-label={`Edit clip ${clip.title}`}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-200 whitespace-nowrap transition-colors hover:border-slate-600 hover:text-white"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Edit Clip</span>
            </button>
          )}

          {clip.renderUrl && (
            <a
              href={`${clip.renderUrl}?download=1`}
              download
              aria-label={`Download MP4 for ${clip.title}`}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-500"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Download MP4</span>
            </a>
          )}

          {clip.srtUrl && (
            <a
              href={clip.srtUrl}
              download
              aria-label={`Download SRT captions for ${clip.title}`}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-300 whitespace-nowrap transition-colors hover:border-slate-600 hover:text-white"
            >
              <FileText className="h-3.5 w-3.5" aria-hidden="true" />
              <span>SRT</span>
            </a>
          )}
        </div>
      </div>
    </article>
  );
}
