import { Sparkles } from 'lucide-react';
import {
  CAPTION_LANGUAGES,
  CAPTION_STYLES,
  CATEGORY_LIST,
  DURATION_PRESETS,
  WEBCAM_POSITION_LABELS,
  type AspectRatio,
  type CaptionStyleId,
  type ClipDurationPreset,
  type LayoutPreference,
  type VideoCategoryId,
  type WebcamPosition,
} from '../lib/clipEngine';
import type { AutoClipSettings } from '../types/studio';

interface AutoClipSidebarProps {
  settings: AutoClipSettings;
  onChange: (next: AutoClipSettings) => void;
  onRunAutoClip: () => void;
  hasVideo: boolean;
  isAnalyzing: boolean;
}

const ASPECT_RATIOS: Array<{ id: AspectRatio; label: string }> = [
  { id: '9:16', label: '9:16 Vertical' },
  { id: '16:9', label: '16:9 Wide' },
  { id: '4:5', label: '4:5 Portrait' },
  { id: '1:1', label: '1:1 Square' },
];

const LAYOUT_PREFERENCES: Array<{ id: LayoutPreference; label: string }> = [
  { id: 'auto', label: 'Auto (Category-Aware)' },
  { id: 'full_frame', label: 'Exact Full Frame (No Cut)' },
  { id: 'split_cam_gameplay', label: 'Streamer Top + Gameplay' },
  { id: 'dual_speaker', label: 'Dual Speaker Split' },
  { id: 'vertical_crop', label: 'Smart Center Crop' },
];

export function AutoClipSidebar({
  settings,
  onChange,
  onRunAutoClip,
  hasVideo,
  isAnalyzing,
}: AutoClipSidebarProps) {
  const update = <K extends keyof AutoClipSettings>(
    key: K,
    value: AutoClipSettings[K]
  ) => {
    onChange({ ...settings, [key]: value });
  };

  return (
    <aside
      aria-label="Auto Clip configuration"
      className="w-full lg:w-[320px] shrink-0 rounded-xl border border-slate-800 bg-[#121823] p-4"
    >
      <div className="border-b border-slate-800 pb-2.5">
        <h2 className="font-display text-base font-semibold text-slate-50">
          Auto Clip Settings
        </h2>
        <p className="mt-0.5 text-xs leading-relaxed text-slate-400">
          Defaults auto-classify up to 10-hour videos and preserve full framing.
        </p>
      </div>

      <div className="mt-3 space-y-3">
        {/* Auto Detect Category Toggle */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <label
              htmlFor="toggle-auto-detect-category"
              className="block text-sm font-medium text-slate-200"
            >
              Auto Detect Category
            </label>
            <p className="mt-0.5 text-xs text-slate-400">
              Classify gameplay, podcasts, docs &amp; more
            </p>
          </div>
          <input
            id="toggle-auto-detect-category"
            type="checkbox"
            checked={settings.autoDetectCategory}
            onChange={(e) => {
              const checked = e.target.checked;
              onChange({
                ...settings,
                autoDetectCategory: checked,
                selectedCategory: checked
                  ? 'auto'
                  : settings.selectedCategory === 'auto'
                    ? 'gaming'
                    : settings.selectedCategory,
              });
            }}
            className="mt-1 h-4 w-4 rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-blue-500"
          />
        </div>

        {/* Select Category Override */}
        <div>
          <label
            htmlFor="select-category"
            className="block text-xs font-medium text-slate-300"
          >
            Select Category
          </label>
          <select
            id="select-category"
            value={settings.autoDetectCategory ? 'auto' : settings.selectedCategory}
            onChange={(e) => {
              const val = e.target.value as VideoCategoryId;
              onChange({
                ...settings,
                autoDetectCategory: val === 'auto',
                selectedCategory: val,
              });
            }}
            className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-3 py-1.5 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
          >
            {CATEGORY_LIST.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.label}
              </option>
            ))}
          </select>
        </div>

        {/* Auto Detect Best Clips Toggle */}
        <div className="flex items-start justify-between gap-3 border-t border-slate-800/80 pt-2.5">
          <div>
            <label
              htmlFor="toggle-auto-best-clips"
              className="block text-sm font-medium text-slate-200"
            >
              Auto Detect Best Clips
            </label>
            <p className="mt-0.5 text-xs text-slate-400">
              Rank hook, context, emotion &amp; visual interest
            </p>
          </div>
          <input
            id="toggle-auto-best-clips"
            type="checkbox"
            checked={settings.autoDetectBestClips}
            onChange={(e) => update('autoDetectBestClips', e.target.checked)}
            className="mt-1 h-4 w-4 rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-blue-500"
          />
        </div>

        {/* Number of Clips + Preferred Duration */}
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <div className="flex items-center justify-between">
              <label
                htmlFor="input-number-of-clips"
                className="text-xs font-medium text-slate-300"
              >
                Clips
              </label>
              <span className="font-mono text-xs font-medium text-slate-200 tabular-nums">
                {settings.numberOfClips}
              </span>
            </div>
            <input
              id="input-number-of-clips"
              type="range"
              min={1}
              max={10}
              value={settings.numberOfClips}
              onChange={(e) => update('numberOfClips', Number(e.target.value))}
              className="mt-2.5 w-full accent-blue-600"
            />
          </div>

          <div>
            <label
              htmlFor="select-duration"
              className="block text-xs font-medium text-slate-300"
            >
              Clip Duration
            </label>
            <select
              id="select-duration"
              value={settings.durationPreset}
              onChange={(e) =>
                update('durationPreset', e.target.value as ClipDurationPreset)
              }
              className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {(Object.keys(DURATION_PRESETS) as ClipDurationPreset[]).map((key) => (
                <option key={key} value={key}>
                  {DURATION_PRESETS[key].label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Target Aspect Ratio */}
        <div>
          <span className="block text-xs font-medium text-slate-300">
            Target Aspect Ratio
          </span>
          <div
            role="group"
            aria-label="Target Aspect Ratio"
            className="mt-1 grid grid-cols-2 gap-1.5"
          >
            {ASPECT_RATIOS.map((ratio) => {
              const active = settings.aspectRatio === ratio.id;
              return (
                <button
                  key={ratio.id}
                  type="button"
                  onClick={() => update('aspectRatio', ratio.id)}
                  className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-colors duration-150 ${
                    active
                      ? 'border-blue-500 bg-blue-600/15 text-white'
                      : 'border-slate-800 bg-[#0B0F17] text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {ratio.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Framing Layout & Streamer Webcam Position */}
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label
              htmlFor="select-layout-preference"
              className="block text-xs font-medium text-slate-300"
            >
              Framing Layout
            </label>
            <select
              id="select-layout-preference"
              value={settings.layoutPreference}
              onChange={(e) =>
                update('layoutPreference', e.target.value as LayoutPreference)
              }
              className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {LAYOUT_PREFERENCES.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="select-webcam-position"
              className="block text-xs font-medium text-slate-300"
            >
              Streamer Cam
            </label>
            <select
              id="select-webcam-position"
              value={settings.webcamPreference}
              onChange={(e) =>
                update('webcamPreference', e.target.value as WebcamPosition)
              }
              className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {(Object.keys(WEBCAM_POSITION_LABELS) as WebcamPosition[]).map((pos) => (
                <option key={pos} value={pos}>
                  {WEBCAM_POSITION_LABELS[pos]}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Caption Language & Style */}
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label
              htmlFor="select-caption-language"
              className="block text-xs font-medium text-slate-300"
            >
              Caption Language
            </label>
            <select
              id="select-caption-language"
              value={settings.captionLanguage}
              onChange={(e) => update('captionLanguage', e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {CAPTION_LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>
                  {lang}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="select-caption-style"
              className="block text-xs font-medium text-slate-300"
            >
              Caption Style
            </label>
            <select
              id="select-caption-style"
              value={settings.captionStyle}
              onChange={(e) =>
                update('captionStyle', e.target.value as CaptionStyleId)
              }
              className="mt-1 w-full rounded-lg border border-slate-700/80 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {CAPTION_STYLES.map((style) => (
                <option key={style.id} value={style.id}>
                  {style.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Primary Auto Clip Button */}
        <button
          type="button"
          onClick={onRunAutoClip}
          disabled={!hasVideo || isAnalyzing}
          className="mt-1 flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap transition-colors duration-150 hover:bg-blue-500 disabled:cursor-not-allowed disabled:bg-slate-800 disabled:text-slate-500"
        >
          <Sparkles className="h-4 w-4" aria-hidden="true" />
          <span>{isAnalyzing ? 'Analyzing & Rendering...' : 'Auto Clip'}</span>
        </button>
      </div>
    </aside>
  );
}
