import { CATEGORY_PROFILES, LAYOUT_LABELS, type ConcreteCategoryId } from '../lib/clipEngine';

interface CategoryEngineViewProps {
  onSelectCategoryForClip: (category: ConcreteCategoryId) => void;
}

export function CategoryEngineView({
  onSelectCategoryForClip,
}: CategoryEngineViewProps) {
  const profiles = Object.values(CATEGORY_PROFILES);

  return (
    <section aria-label="Universal category detection rubrics" className="space-y-6">
      <div className="border-b border-slate-800 pb-5">
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-50">
          Universal Category Highlight Rubrics
        </h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">
          Each video category uses dedicated visual/audio signal weights, context-preservation
          rules, and content-appropriate framing. Gaming split layouts are never applied to
          podcasts, interviews, or documentaries.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {profiles.map((profile) => (
          <article
            key={profile.id}
            className="flex flex-col justify-between rounded-xl border border-slate-800 bg-[#121823] p-5"
          >
            <div>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-50">
                    {profile.label}
                  </h2>
                  <p className="mt-1 font-mono text-xs text-slate-400">
                    Vertical Default: {LAYOUT_LABELS[profile.preferredVerticalLayout]}
                    <span aria-hidden="true"> · </span>
                    Split Gameplay: {profile.allowSplitGameplayLayout ? 'Allowed' : 'Disabled'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onSelectCategoryForClip(profile.id)}
                  className="rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs font-medium text-slate-200 whitespace-nowrap hover:border-blue-500 hover:text-white"
                >
                  Use Preset
                </button>
              </div>

              <p className="mt-3 text-sm leading-relaxed text-slate-300">
                {profile.description}
              </p>

              <div className="mt-4 grid grid-cols-1 gap-4 border-t border-slate-800/80 pt-4 sm:grid-cols-2">
                <div>
                  <h3 className="text-xs font-semibold text-emerald-400">
                    Signals Detected
                  </h3>
                  <ul className="mt-2 space-y-1.5 text-xs leading-relaxed text-slate-300">
                    {profile.detectSignals.slice(0, 4).map((sig) => (
                      <li key={sig}>• {sig}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xs font-semibold text-amber-400">
                    Filtered Out
                  </h3>
                  <ul className="mt-2 space-y-1.5 text-xs leading-relaxed text-slate-400">
                    {profile.avoidSignals.map((sig) => (
                      <li key={sig}>• {sig}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
