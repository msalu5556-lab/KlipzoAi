import { useEffect, useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, Film, Loader2 } from 'lucide-react';
import { AutoClipSidebar } from './components/AutoClipSidebar';
import { CategoryEngineView } from './components/CategoryEngineView';
import { ClipCard } from './components/ClipCard';
import { ClipEditorModal } from './components/ClipEditorModal';
import { TopBar } from './components/TopBar';
import { VideoUploadStage } from './components/VideoUploadStage';
import {
  CATEGORY_LIST,
  CATEGORY_PROFILES,
  WEBCAM_POSITION_LABELS,
  type ConcreteCategoryId,
  type NormalizedClip,
  type VideoCategoryId,
} from './lib/clipEngine';
import type {
  ActiveTab,
  AnalysisResponse,
  AutoClipSettings,
  UploadedVideoInfo,
} from './types/studio';

const DEFAULT_SETTINGS: AutoClipSettings = {
  autoDetectCategory: true,
  selectedCategory: 'auto',
  autoDetectBestClips: true,
  numberOfClips: 4,
  durationPreset: 'balanced',
  aspectRatio: '9:16',
  captionLanguage: 'English',
  captionStyle: 'clean_editorial',
  layoutPreference: 'auto',
  webcamPreference: 'auto',
};

const CHUNK_SIZE_BYTES = 2 * 1024 * 1024; // 2 MB raw chunks stay safely under proxy body limits

function summarizeHtmlResponse(html: string): string {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch?.[1]?.replace(/\s+/g, ' ').trim();
  const stripped = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 140);
  return title ? `${title}${stripped ? ` — ${stripped}` : ''}` : stripped || 'HTML page';
}

async function parseJsonResponse<T>(
  response: Response,
  endpoint = 'API'
): Promise<T> {
  const text = await response.text();
  try {
    return JSON.parse(text) as T;
  } catch {
    if (text.trim().startsWith('<')) {
      const summary = summarizeHtmlResponse(text);
      throw new Error(
        `${endpoint} returned an HTML page (HTTP ${response.status}: ${summary}). If your preview session expired or the request was intercepted, refresh the page and try again.`
      );
    }
    throw new Error(
      `${endpoint} returned unexpected response (HTTP ${response.status}): ${text.slice(0, 140)}`
    );
  }
}

export default function App() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [activeTab, setActiveTab] = useState<ActiveTab>('workspace');
  const [settings, setSettings] = useState<AutoClipSettings>(DEFAULT_SETTINGS);
  const [video, setVideo] = useState<UploadedVideoInfo | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [clipLibrary, setClipLibrary] = useState<NormalizedClip[]>([]);
  const [libraryFilter, setLibraryFilter] = useState<'all' | ConcreteCategoryId>('all');

  const [isUploading, setIsUploading] = useState(false);
  const [isImportingYoutube, setIsImportingYoutube] = useState(false);
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusProgress, setStatusProgress] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [engineStatus, setEngineStatus] = useState<{
    ready: boolean;
    detail: string;
    gemini: boolean;
  } | null>(null);

  // Surface the clipping engine's health on load (BUG-9 fix): the user sees
  // immediately whether the local engine is ready — and if not, exactly what
  // to install — instead of discovering it after clicking Run.
  useEffect(() => {
    let cancelled = false;
    fetch('/api/health')
      .then((r) => r.json())
      .then((h: { localEngine?: { available: boolean; detail: string }; geminiConfigured?: boolean }) => {
        if (cancelled) return;
        const local = h.localEngine;
        setEngineStatus({
          ready: Boolean(local?.available),
          detail: local?.detail ?? 'Engine status unknown.',
          gemini: Boolean(h.geminiConfigured),
        });
      })
      .catch(() => {
        if (!cancelled) setEngineStatus({ ready: false, detail: 'Could not reach the server health endpoint.', gemini: false });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const [editingClip, setEditingClip] = useState<NormalizedClip | null>(null);

  const triggerFilePicker = () => {
    fileInputRef.current?.click();
  };

  const handleUploadFile = async (file: File) => {
    setErrorMessage(null);
    setStatusProgress(null);
    setStatusMessage(`Uploading and inspecting "${file.name}"...`);
    setIsUploading(true);

    try {
      let data: UploadedVideoInfo & { error?: string };

      if (file.size > CHUNK_SIZE_BYTES) {
        const totalChunks = Math.ceil(file.size / CHUNK_SIZE_BYTES);
        const initRes = await fetch('/api/videos/upload/init', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filename: file.name,
            mimeType: file.type || 'video/mp4',
            totalChunks,
          }),
        });
        const initData = await parseJsonResponse<{ uploadId?: string; error?: string }>(
          initRes,
          'Upload init'
        );
        if (!initRes.ok || !initData.uploadId) {
          throw new Error(initData.error || 'Failed to initialize chunked upload.');
        }

        let uploadedChunks = 0;
        const uploadSingleChunk = async (idx: number) => {
          const start = idx * CHUNK_SIZE_BYTES;
          const end = Math.min(file.size, start + CHUNK_SIZE_BYTES);
          const chunkBlob = file.slice(start, end);

          let lastErr: Error | null = null;
          for (let attempt = 1; attempt <= 3; attempt++) {
            try {
              const chunkRes = await fetch(
                `/api/videos/upload/chunk-raw?uploadId=${encodeURIComponent(initData.uploadId!)}&chunkIndex=${idx}`,
                {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/octet-stream' },
                  body: chunkBlob,
                }
              );
              const chunkData = await parseJsonResponse<{ ok?: boolean; error?: string }>(
                chunkRes,
                `Chunk ${idx + 1}/${totalChunks}`
              );
              if (!chunkRes.ok || !chunkData.ok) {
                throw new Error(chunkData.error || `Chunk ${idx + 1} failed.`);
              }
              uploadedChunks += 1;
              const pct = Math.round((uploadedChunks / totalChunks) * 85);
              const uploadedMb = ((uploadedChunks * CHUNK_SIZE_BYTES) / (1024 * 1024)).toFixed(0);
              const totalMb = (file.size / (1024 * 1024)).toFixed(0);
              setStatusMessage(
                `Uploading "${file.name}" (${Math.min(Number(uploadedMb), Number(totalMb))} / ${totalMb} MB)...`
              );
              setStatusProgress(pct);
              return;
            } catch (err) {
              lastErr = err instanceof Error ? err : new Error('Chunk upload failed.');
              if (attempt < 3) {
                await new Promise((r) => setTimeout(r, attempt * 1000));
              }
            }
          }
          throw lastErr ?? new Error(`Failed uploading chunk ${idx + 1}.`);
        };

        let nextIdx = 0;
        const workerCount = Math.min(3, totalChunks);
        await Promise.all(
          Array.from({ length: workerCount }, async () => {
            while (nextIdx < totalChunks) {
              const idx = nextIdx++;
              await uploadSingleChunk(idx);
            }
          })
        );

        setStatusMessage(`Finalizing and inspecting "${file.name}"...`);
        setStatusProgress(88);
        const completeRes = await fetch('/api/videos/upload/complete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uploadId: initData.uploadId }),
        });

        const completeData = await parseJsonResponse<
          (UploadedVideoInfo & { error?: string }) | { jobId: string; stage?: string; progress?: number; error?: string }
        >(completeRes, 'Upload complete');

        if (!completeRes.ok) {
          throw new Error(completeData.error || 'Failed to finalize video upload.');
        }

        if ('videoId' in completeData) {
          data = completeData;
        } else {
          const { jobId } = completeData;
          while (true) {
            await new Promise((r) => setTimeout(r, 1000));
            const jobRes = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`);
            const jobData = await parseJsonResponse<{
              status: 'queued' | 'running' | 'completed' | 'failed';
              stage?: string;
              progress?: number;
              video?: UploadedVideoInfo;
              error?: string;
            }>(jobRes, 'Upload status');
            if (!jobRes.ok) {
              throw new Error(jobData.error || 'Failed checking upload status.');
            }
            if (jobData.stage) setStatusMessage(jobData.stage);
            if (typeof jobData.progress === 'number') {
              setStatusProgress(Math.max(88, Math.round(88 + jobData.progress * 0.12)));
            }
            if (jobData.status === 'completed' && jobData.video) {
              data = jobData.video;
              break;
            }
            if (jobData.status === 'failed') {
              throw new Error(jobData.error || 'Video assembly failed.');
            }
          }
        }
      } else {
        const formData = new FormData();
        formData.append('video', file);

        const response = await fetch('/api/videos/upload', {
          method: 'POST',
          body: formData,
        });

        data = await parseJsonResponse<UploadedVideoInfo & { error?: string }>(
          response,
          'Video upload'
        );
        if (!response.ok) {
          throw new Error(data.error || 'Video upload failed.');
        }
      }

      setVideo(data);
      setAnalysis(null);
      setActiveTab('workspace');
      setStatusMessage(null);
      setStatusProgress(null);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to upload video.');
      setStatusMessage(null);
      setStatusProgress(null);
    } finally {
      setIsUploading(false);
    }
  };

  const handleImportYoutubeUrl = async (url: string) => {
    setErrorMessage(null);
    setStatusProgress(null);
    setStatusMessage('Fetching YouTube video metadata, transcript & stream...');
    setIsImportingYoutube(true);

    try {
      const response = await fetch('/api/videos/youtube', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });

      const data = await parseJsonResponse<UploadedVideoInfo & { error?: string }>(
        response,
        'YouTube import'
      );
      if (!response.ok) {
        throw new Error(data.error || 'Failed to import YouTube URL.');
      }

      setVideo(data);
      setAnalysis(null);
      setActiveTab('workspace');
      setStatusMessage(null);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to import YouTube URL.');
      setStatusMessage(null);
    } finally {
      setIsImportingYoutube(false);
    }
  };

  const handleLoadSample = async (kind: 'gaming' | 'podcast' | 'educational') => {
    setErrorMessage(null);
    setStatusProgress(null);
    setStatusMessage(`Preparing synthesized ${kind} test video...`);
    setIsGeneratingSample(true);

    try {
      const response = await fetch('/api/videos/sample', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind }),
      });

      const data = await parseJsonResponse<UploadedVideoInfo & { error?: string }>(response);
      if (!response.ok) {
        throw new Error(data.error || 'Failed to prepare sample video.');
      }

      setVideo(data);
      setAnalysis(null);
      setActiveTab('workspace');
      setStatusMessage(null);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to load sample video.');
      setStatusMessage(null);
    } finally {
      setIsGeneratingSample(false);
    }
  };

  const handleRunAutoClip = async (overrideSettings?: AutoClipSettings) => {
    if (!video) return;
    const activeSettings = overrideSettings ?? settings;
    setErrorMessage(null);
    setIsAnalyzing(true);
    setStatusProgress(5);
    setStatusMessage(
      activeSettings.autoDetectCategory
        ? 'Starting automatic category detection and multi-window analysis...'
        : `Starting highlight analysis for ${
            activeSettings.selectedCategory !== 'auto'
              ? CATEGORY_PROFILES[activeSettings.selectedCategory].label
              : 'Auto'
          }...`
    );

    try {
      const startResponse = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoId: video.videoId,
          ...activeSettings,
        }),
      });

      const startData = await parseJsonResponse<
        (AnalysisResponse & { error?: string }) | { jobId: string; status: string; stage: string; progress: number; error?: string }
      >(startResponse);

      if (!startResponse.ok) {
        throw new Error(startData.error || 'Auto Clip analysis failed.');
      }

      if ('clips' in startData) {
        setAnalysis(startData);
        setClipLibrary((prev) => [...startData.clips, ...prev]);
        setStatusMessage(null);
        setStatusProgress(null);
        return;
      }

      const { jobId } = startData;
      const pollStartedAt = Date.now();
      const maxPollMs = 25 * 60 * 1000;

      while (true) {
        if (Date.now() - pollStartedAt > maxPollMs) {
          throw new Error('Analysis timed out. Try fewer clips or verify the source stream.');
        }

        await new Promise((resolve) => setTimeout(resolve, 1500));

        const jobRes = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`);
        const jobData = await parseJsonResponse<{
          status: 'queued' | 'running' | 'completed' | 'failed';
          stage?: string;
          progress?: number;
          result?: AnalysisResponse;
          error?: string;
        }>(jobRes);

        if (!jobRes.ok) {
          throw new Error(jobData.error || 'Failed to check Auto Clip job status.');
        }

        if (jobData.stage) {
          setStatusMessage(jobData.stage);
        }
        if (typeof jobData.progress === 'number') {
          setStatusProgress(jobData.progress);
        }

        if (jobData.status === 'completed' && jobData.result) {
          setAnalysis(jobData.result);
          setClipLibrary((prev) => [...jobData.result!.clips, ...prev]);
          setStatusMessage(null);
          setStatusProgress(null);
          break;
        }

        if (jobData.status === 'failed') {
          throw new Error(jobData.error || 'Auto Clip analysis failed.');
        }
      }
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Auto Clip analysis failed.');
      setStatusMessage(null);
      setStatusProgress(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleClipUpdated = (updated: NormalizedClip) => {
    setAnalysis((prev) =>
      prev
        ? {
            ...prev,
            clips: prev.clips.map((c) => (c.id === updated.id ? updated : c)),
          }
        : prev
    );
    setClipLibrary((prev) =>
      prev.map((c) => (c.id === updated.id ? updated : c))
    );
    setEditingClip(null);
  };

  const filteredLibraryClips =
    libraryFilter === 'all'
      ? clipLibrary
      : clipLibrary.filter((c) => c.detectedCategory === libraryFilter);

  const libraryCategories = Array.from(
    new Set(clipLibrary.map((c) => c.detectedCategory))
  );

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100">
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        aria-label="Upload video file"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            void handleUploadFile(file);
          }
          e.target.value = '';
        }}
      />

      <TopBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onTriggerUpload={triggerFilePicker}
        clipCount={clipLibrary.length}
      />

      <main className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6 sm:py-8">
        <nav
          aria-label="Mobile studio navigation"
          className="mb-5 flex items-center gap-4 border-b border-slate-800 pb-3 md:hidden"
        >
          <button
            type="button"
            onClick={() => setActiveTab('workspace')}
            className={`text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'workspace' ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8' : 'text-slate-400'
            }`}
          >
            Auto Clip
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('library')}
            className={`text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'library' ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8' : 'text-slate-400'
            }`}
          >
            Clip Library ({clipLibrary.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('categories')}
            className={`text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'categories' ? 'text-white underline decoration-blue-500 decoration-2 underline-offset-8' : 'text-slate-400'
            }`}
          >
            Category Engine
          </button>
        </nav>

        {activeTab === 'workspace' && (
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
            <AutoClipSidebar
              settings={settings}
              onChange={setSettings}
              onRunAutoClip={() => void handleRunAutoClip()}
              hasVideo={Boolean(video)}
              isAnalyzing={isAnalyzing}
            />

            <div className="min-w-0 flex-1 space-y-6">
              <VideoUploadStage
                video={video}
                isUploading={isUploading}
                isImportingYoutube={isImportingYoutube}
                isGeneratingSample={isGeneratingSample}
                onSelectFile={(file) => void handleUploadFile(file)}
                onImportYoutubeUrl={(url) => void handleImportYoutubeUrl(url)}
                onLoadSample={(kind) => void handleLoadSample(kind)}
                onTriggerUpload={triggerFilePicker}
                onClearVideo={() => {
                  setVideo(null);
                  setAnalysis(null);
                  setErrorMessage(null);
                }}
                onRunAutoClip={() => void handleRunAutoClip()}
                isAnalyzing={isAnalyzing}
              />

              {engineStatus && !engineStatus.ready && (
                <div
                  role="alert"
                  className="flex items-start gap-3 rounded-xl border border-amber-500/40 bg-amber-950/30 px-4 py-3.5 text-sm text-amber-200"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
                  <div>
                    <p className="font-semibold text-amber-100">Local clipping engine is not ready</p>
                    <p className="mt-1 leading-relaxed text-amber-200/90">{engineStatus.detail}</p>
                  </div>
                </div>
              )}

              {engineStatus && engineStatus.ready && (
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                  <span>
                    Local clipping engine ready — no API key needed
                    {engineStatus.gemini ? ' · Gemini enhancement available' : ''}
                  </span>
                </div>
              )}

              {statusMessage && (
                <div
                  role="status"
                  className="rounded-xl border border-blue-500/30 bg-blue-950/30 px-4 py-3.5 text-sm text-blue-100"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Loader2 className="h-4 w-4 shrink-0 animate-spin text-blue-400" aria-hidden="true" />
                      <span>{statusMessage}</span>
                    </div>
                    {statusProgress !== null && (
                      <span className="font-mono text-xs text-blue-300 tabular-nums shrink-0">
                        {statusProgress}%
                      </span>
                    )}
                  </div>
                  {statusProgress !== null && (
                    <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                      <div
                        className="h-full bg-blue-500 transition-all duration-300"
                        style={{ width: `${Math.max(4, Math.min(100, statusProgress))}%` }}
                      />
                    </div>
                  )}
                </div>
              )}

              {errorMessage && (
                <div
                  role="alert"
                  className="flex items-start gap-3 rounded-xl border border-red-500/40 bg-red-950/30 px-4 py-3.5 text-sm text-red-200"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" aria-hidden="true" />
                  <div>
                    <p className="font-semibold text-red-100">Auto Clip Could Not Complete</p>
                    <p className="mt-1 leading-relaxed text-red-200/90">{errorMessage}</p>
                  </div>
                </div>
              )}

              {analysis && (
                <section aria-label="Generated highlights" className="space-y-6">
                  {/* Category Detection Summary */}
                  <div className="rounded-xl border border-slate-800 bg-[#121823] p-5">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="max-w-2xl">
                        <div className="flex items-center gap-2 text-xs font-medium text-emerald-400">
                          <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                          <span>
                            Detected Category: {analysis.primaryCategoryLabel}
                            <span aria-hidden="true"> · </span>
                            {analysis.categoryConfidence}% confidence
                            {analysis.detectedWebcamPosition &&
                              analysis.detectedWebcamPosition !== 'none' && (
                                <>
                                  <span aria-hidden="true"> · </span>
                                  Facecam: {WEBCAM_POSITION_LABELS[analysis.detectedWebcamPosition]}
                                </>
                              )}
                            {analysis.secondaryCategories.length > 0 && (
                              <>
                                <span aria-hidden="true"> · </span>
                                Secondary:{' '}
                                {analysis.secondaryCategories
                                  .map((c) => CATEGORY_PROFILES[c].shortLabel)
                                  .join(', ')}
                              </>
                            )}
                          </span>
                        </div>
                        <p className="mt-2 text-sm leading-relaxed text-slate-200">
                          {analysis.categoryReasoning}
                        </p>
                        {analysis.contentSummary && (
                          <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
                            {analysis.contentSummary}
                          </p>
                        )}
                        {analysis.streamWarning && (
                          <p className="mt-2 text-xs leading-relaxed text-amber-300/90">
                            {analysis.streamWarning}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <label
                          htmlFor="override-category-inline"
                          className="sr-only"
                        >
                          Override category
                        </label>
                        <select
                          id="override-category-inline"
                          value={settings.autoDetectCategory ? 'auto' : settings.selectedCategory}
                          onChange={(e) => {
                            const val = e.target.value as VideoCategoryId;
                            const next: AutoClipSettings = {
                              ...settings,
                              autoDetectCategory: val === 'auto',
                              selectedCategory: val,
                            };
                            setSettings(next);
                          }}
                          className="rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs text-slate-200 focus:border-blue-500 focus:outline-none"
                        >
                          {CATEGORY_LIST.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.label}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => void handleRunAutoClip()}
                          disabled={isAnalyzing}
                          className="rounded-lg border border-slate-700 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-slate-200 whitespace-nowrap hover:border-blue-500 hover:text-white disabled:opacity-50"
                        >
                          Re-Run
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Clip Cards */}
                  {analysis.clips.length === 0 ? (
                    <div className="rounded-xl border border-slate-800 bg-[#121823] p-8 text-center">
                      <p className="text-sm font-medium text-slate-200">
                        No clips met the minimum quality and duration thresholds for this video.
                      </p>
                      <p className="mt-1 text-xs text-slate-400">
                        Try switching Clip Duration to Short (15–30s) or adjusting the category override.
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                      {analysis.clips.map((clip) => (
                        <ClipCard
                          key={clip.id}
                          clip={clip}
                          onEdit={(target) => setEditingClip(target)}
                        />
                      ))}
                    </div>
                  )}
                </section>
              )}
            </div>
          </div>
        )}

        {activeTab === 'library' && (
          <section aria-label="Clip library" className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
              <div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-slate-50">
                  Generated Clip Library
                </h1>
                <p className="mt-1 text-sm text-slate-400">
                  All rendered MP4 highlights and SRT transcripts from your current studio session.
                </p>
              </div>

              {libraryCategories.length > 0 && (
                <div
                  role="group"
                  aria-label="Filter clips by category"
                  className="flex flex-wrap items-center gap-1 rounded-lg bg-[#121823] p-1 border border-slate-800"
                >
                  <button
                    type="button"
                    onClick={() => setLibraryFilter('all')}
                    className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                      libraryFilter === 'all'
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-400 hover:text-slate-100'
                    }`}
                  >
                    All ({clipLibrary.length})
                  </button>
                  {libraryCategories.map((catId) => (
                    <button
                      key={catId}
                      type="button"
                      onClick={() => setLibraryFilter(catId)}
                      className={`rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                        libraryFilter === catId
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-slate-100'
                      }`}
                    >
                      {CATEGORY_PROFILES[catId].shortLabel}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {filteredLibraryClips.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-[#121823] p-12 text-center">
                <Film className="mx-auto h-8 w-8 text-slate-500" aria-hidden="true" />
                <h2 className="mt-3 font-display text-base font-semibold text-slate-200">
                  No Clips Generated Yet
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  Upload a video or paste a YouTube URL in the Auto Clip workspace to generate
                  highlights.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('workspace')}
                  className="mt-5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500"
                >
                  Go to Auto Clip
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
                {filteredLibraryClips.map((clip) => (
                  <ClipCard
                    key={clip.id}
                    clip={clip}
                    onEdit={(target) => setEditingClip(target)}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {activeTab === 'categories' && (
          <CategoryEngineView
            onSelectCategoryForClip={(cat) => {
              setSettings((prev) => ({
                ...prev,
                autoDetectCategory: false,
                selectedCategory: cat,
              }));
              setActiveTab('workspace');
            }}
          />
        )}
      </main>

      {editingClip && (
        <ClipEditorModal
          clip={editingClip}
          videoDuration={video?.probe.duration ?? editingClip.endTime}
          onClose={() => setEditingClip(null)}
          onSaved={handleClipUpdated}
        />
      )}
    </div>
  );
}
