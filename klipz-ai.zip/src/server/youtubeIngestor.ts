import { Innertube } from 'youtubei.js';
import {
  extractYouTubeVideoId,
  parseIsoDurationSeconds,
} from '../lib/clipEngine.ts';
import type { VideoProbeInfo } from './ffmpegTools.ts';

export interface YouTubeTranscriptCue {
  start: number;
  duration: number;
  text: string;
}

export interface YouTubeIngestResult {
  youtubeId: string;
  title: string;
  channelTitle: string;
  description: string;
  durationSeconds: number;
  isLive: boolean;
  isLiveContent: boolean;
  thumbnailUrl: string;
  canonicalUrl: string;
  heatmapPeaks: number[];
  transcriptSegments: YouTubeTranscriptCue[];
  streamUrl: string | null;
  usedYouTubeDataApi: boolean;
  streamWarning?: string;
  probe: VideoProbeInfo;
}

interface YouTubeDataApiResponse {
  error?: { message?: string; code?: number };
  items?: Array<{
    id?: string;
    snippet?: {
      title?: string;
      channelTitle?: string;
      description?: string;
      liveBroadcastContent?: string;
      thumbnails?: {
        maxres?: { url?: string };
        high?: { url?: string };
        medium?: { url?: string };
        default?: { url?: string };
      };
    };
    contentDetails?: {
      duration?: string;
    };
    liveStreamingDetails?: {
      actualStartTime?: string;
      actualEndTime?: string;
    };
  }>;
}

export async function ingestYouTubeUrl(rawUrl: string): Promise<YouTubeIngestResult> {
  const youtubeId = extractYouTubeVideoId(rawUrl);
  if (!youtubeId) {
    throw new Error(
      'Invalid YouTube URL. Paste a standard YouTube video, live stream, or youtu.be link.'
    );
  }

  const canonicalUrl = `https://www.youtube.com/watch?v=${youtubeId}`;
  const apiKey = process.env.YOUTUBE_API_KEY?.trim();

  let title = '';
  let channelTitle = '';
  let description = '';
  let durationSeconds = 0;
  let isLive = false;
  let isLiveContent = false;
  let thumbnailUrl = `https://i.ytimg.com/vi/${youtubeId}/hqdefault.jpg`;
  let usedYouTubeDataApi = false;

  // 1. Official YouTube Data API v3 metadata + duration + live stream detection when configured
  if (apiKey) {
    const apiUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,liveStreamingDetails&id=${encodeURIComponent(
      youtubeId
    )}&key=${encodeURIComponent(apiKey)}`;

    const res = await fetch(apiUrl);
    const data = (await res.json()) as YouTubeDataApiResponse;

    if (!res.ok || data.error) {
      throw new Error(
        `YouTube Data API error: ${data.error?.message || `HTTP ${res.status}`}`
      );
    }

    const item = data.items?.[0];
    if (!item) {
      throw new Error('YouTube video not found, private, or unavailable.');
    }

    usedYouTubeDataApi = true;
    title = item.snippet?.title ?? '';
    channelTitle = item.snippet?.channelTitle ?? '';
    description = item.snippet?.description ?? '';
    isLive = item.snippet?.liveBroadcastContent === 'live';
    isLiveContent = Boolean(item.liveStreamingDetails || isLive);
    durationSeconds = item.contentDetails?.duration
      ? parseIsoDurationSeconds(item.contentDetails.duration)
      : 0;

    const thumbs = item.snippet?.thumbnails;
    thumbnailUrl =
      thumbs?.maxres?.url ||
      thumbs?.high?.url ||
      thumbs?.medium?.url ||
      thumbs?.default?.url ||
      thumbnailUrl;
  }

  // 2. Innertube (youtubei.js) for transcript, Most-Replayed heatmap peaks, and direct stream URL
  const heatmapPeaks: number[] = [];
  const transcriptSegments: YouTubeTranscriptCue[] = [];
  let streamUrl: string | null = null;
  let streamWarning: string | undefined;
  let width = 1280;
  let height = 720;
  let fps = 30;

  try {
    const yt = await Innertube.create({ retrieve_player: true });
    let info = await yt.getInfo(youtubeId);

    if (!title && info.basic_info.title) {
      title = info.basic_info.title;
    }
    if (!channelTitle && info.basic_info.author) {
      channelTitle = info.basic_info.author;
    }
    if (!description && info.basic_info.short_description) {
      description = info.basic_info.short_description;
    }
    if (durationSeconds <= 0 && typeof info.basic_info.duration === 'number') {
      durationSeconds = info.basic_info.duration;
    }
    if (info.basic_info.is_live) {
      isLive = true;
      isLiveContent = true;
    }
    if (info.basic_info.thumbnail?.[0]?.url) {
      thumbnailUrl = info.basic_info.thumbnail[0].url;
    }

    // Extract "Most Replayed" heatmap markers if present
    const markers = info.heat_map?.heat_markers ?? [];
    if (markers.length > 0) {
      const sortedMarkers = [...markers]
        .filter(
          (m) =>
            typeof m.time_range_start_millis === 'number' &&
            typeof m.heat_marker_intensity_score_normalized === 'number'
        )
        .sort(
          (a, b) =>
            (b.heat_marker_intensity_score_normalized ?? 0) -
            (a.heat_marker_intensity_score_normalized ?? 0)
        );

      for (const m of sortedMarkers.slice(0, 8)) {
        heatmapPeaks.push(Math.round((m.time_range_start_millis ?? 0) / 1000));
      }
    }

    // Extract transcript cues (works even on 10-hour streams/VODs)
    try {
      const transcriptInfo = await info.getTranscript();
      const bodySegments =
        transcriptInfo?.transcript?.content?.body?.initial_segments ?? [];
      for (const seg of bodySegments) {
        const s = seg as {
          start_ms?: string | number;
          end_ms?: string | number;
          snippet?: { text?: string };
        };
        const text = s.snippet?.text?.trim();
        if (!text) continue;
        const startSec = Number(s.start_ms ?? 0) / 1000;
        const endSec = Number(s.end_ms ?? startSec * 1000 + 3000) / 1000;
        if (Number.isFinite(startSec)) {
          transcriptSegments.push({
            start: Number(startSec.toFixed(2)),
            duration: Math.max(0.5, Number((endSec - startSec).toFixed(2))),
            text,
          });
        }
      }
    } catch {
      // Transcript may be disabled on some streams
    }

    // Resolve stream URL (try HLS manifest first for live/DVR, then progressive MP4, then ANDROID fallback)
    const resolveStreamFromInfo = async (targetInfo: typeof info) => {
      if (targetInfo.streaming_data?.hls_manifest_url) {
        return {
          url: targetInfo.streaming_data.hls_manifest_url,
          w: 1280,
          h: 720,
          f: 30,
        };
      }
      try {
        const fmt = targetInfo.chooseFormat({ type: 'video+audio', quality: 'best' });
        const url = await fmt.decipher(yt.session.player);
        if (url) {
          return {
            url,
            w: fmt.width ?? 1280,
            h: fmt.height ?? 720,
            f: fmt.fps ?? 30,
          };
        }
      } catch {
        // Ignore and try alternative client
      }
      return null;
    };

    let resolved = await resolveStreamFromInfo(info);
    if (!resolved) {
      try {
        info = await yt.getInfo(youtubeId, { client: 'ANDROID' });
        resolved = await resolveStreamFromInfo(info);
      } catch {
        // Fallback failed
      }
    }

    if (resolved) {
      streamUrl = resolved.url;
      width = resolved.w;
      height = resolved.h;
      fps = resolved.f;
    } else {
      streamWarning =
        'YouTube restricted direct server-side media stream extraction for this URL (bot/DRM check). Metadata and transcript were loaded, but MP4 rendering requires an unrestricted stream or uploaded video file.';
    }
  } catch (err) {
    if (!usedYouTubeDataApi) {
      throw new Error(
        `Could not load YouTube video "${youtubeId}": ${
          err instanceof Error ? err.message : 'Network or YouTube access error'
        }`
      );
    }
    streamWarning =
      'Loaded official YouTube Data API metadata, but InnerTube stream extraction was blocked on this server IP.';
  }

  // Fallback for active 10h live DVR streams that don't expose fixed contentDetails.duration
  if (durationSeconds <= 0 && isLive) {
    // Allow up to 10 hours (36,000s) DVR window if transcript/heatmap exists, or 3600s default
    const lastCue = transcriptSegments[transcriptSegments.length - 1];
    durationSeconds = lastCue ? Math.max(60, Math.ceil(lastCue.start + lastCue.duration)) : 3600;
  }

  if (!title) {
    title = `YouTube Video (${youtubeId})`;
  }

  return {
    youtubeId,
    title,
    channelTitle,
    description,
    durationSeconds: Math.max(1, durationSeconds),
    isLive,
    isLiveContent,
    thumbnailUrl,
    canonicalUrl,
    heatmapPeaks,
    transcriptSegments,
    streamUrl,
    usedYouTubeDataApi,
    streamWarning,
    probe: {
      duration: Math.max(1, durationSeconds),
      width,
      height,
      fps,
      hasAudio: true,
      codec: 'h264',
      sizeBytes: 0,
    },
  };
}
