import fs from 'node:fs/promises';
import path from 'node:path';
import {
  createPartFromUri,
  createUserContent,
  GoogleGenAI,
  ThinkingLevel,
  Type,
} from '@google/genai';
import {
  buildGeminiAnalysisPrompt,
  CATEGORY_PROFILES,
  selectCandidateWindows,
  validateAndNormalizeClips,
  type AspectRatio,
  type CaptionStyleId,
  type ClipDurationPreset,
  type ConcreteCategoryId,
  type DetectedWebcamPosition,
  type LayoutPreference,
  type NormalizedClip,
  type RawHighlightCandidate,
  type VideoCategoryId,
  type WebcamPosition,
} from '../lib/clipEngine.ts';
import {
  detectAudioActivityPeaks,
  extractCategoryProbeVideo,
  extractProxySegment,
  PROXIES_DIR,
} from './ffmpegTools.ts';
import type { YouTubeTranscriptCue } from './youtubeIngestor.ts';

export interface AnalyzeVideoRequest {
  videoPath: string;
  mimeType: string;
  videoDuration: number;
  sizeBytes?: number;
  hasAudio?: boolean;
  autoDetectCategory: boolean;
  selectedCategory: VideoCategoryId;
  autoDetectBestClips: boolean;
  numberOfClips: number;
  durationPreset: ClipDurationPreset;
  aspectRatio: AspectRatio;
  captionLanguage: string;
  captionStyle: CaptionStyleId;
  layoutPreference?: LayoutPreference;
  webcamPreference?: WebcamPosition;
  youtubeContext?: {
    title: string;
    channelTitle?: string;
    description?: string;
    heatmapPeaks?: number[];
    transcriptSegments?: YouTubeTranscriptCue[];
  };
  onProgress?: (stage: string, progress: number) => void;
}

export interface AnalyzeVideoResult {
  primaryCategory: ConcreteCategoryId;
  secondaryCategories: ConcreteCategoryId[];
  categoryConfidence: number;
  categoryReasoning: string;
  contentSummary: string;
  detectedWebcamPosition: DetectedWebcamPosition;
  clips: NormalizedClip[];
}

const CONCRETE_CATEGORIES = Object.keys(CATEGORY_PROFILES) as ConcreteCategoryId[];
const VALID_WEBCAM_POSITIONS: DetectedWebcamPosition[] = [
  'top_left',
  'top_right',
  'bottom_left',
  'bottom_right',
  'top_center',
  'none',
];

function toConcreteCategory(value: string | undefined): ConcreteCategoryId {
  if (value && (CONCRETE_CATEGORIES as string[]).includes(value)) {
    return value as ConcreteCategoryId;
  }
  return 'other';
}

function toWebcamPosition(value: string | undefined): DetectedWebcamPosition {
  if (value && (VALID_WEBCAM_POSITIONS as string[]).includes(value)) {
    return value as DetectedWebcamPosition;
  }
  return 'none';
}

export class GeminiConfigError extends Error {
  statusCode: number;
  code: string;
  constructor(message: string, statusCode = 503, code = 'API_KEY_MISSING') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new GeminiConfigError(
      'GEMINI_API_KEY is not configured. Open Settings > Secrets and add your Gemini API key to enable AI video classification and highlight detection.',
      503,
      'API_KEY_MISSING'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function uploadAndWaitFile(
  ai: GoogleGenAI,
  filePath: string,
  mimeType: string
): Promise<{ name: string; uri: string; mimeType: string }> {
  const uploaded = await ai.files.upload({
    file: filePath,
    config: {
      mimeType: mimeType || 'video/mp4',
    },
  });

  if (!uploaded.name) {
    throw new Error('Gemini Files API upload succeeded without returning a file name.');
  }

  let currentFile = await ai.files.get({ name: uploaded.name });
  const startedAt = Date.now();
  const maxWaitMs = 150_000;

  while (currentFile.state === 'PROCESSING') {
    if (Date.now() - startedAt > maxWaitMs) {
      await ai.files.delete({ name: uploaded.name }).catch(() => undefined);
      throw new Error('Timed out waiting for Gemini to process video segment.');
    }
    await new Promise((resolve) => setTimeout(resolve, 1500));
    currentFile = await ai.files.get({ name: uploaded.name });
  }

  if (currentFile.state === 'FAILED') {
    await ai.files.delete({ name: uploaded.name }).catch(() => undefined);
    throw new Error(
      `Gemini failed to process video segment: ${currentFile.error?.message || 'Unknown media error'}`
    );
  }

  if (!currentFile.uri) {
    await ai.files.delete({ name: uploaded.name }).catch(() => undefined);
    throw new Error('Processed Gemini file is missing a file URI.');
  }

  return {
    name: uploaded.name,
    uri: currentFile.uri,
    mimeType: currentFile.mimeType || mimeType || 'video/mp4',
  };
}

const FREE_MULTIMODAL_MODELS = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'] as const;

function extractReadableGeminiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  try {
    const jsonStart = raw.indexOf('{');
    if (jsonStart !== -1) {
      const parsed = JSON.parse(raw.slice(jsonStart)) as {
        error?: { message?: string; code?: number; status?: string };
      };
      if (parsed.error?.message) {
        return `Gemini AI service temporarily unavailable (${parsed.error.code ?? 503}): ${parsed.error.message}`;
      }
    }
  } catch {
    // Fall back to raw message
  }
  return raw;
}

async function generateWithModelFallback(
  fn: (model: string) => Promise<import('@google/genai').GenerateContentResponse>
): Promise<import('@google/genai').GenerateContentResponse> {
  let lastErr: unknown;

  for (const model of FREE_MULTIMODAL_MODELS) {
    const maxAttempts = 3;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await fn(model);
      } catch (err) {
        lastErr = err;
        const msg = err instanceof Error ? err.message : String(err);
        const isTransient =
          msg.includes('503') ||
          msg.includes('UNAVAILABLE') ||
          msg.includes('high demand') ||
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('500') ||
          msg.includes('ECONNRESET') ||
          msg.includes('ETIMEDOUT');

        if (!isTransient) {
          throw new Error(extractReadableGeminiError(err));
        }

        if (attempt < maxAttempts) {
          const jitter = Math.floor(Math.random() * 500);
          await new Promise((r) => setTimeout(r, attempt * 2000 + jitter));
        }
      }
    }
    console.warn(`Model ${model} unavailable after retries; trying next fallback model.`);
  }

  throw new Error(extractReadableGeminiError(lastErr));
}

const HIGHLIGHTS_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    primaryCategory: {
      type: Type.STRING,
      description:
        'One of: gaming, podcast, interview, reaction, commentary, documentary, educational, storytelling, news, entertainment, other',
    },
    secondaryCategories: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    categoryConfidence: {
      type: Type.NUMBER,
      description: 'Confidence score from 0 to 100',
    },
    categoryReasoning: {
      type: Type.STRING,
    },
    contentSummary: {
      type: Type.STRING,
    },
    webcamPosition: {
      type: Type.STRING,
      description:
        'Detected streamer/creator webcam overlay corner: top_left, top_right, bottom_left, bottom_right, top_center, or none',
    },
    highlights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          startTime: { type: Type.NUMBER },
          endTime: { type: Type.NUMBER },
          detectedCategory: { type: Type.STRING },
          reason: { type: Type.STRING },
          recommendedLayout: {
            type: Type.STRING,
            description:
              'One of: full_frame, dual_speaker, split_cam_gameplay, vertical_crop, speaker_focus, picture_in_picture',
          },
          webcamPosition: {
            type: Type.STRING,
            description:
              'One of: top_left, top_right, bottom_left, bottom_right, top_center, none',
          },
          scores: {
            type: Type.OBJECT,
            properties: {
              hookStrength: { type: Type.NUMBER },
              contextCompleteness: { type: Type.NUMBER },
              emotionalIntensity: { type: Type.NUMBER },
              valueScore: { type: Type.NUMBER },
              visualInterest: { type: Type.NUMBER },
              audioInterest: { type: Type.NUMBER },
              standaloneQuality: { type: Type.NUMBER },
              retentionPotential: { type: Type.NUMBER },
            },
            required: [
              'hookStrength',
              'contextCompleteness',
              'emotionalIntensity',
              'valueScore',
              'visualInterest',
              'audioInterest',
              'standaloneQuality',
              'retentionPotential',
            ],
          },
          captions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                start: { type: Type.NUMBER },
                end: { type: Type.NUMBER },
                text: { type: Type.STRING },
              },
              required: ['start', 'end', 'text'],
            },
          },
        },
        required: [
          'title',
          'startTime',
          'endTime',
          'reason',
          'scores',
          'captions',
        ],
      },
    },
  },
  required: [
    'primaryCategory',
    'categoryConfidence',
    'categoryReasoning',
    'contentSummary',
    'webcamPosition',
    'highlights',
  ],
};

interface ParsedGeminiOutput {
  primaryCategory?: string;
  secondaryCategories?: string[];
  categoryConfidence?: number;
  categoryReasoning?: string;
  contentSummary?: string;
  webcamPosition?: string;
  highlights?: RawHighlightCandidate[];
}

async function analyzeSingleMediaFile(
  ai: GoogleGenAI,
  filePath: string,
  mimeType: string,
  prompt: string
): Promise<ParsedGeminiOutput> {
  const uploaded = await uploadAndWaitFile(ai, filePath, mimeType);
  try {
    const response = await generateWithModelFallback((model) =>
      ai.models.generateContent({
        model,
        contents: createUserContent([
          createPartFromUri(uploaded.uri, uploaded.mimeType),
          prompt,
        ]),
        config: {
          systemInstruction:
            'You are a senior video editor and multimodal highlight detector. Return only accurate, strictly formatted JSON grounded in the observed video frames and audio.',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: 'application/json',
          responseSchema: HIGHLIGHTS_RESPONSE_SCHEMA,
        },
      })
    );
    const rawText = (response.text ?? '').trim();
    if (!rawText) {
      throw new Error('Gemini returned an empty analysis response.');
    }
    return JSON.parse(rawText) as ParsedGeminiOutput;
  } finally {
    await ai.files.delete({ name: uploaded.name }).catch(() => undefined);
  }
}

async function classifyProbeAndWebcam(
  ai: GoogleGenAI,
  probePath: string,
  req: AnalyzeVideoRequest
): Promise<{
  primaryCategory: ConcreteCategoryId;
  secondaryCategories: ConcreteCategoryId[];
  categoryConfidence: number;
  categoryReasoning: string;
  contentSummary: string;
  detectedWebcamPosition: DetectedWebcamPosition;
}> {
  const uploaded = await uploadAndWaitFile(ai, probePath, 'video/mp4');
  try {
    const contextHint = req.youtubeContext
      ? `Video Title: "${req.youtubeContext.title}"\nChannel: "${req.youtubeContext.channelTitle || 'Unknown'}"\n`
      : '';
    const prompt = `${contextHint}Classify this composite sample video (full video duration: ${Math.round(
      req.videoDuration
    )}s) and detect whether a streamer/creator webcam overlay box is visible.
Return JSON with:
- primaryCategory: one of ${CONCRETE_CATEGORIES.join(', ')}
- secondaryCategories: array of matching secondary category IDs
- categoryConfidence: 0-100
- categoryReasoning: concise explanation grounded in visual/audio cues
- contentSummary: concise 1-2 sentence summary of the video
- webcamPosition: corner where a webcam facecam box sits (top_left, top_right, bottom_left, bottom_right, top_center) or "none" if no webcam overlay is visible.`;

    const response = await generateWithModelFallback((model) =>
      ai.models.generateContent({
        model,
        contents: createUserContent([
          createPartFromUri(uploaded.uri, uploaded.mimeType),
          prompt,
        ]),
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              primaryCategory: { type: Type.STRING },
              secondaryCategories: { type: Type.ARRAY, items: { type: Type.STRING } },
              categoryConfidence: { type: Type.NUMBER },
              categoryReasoning: { type: Type.STRING },
              contentSummary: { type: Type.STRING },
              webcamPosition: { type: Type.STRING },
            },
            required: [
              'primaryCategory',
              'categoryConfidence',
              'categoryReasoning',
              'contentSummary',
              'webcamPosition',
            ],
          },
        },
      })
    );

    const parsed = JSON.parse((response.text ?? '{}').trim()) as ParsedGeminiOutput;
    const primary =
      !req.autoDetectCategory && req.selectedCategory !== 'auto'
        ? req.selectedCategory
        : toConcreteCategory(parsed.primaryCategory);
    const secondary = (parsed.secondaryCategories ?? [])
      .map((c) => toConcreteCategory(c))
      .filter((c, idx, arr) => c !== primary && arr.indexOf(c) === idx);

    return {
      primaryCategory: primary,
      secondaryCategories: secondary,
      categoryConfidence: Math.max(0, Math.min(100, Math.round(parsed.categoryConfidence ?? 86))),
      categoryReasoning:
        parsed.categoryReasoning?.trim() ||
        `Classified as ${CATEGORY_PROFILES[primary].label} from multimodal sample inspection.`,
      contentSummary: parsed.contentSummary?.trim() || '',
      detectedWebcamPosition: toWebcamPosition(parsed.webcamPosition),
    };
  } finally {
    await ai.files.delete({ name: uploaded.name }).catch(() => undefined);
  }
}

async function analyzeYouTubeTranscriptOnly(
  ai: GoogleGenAI,
  req: AnalyzeVideoRequest
): Promise<AnalyzeVideoResult> {
  const cues = req.youtubeContext?.transcriptSegments ?? [];
  if (cues.length === 0) {
    throw new Error(
      'Direct stream download was restricted by YouTube and no transcript is available for this video.'
    );
  }

  req.onProgress?.('Scanning YouTube transcript & heatmap highlights...', 35);
  const windows = selectCandidateWindows(req.videoDuration, {
    windowSeconds: 300,
    maxWindows: Math.min(6, Math.max(3, req.numberOfClips + 1)),
    activityPeaks: req.youtubeContext?.heatmapPeaks ?? [],
  });

  const windowTranscripts = windows
    .map((w, idx) => {
      const slice = cues
        .filter((c) => c.start >= w.start && c.start <= w.end)
        .slice(0, 120)
        .map((c) => `[${c.start.toFixed(1)}s] ${c.text}`)
        .join(' ');
      return `=== WINDOW ${idx + 1} (${w.start.toFixed(0)}s - ${w.end.toFixed(0)}s) ===\n${slice}`;
    })
    .join('\n\n');

  const prompt = `${buildGeminiAnalysisPrompt({
    videoDuration: req.videoDuration,
    selectedCategory: req.selectedCategory,
    autoDetectCategory: req.autoDetectCategory,
    autoDetectBestClips: req.autoDetectBestClips,
    numberOfClips: req.numberOfClips,
    durationPreset: req.durationPreset,
    aspectRatio: req.aspectRatio,
    captionLanguage: req.captionLanguage,
  })}

YOUTUBE VIDEO METADATA:
Title: ${req.youtubeContext?.title || 'Unknown'}
Channel: ${req.youtubeContext?.channelTitle || 'Unknown'}
Description: ${(req.youtubeContext?.description || '').slice(0, 600)}

TIME-SYNCED TRANSCRIPT WINDOWS (timestamps are absolute seconds in the full video):
${windowTranscripts}`;

  req.onProgress?.('Detecting category & scoring transcript highlights...', 60);
  const response = await generateWithModelFallback((model) =>
    ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: HIGHLIGHTS_RESPONSE_SCHEMA,
      },
    })
  );

  const parsed = JSON.parse((response.text ?? '{}').trim()) as ParsedGeminiOutput;
  const primary =
    !req.autoDetectCategory && req.selectedCategory !== 'auto'
      ? req.selectedCategory
      : toConcreteCategory(parsed.primaryCategory);
  const secondary = (parsed.secondaryCategories ?? [])
    .map((c) => toConcreteCategory(c))
    .filter((c, idx, arr) => c !== primary && arr.indexOf(c) === idx);
  const detectedWebcam = toWebcamPosition(parsed.webcamPosition);

  const clips = validateAndNormalizeClips(parsed.highlights ?? [], {
    videoDuration: req.videoDuration,
    selectedCategory: req.autoDetectCategory ? 'auto' : req.selectedCategory,
    detectedPrimaryCategory: primary,
    maxClips: req.numberOfClips,
    durationPreset: req.durationPreset,
    aspectRatio: req.aspectRatio,
    captionStyle: req.captionStyle,
    captionLanguage: req.captionLanguage,
    layoutPreference: req.layoutPreference,
    webcamPreference: req.webcamPreference,
    detectedWebcamPosition: detectedWebcam,
  });

  return {
    primaryCategory: primary,
    secondaryCategories: secondary,
    categoryConfidence: Math.max(0, Math.min(100, Math.round(parsed.categoryConfidence ?? 82))),
    categoryReasoning:
      parsed.categoryReasoning?.trim() ||
      `Classified as ${CATEGORY_PROFILES[primary].label} from YouTube metadata and transcript.`,
    contentSummary: parsed.contentSummary?.trim() || '',
    detectedWebcamPosition: detectedWebcam,
    clips,
  };
}

export async function analyzeVideoWithGemini(
  req: AnalyzeVideoRequest
): Promise<AnalyzeVideoResult> {
  const ai = createGeminiClient();
  const sizeBytes = req.sizeBytes ?? 0;
  const isRemote = /^https?:\/\//i.test(req.videoPath);
  const hasStreamSource = Boolean(req.videoPath);

  if (!hasStreamSource && req.youtubeContext) {
    return analyzeYouTubeTranscriptOnly(ai, req);
  }

  const useSinglePass =
    !isRemote && req.videoDuration <= 240 && sizeBytes > 0 && sizeBytes <= 25 * 1024 * 1024;

  if (useSinglePass) {
    req.onProgress?.('Uploading compact video to Gemini multimodal engine...', 15);
    const prompt = buildGeminiAnalysisPrompt({
      videoDuration: req.videoDuration,
      selectedCategory: req.selectedCategory,
      autoDetectCategory: req.autoDetectCategory,
      autoDetectBestClips: req.autoDetectBestClips,
      numberOfClips: req.numberOfClips,
      durationPreset: req.durationPreset,
      aspectRatio: req.aspectRatio,
      captionLanguage: req.captionLanguage,
    });

    req.onProgress?.('Detecting category, webcam framing & highlights...', 45);
    const parsed = await analyzeSingleMediaFile(ai, req.videoPath, req.mimeType, prompt);

    const detectedPrimary =
      !req.autoDetectCategory && req.selectedCategory !== 'auto'
        ? req.selectedCategory
        : toConcreteCategory(parsed.primaryCategory);
    const secondaryCategories = (parsed.secondaryCategories ?? [])
      .map((c) => toConcreteCategory(c))
      .filter((c, idx, arr) => c !== detectedPrimary && arr.indexOf(c) === idx);
    const detectedWebcam = toWebcamPosition(parsed.webcamPosition);

    const clips = validateAndNormalizeClips(parsed.highlights ?? [], {
      videoDuration: req.videoDuration,
      selectedCategory: req.autoDetectCategory ? 'auto' : req.selectedCategory,
      detectedPrimaryCategory: detectedPrimary,
      maxClips: req.numberOfClips,
      durationPreset: req.durationPreset,
      aspectRatio: req.aspectRatio,
      captionStyle: req.captionStyle,
      captionLanguage: req.captionLanguage,
      layoutPreference: req.layoutPreference,
      webcamPreference: req.webcamPreference,
      detectedWebcamPosition: detectedWebcam,
    });

    return {
      primaryCategory: detectedPrimary,
      secondaryCategories,
      categoryConfidence: Math.max(
        0,
        Math.min(100, Math.round(parsed.categoryConfidence ?? 85))
      ),
      categoryReasoning:
        parsed.categoryReasoning?.trim() ||
        `Classified as ${CATEGORY_PROFILES[detectedPrimary].label} based on visual and audio signals.`,
      contentSummary: parsed.contentSummary?.trim() || '',
      detectedWebcamPosition: detectedWebcam,
      clips,
    };
  }

  const sessionTag = `scan_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const probePath = path.join(PROXIES_DIR, `${sessionTag}_probe.mp4`);
  const tempFilesToClean: string[] = [probePath];

  try {
    req.onProgress?.('Building lightweight timeline probe for category & webcam detection...', 12);
    await extractCategoryProbeVideo({
      sourcePath: req.videoPath,
      outputPath: probePath,
      totalDuration: req.videoDuration,
      hasAudio: req.hasAudio ?? true,
    });

    req.onProgress?.('Classifying video category & detecting streamer webcam position...', 24);
    const classification = await classifyProbeAndWebcam(ai, probePath, req);

    req.onProgress?.('Scanning timeline energy peaks across full video...', 32);
    const audioPeaks = await detectAudioActivityPeaks({
      sourcePath: req.videoPath,
      totalDuration: req.videoDuration,
      hasAudio: req.hasAudio ?? true,
      maxPeaks: 6,
    });

    const combinedPeaks = [
      ...(req.youtubeContext?.heatmapPeaks ?? []),
      ...audioPeaks,
    ];

    const windowDuration = req.videoDuration > 1800 ? 120 : 140;
    const maxWindows = Math.min(7, Math.max(4, req.numberOfClips + 1));
    const windows = selectCandidateWindows(req.videoDuration, {
      windowSeconds: windowDuration,
      maxWindows,
      activityPeaks: combinedPeaks,
    });

    const allCandidates: RawHighlightCandidate[] = [];
    let completedWindows = 0;
    const perWindowTargetClips = Math.max(2, Math.ceil((req.numberOfClips + 2) / windows.length));

    const processWindow = async (
      win: { start: number; end: number },
      idx: number
    ): Promise<void> => {
      const dur = Math.max(8, win.end - win.start);
      const proxyPath = path.join(PROXIES_DIR, `${sessionTag}_w${idx}.mp4`);
      tempFilesToClean.push(proxyPath);

      await extractProxySegment({
        sourcePath: req.videoPath,
        outputPath: proxyPath,
        startTime: win.start,
        duration: dur,
        hasAudio: req.hasAudio ?? true,
        maxWidth: 480,
        fps: 2,
      });

      const windowPrompt = `${buildGeminiAnalysisPrompt({
        videoDuration: dur,
        selectedCategory: classification.primaryCategory,
        autoDetectCategory: false,
        autoDetectBestClips: req.autoDetectBestClips,
        numberOfClips: perWindowTargetClips,
        durationPreset: req.durationPreset,
        aspectRatio: req.aspectRatio,
        captionLanguage: req.captionLanguage,
      })}

WINDOW CONTEXT:
This segment spans ${Math.round(win.start)}s to ${Math.round(win.end)}s of a ${Math.round(
        req.videoDuration
      )}s video.
Return timestamps relative to THIS segment [0, ${dur.toFixed(2)}].
Detected webcam position: ${classification.detectedWebcamPosition}.`;

      const parsed = await analyzeSingleMediaFile(ai, proxyPath, 'video/mp4', windowPrompt);

      for (const h of parsed.highlights ?? []) {
        const localStart = Math.max(0, Math.min(dur - 1, Number(h.startTime) || 0));
        const localEnd = Math.max(localStart + 1, Math.min(dur, Number(h.endTime) || 0));
        const absStart = Number((win.start + localStart).toFixed(2));
        const absEnd = Number((win.start + localEnd).toFixed(2));

        const adjustedCaptions = (h.captions ?? []).map((cue) => {
          const looksLocal = cue.start <= dur + 1;
          const relStart = looksLocal ? cue.start - localStart : cue.start - absStart;
          const relEnd = looksLocal ? cue.end - localStart : cue.end - absStart;
          return {
            start: Math.max(0, relStart),
            end: Math.max(0, relEnd),
            text: cue.text,
          };
        });

        allCandidates.push({
          ...h,
          startTime: absStart,
          endTime: absEnd,
          detectedCategory: h.detectedCategory ?? classification.primaryCategory,
          webcamPosition: h.webcamPosition ?? classification.detectedWebcamPosition,
          captions: adjustedCaptions,
        });
      }

      completedWindows += 1;
      const pct = 36 + Math.round((completedWindows / windows.length) * 38);
      req.onProgress?.(
        `Analyzed window ${completedWindows}/${windows.length} (${Math.round(
          win.start / 60
        )}m–${Math.round(win.end / 60)}m)...`,
        pct
      );
    };

    let nextWindowIdx = 0;
    const workers = Array.from({ length: Math.min(2, windows.length) }, async () => {
      while (nextWindowIdx < windows.length) {
        const idx = nextWindowIdx++;
        try {
          await processWindow(windows[idx], idx);
        } catch (err) {
          console.warn(`Window ${idx} analysis skipped:`, err);
          completedWindows += 1;
        }
      }
    });
    await Promise.all(workers);

    if (allCandidates.length === 0) {
      if (req.youtubeContext?.transcriptSegments?.length) {
        return analyzeYouTubeTranscriptOnly(ai, req);
      }
      throw new Error(
        'Multimodal window analysis returned no highlight candidates. Check your Gemini API quota or try another video.'
      );
    }

    const clips = validateAndNormalizeClips(allCandidates, {
      videoDuration: req.videoDuration,
      selectedCategory: req.autoDetectCategory ? 'auto' : req.selectedCategory,
      detectedPrimaryCategory: classification.primaryCategory,
      maxClips: req.numberOfClips,
      durationPreset: req.durationPreset,
      aspectRatio: req.aspectRatio,
      captionStyle: req.captionStyle,
      captionLanguage: req.captionLanguage,
      layoutPreference: req.layoutPreference,
      webcamPreference: req.webcamPreference,
      detectedWebcamPosition: classification.detectedWebcamPosition,
    });

    return {
      primaryCategory: classification.primaryCategory,
      secondaryCategories: classification.secondaryCategories,
      categoryConfidence: classification.categoryConfidence,
      categoryReasoning: classification.categoryReasoning,
      contentSummary: classification.contentSummary,
      detectedWebcamPosition: classification.detectedWebcamPosition,
      clips,
    };
  } finally {
    await Promise.all(tempFilesToClean.map((p) => fs.unlink(p).catch(() => undefined)));
  }
}
