import test from 'node:test';
import assert from 'node:assert/strict';
import {
  assTimeToSeconds,
  groupWordCuesToCaptions,
  mapCaptionLanguage,
  mapFaceCropToCorner,
  mapSubScores,
  parseAssFileToWordCues,
  presetToWindow,
  verifiedMomentToClip,
  webcamCornerToCrop,
} from './localAnalyzer.ts';

test('presetToWindow maps short/balanced/deep to the delivered clip lengths', () => {
  assert.deepEqual(presetToWindow('short'), { pre: 10, post: 15 });
  assert.deepEqual(presetToWindow('balanced'), { pre: 15, post: 20 });
  assert.deepEqual(presetToWindow('deep'), { pre: 30, post: 45 });
});

test('mapCaptionLanguage maps UI labels to whisper codes and Auto to null', () => {
  assert.equal(mapCaptionLanguage('English'), 'en');
  assert.equal(mapCaptionLanguage('Urdu'), 'ur');
  assert.equal(mapCaptionLanguage('Hindi'), 'hi');
  assert.equal(mapCaptionLanguage('Auto / Original Language'), null);
  assert.equal(mapCaptionLanguage('Klingon'), null);
});

test('webcamCornerToCrop maps corners to fractions; auto/none pass through', () => {
  assert.equal(webcamCornerToCrop('top_right'), '0.75,0,0.25,0.35');
  assert.equal(webcamCornerToCrop('bottom_left'), '0,0.65,0.25,0.35');
  assert.equal(webcamCornerToCrop('auto'), 'auto');
  assert.equal(webcamCornerToCrop('none'), 'none');
});

test('mapFaceCropToCorner picks the nearest corner; no crop means none', () => {
  assert.equal(mapFaceCropToCorner([0.76, 0.0, 0.24, 0.285]), 'top_right');
  assert.equal(mapFaceCropToCorner([0.01, 0.44, 0.19, 0.24]), 'bottom_left');
  assert.equal(mapFaceCropToCorner(null), 'none');
  assert.equal(mapFaceCropToCorner(undefined), 'none');
});

test('assTimeToSeconds parses ASS timestamps', () => {
  assert.equal(assTimeToSeconds('0:00:03.50'), 3.5);
  assert.equal(assTimeToSeconds('0:01:02.25'), 62.25);
  assert.ok(Number.isNaN(assTimeToSeconds('garbage')));
});

test('parseAssFileToWordCues extracts the highlighted word per Dialogue line', () => {
  const ass = `[Script Info]
ScriptType: v4.00+
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,DejaVu Sans,84,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,8,2,5,40,40,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.50,0:00:00.80,Cap,,0,0,0,,{\\pos(540,1152)}{\\1c&H00FFFF&\\fscx118\\fscy118}FOUR{\\r} STAR PURSUIT
Dialogue: 0,0:00:00.80,0:00:01.10,Cap,,0,0,0,,{\\pos(540,1152)}FOUR {\\1c&H00FFFF&\\fscx118\\fscy118}STAR{\\r} PURSUIT
`;
  const words = parseAssFileToWordCues(ass);
  assert.equal(words.length, 2);
  assert.equal(words[0].text, 'FOUR');
  assert.equal(words[0].start, 0.5);
  assert.equal(words[1].text, 'STAR');
  assert.equal(words[1].end, 1.1);
});

test('groupWordCuesToCaptions groups words in threes', () => {
  const words = [
    { start: 0.5, end: 0.8, text: 'four' },
    { start: 0.8, end: 1.1, text: 'star' },
    { start: 1.1, end: 1.5, text: 'pursuit' },
    { start: 1.5, end: 1.9, text: 'near' },
  ];
  const cues = groupWordCuesToCaptions(words);
  assert.equal(cues.length, 2);
  assert.equal(cues[0].text, 'four star pursuit');
  assert.equal(cues[0].start, 0.5);
  assert.equal(cues[0].end, 1.5);
  assert.equal(cues[1].text, 'near');
});

test('mapSubScores scales the v7 /100 rubric onto the 8-factor breakdown', () => {
  const full = { reaction: 30, cause: 20, story: 15, chat: 15, quotable: 10, technical: 10 };
  const mapped = mapSubScores(full);
  assert.equal(mapped.hookStrength, 100);
  assert.equal(mapped.contextCompleteness, 100);
  assert.equal(mapped.emotionalIntensity, 100);
  assert.equal(mapped.valueScore, 100);
  assert.equal(mapped.retentionPotential, 100);
  const half = mapSubScores({ reaction: 15, cause: 10, story: 7, chat: 7, quotable: 5, technical: 5 });
  assert.equal(half.hookStrength, 50);
  assert.equal(half.emotionalIntensity, 50);
  assert.equal(half.retentionPotential, 48);
  assert.deepEqual(mapSubScores(undefined), {
    hookStrength: 0,
    contextCompleteness: 0,
    emotionalIntensity: 0,
    valueScore: 0,
    visualInterest: 0,
    audioInterest: 0,
    standaloneQuality: 0,
    retentionPotential: 0,
  });
});

test('verifiedMomentToClip keeps the v7 total as the overall score and marks the clip pre-rendered', () => {
  const clip = verifiedMomentToClip(
    {
      t: 100,
      emotion: 'rage',
      title: 'Rage at the cops',
      quote: 'are you serious right now',
      score: 82,
      reaction: 24,
      cause: 16,
      story: 12,
      chat: 10,
      quotable: 8,
      technical: 8,
      signals: 3,
      face: true,
      words: 120,
      mean_db: -18.5,
      max_db: -6.2,
      events: ['police', 'chase'],
    },
    {
      renderedFile: '/tmp/klipz-studio/clips/job1-short_01.mp4',
      outputFilename: 'job1-short_01.mp4',
      pre: 15,
      post: 20,
      videoDuration: 3600,
      category: 'gaming',
      captionLanguage: 'English',
      captionStyle: 'bold_kinetic',
      faceCrop: [0.76, 0.0, 0.24, 0.285],
      captions: [{ start: 0, end: 2, text: 'are you serious' }],
      wordCues: [{ start: 0, end: 0.4, text: 'are' }],
      segmentPath: '/tmp/klipz-studio/jobs/job1/_work/seg_01.mp4',
      segmentStart: 85,
      index: 0,
    }
  );
  assert.equal(clip.overallScore, 82);
  assert.equal(clip.startTime, 85);
  assert.equal(clip.endTime, 120);
  assert.equal(clip.duration, 35);
  assert.equal(clip.aspectRatio, '9:16');
  assert.equal(clip.layoutMode, 'split_cam_gameplay');
  assert.equal(clip.webcamPosition, 'top_right');
  assert.equal(clip.renderUrl, '/api/media/clips/job1-short_01.mp4');
  assert.equal(clip.outputPath, '/tmp/klipz-studio/clips/job1-short_01.mp4');
  assert.equal(clip.outputFilename, 'job1-short_01.mp4');
  assert.equal(clip.segmentPath, '/tmp/klipz-studio/jobs/job1/_work/seg_01.mp4');
  assert.ok(clip.reason.includes('rage'));
  assert.ok(clip.reason.includes('3 independent signals'));
  assert.ok(clip.reason.includes('police'));
});

test('verifiedMomentToClip without a face uses full_frame and no webcam', () => {
  const clip = verifiedMomentToClip(
    { t: 50, score: 75, reaction: 20, cause: 15, story: 10, chat: 5, quotable: 6, technical: 9 },
    {
      renderedFile: '/tmp/klipz-studio/clips/job1-short_02.mp4',
      outputFilename: 'job1-short_02.mp4',
      pre: 15,
      post: 20,
      videoDuration: 600,
      category: 'other',
      captionLanguage: 'English',
      captionStyle: 'clean_editorial',
      faceCrop: null,
      captions: [],
      wordCues: [],
      index: 1,
    }
  );
  assert.equal(clip.layoutMode, 'full_frame');
  assert.equal(clip.webcamPosition, 'none');
  assert.equal(clip.overallScore, 75);
});
