#!/usr/bin/env python3
"""
clip_stream.py - turn a finished YouTube live stream (or a local video file)
into vertical 9:16 shorts: gameplay on top, facecam at the bottom, CapCut-style
word-by-word captions. Built for low-RAM laptops (6 GB): audio-only analysis,
only the clip segments are downloaded, Whisper runs int8 on CPU.

Typical use
  python clip_stream.py --check
  python clip_stream.py URL --preview-face            # look at face_preview.jpg
  python clip_stream.py URL --detect-only             # list moments, no rendering
  python clip_stream.py URL --count 6 --face 0.75,0.62,0.25,0.35
  python clip_stream.py URL --times 3:00:00 --title "Mythpat Gets CHASED By Police"
"""
from __future__ import annotations

import argparse
from datetime import datetime
import glob
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

OUT_W, OUT_H = 1080, 1920
FACE_PANEL_H = 768


def log(msg: str) -> None:
    print(msg, flush=True)


def run(cmd, cwd=None):
    cmd = [str(c) for c in cmd]
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if p.returncode != 0:
        tail = (p.stderr or p.stdout or "")[-1800:]
        raise RuntimeError(f"Command failed: {' '.join(cmd[:4])} ...\n{tail}")
    return p


def ytdlp(args, cookies=None, prefer_android=False):
    """Run yt-dlp. On this network YouTube throttles the default (web) client
    to ~4-7 KB/s while the android player client runs at ~160 KB/s, so
    downloads try android first and fall back to web. Metadata calls keep
    web first (fast and reliable) with android as the fallback. Each client
    is tried once; a failure in both raises."""
    cmd = [sys.executable, "-m", "yt_dlp", "--no-warnings"]
    if cookies:
        cmd += ["--cookies-from-browser", cookies]
    android = ["--extractor-args", "youtube:player_client=android"]
    attempts = [android, []] if prefer_android else [[], android]
    last_err = None
    for extra in attempts:
        try:
            return run(cmd + extra + list(args))
        except Exception as e:
            last_err = e
            log(f"  (yt-dlp {'android' if extra else 'default'} client failed, "
                f"trying the other: {str(e)[:80]})")
    raise last_err


def parse_time(s: str) -> float:
    t = 0.0
    for part in s.strip().split(":"):
        t = t * 60 + float(part)
    return t


def fmt_time(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 3600}:{(sec // 60) % 60:02d}:{sec % 60:02d}"


def probe(path):
    p = run(["ffprobe", "-v", "error", "-print_format", "json",
             "-show_streams", "-show_format", path])
    d = json.loads(p.stdout)
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    dur = float(d.get("format", {}).get("duration") or 0)
    size = (int(v["width"]), int(v["height"])) if v else (0, 0)
    return size, dur


# --------------------------------------------------------------------------
# Dependency check
# --------------------------------------------------------------------------
def check_deps() -> bool:
    ok = True
    for tool in ("ffmpeg", "ffprobe"):
        path = shutil.which(tool)
        log(f"[{'OK' if path else 'MISSING'}] {tool} {path or '(install ffmpeg and add to PATH)'}")
        ok &= bool(path)
    for mod, pipname in (("yt_dlp", "yt-dlp"), ("faster_whisper", "faster-whisper"),
                         ("numpy", "numpy"), ("cv2", "opencv-python-headless")):
        try:
            __import__(mod)
            log(f"[OK] python module {mod}")
        except Exception:
            log(f"[MISSING] python module {mod}  ->  pip install {pipname}")
            ok &= False
    return ok


# --------------------------------------------------------------------------
# Moment detection (audio loudness spikes + chat message bursts)
# --------------------------------------------------------------------------
def audio_db_series(src, sr=8000, win=0.5):
    """Loudness in dB per `win` seconds, streamed from ffmpeg (tiny RAM use)."""
    import numpy as np
    n = int(sr * win)
    cmd = ["ffmpeg", "-v", "error", "-i", str(src), "-vn", "-ac", "1",
           "-ar", str(sr), "-f", "s16le", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    out, buf = [], b""
    while True:
        data = proc.stdout.read(n * 2 * 240)
        if not data:
            break
        buf += data
        k = len(buf) // (n * 2)
        if k:
            arr = np.frombuffer(buf[: k * n * 2], dtype=np.int16).astype(np.float32).reshape(k, n)
            out.append(20 * np.log10(np.sqrt((arr ** 2).mean(axis=1)) + 1.0))
            buf = buf[k * n * 2:]
    proc.wait()
    return np.concatenate(out) if out else np.zeros(0, dtype=np.float32)


def spike_scores(x, short, base, floor):
    """How far a short moving average sits above the local (long) baseline, in std-devs."""
    import numpy as np
    x = np.asarray(x, dtype=np.float64)
    if len(x) == 0:
        return x
    short = max(1, min(short, len(x)))
    base = max(1, min(base, len(x)))
    ks, kb = np.ones(short) / short, np.ones(base) / base
    norm = np.convolve(np.ones_like(x), kb, mode="same")
    s = np.convolve(x, ks, mode="same")
    m = np.convolve(x, kb, mode="same") / norm
    v = np.convolve(x * x, kb, mode="same") / norm - m * m
    sd = np.maximum(np.sqrt(np.maximum(v, 0)), floor)
    return (s - m) / sd


def chat_counts(path, length):
    import numpy as np
    c = np.zeros(length, dtype=np.float32)
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "addChatItemAction" not in line:
                continue
            try:
                o = json.loads(line)
                t = int(o["replayChatItemAction"]["videoOffsetTimeMsec"]) / 1000
            except Exception:
                continue
            if 0 <= t < length:
                c[int(t)] += line.count("addChatItemAction")
    return c


def detect_moments(audio_src, duration, chat_path, count, min_gap):
    import numpy as np
    length = int(duration)
    db = audio_db_series(audio_src)
    za = spike_scores(db, short=4, base=240, floor=2.0)
    if len(za) % 2:
        za = za[:-1]
    za1 = za.reshape(-1, 2).max(axis=1) if len(za) else za
    a = np.zeros(length, dtype=np.float32)
    m = min(length, len(za1))
    a[:m] = np.clip(za1[:m], 0, 8)

    c = np.zeros(length, dtype=np.float32)
    if chat_path:
        cc = chat_counts(chat_path, length)
        if cc.sum() >= 20:
            c = np.clip(spike_scores(cc, short=10, base=300, floor=1.0), 0, 8).astype(np.float32)

    score = a + c
    edge = 5
    picked = []
    for i in np.argsort(score)[::-1]:
        if score[i] <= 0:
            break
        if i < edge or i > length - edge:
            continue
        if all(abs(int(i) - j) >= min_gap for j in picked):
            picked.append(int(i))
        if len(picked) >= count:
            break
    return [{"t": t, "score": round(float(score[t]), 2),
             "audio": round(float(a[t]), 2), "chat": round(float(c[t]), 2)} for t in picked]


def transcript_marker_moments(model, audio_src, duration, lang, translate,
                              needed, min_gap, existing, work):
    """Supplement for speech-heavy content with even loudness (podcasts,
    documentaries, interviews): transcribe the full audio once and pick the
    most marker-dense passages (questions, numbers, quotes, reaction/event
    words). Only used for short videos (see main); for long streams the
    loudness scan is the cheap path and a full transcription is too slow."""
    wav = work / "full_transcribe.wav"
    run(["ffmpeg", "-y", "-v", "error", "-i", str(audio_src), "-vn",
         "-ac", "1", "-ar", "16000", str(wav)])
    segs, _info = model.transcribe(str(wav), language=lang,
                                   task="translate" if translate else "transcribe",
                                   word_timestamps=False, beam_size=1)
    cands = []
    for s in segs:
        text = (s.text or "").strip()
        if not text:
            continue
        words = text.split()
        if len(words) < 8:
            continue
        low = text.lower()
        score = 0
        if "?" in text:
            score += 3
        if re.search(r"\d", text):
            score += 2
        if any(w in low for w in ("wow", "oh my", "unbelievable", "look", "incredible")):
            score += 2
        score += min(3, sum(low.count(w) for ws in REACTION_WORDS.values() for w in ws))
        score += min(3, sum(low.count(w) for w in EVENT_WORDS))
        if score <= 0:
            continue
        t = int((s.start + s.end) / 2)
        cands.append({"t": t, "score": round(score / 10, 2),
                      "audio": None, "chat": None, "transcript": True})
    cands.sort(key=lambda c: c["score"], reverse=True)
    picked = []
    taken = [m["t"] for m in existing]
    for c in cands:
        if all(abs(c["t"] - j) >= min_gap for j in taken):
            picked.append(c)
            taken.append(c["t"])
        if len(picked) >= needed:
            break
    return picked


# --------------------------------------------------------------------------
# Captions (Whisper -> ASS, CapCut style: 3 words, active word yellow + bigger)
# --------------------------------------------------------------------------
def load_whisper(size):
    import os
    from faster_whisper import WhisperModel
    return WhisperModel(size, device="cpu", compute_type="int8",
                        cpu_threads=min(4, os.cpu_count() or 2))


def transcribe(model, wav, lang, task):
    # NOTE (2026-11-21, IShowSpeed GTA 6 job): vad_filter=True dropped most
    # speech on this loud music-heavy stream audio (verify got 10 words where
    # no-VAD tiny got 61). VAD off; base no-VAD gave 31 real words on the same
    # 30s window. Keep beam_size=1 for speed.
    segs, _info = model.transcribe(str(wav), language=lang, task=task,
                                   word_timestamps=True, beam_size=1)
    words = []
    for s in segs:
        for w in (s.words or []):
            t = w.word.strip()
            if t:
                words.append((float(w.start), float(w.end), t))
    return words


def ass_time(t: float) -> str:
    cs = max(0, int(round(t * 100)))
    return f"{cs // 360000}:{(cs // 6000) % 60:02d}:{(cs // 100) % 60:02d}.{cs % 100:02d}"


def _esc(t: str) -> str:
    return t.replace("\\", "").replace("{", "(").replace("}", ")")


def group_words(words, max_words=3, max_gap=0.7):
    groups, cur = [], []
    for w in words:
        if cur and (len(cur) >= max_words or w[0] - cur[-1][1] > max_gap
                    or cur[-1][2][-1:] in ".?!,"):
            groups.append(cur)
            cur = []
        cur.append(w)
    if cur:
        groups.append(cur)
    return groups


def build_ass(words, path, font="Arial", size=84, seam_y=1152, upper=True, hi="&H00FFFF&"):
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {OUT_W}
PlayResY: {OUT_H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{font},{size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,8,2,5,40,40,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    groups = group_words(words)
    lines = []
    for gi, g in enumerate(groups):
        next_start = groups[gi + 1][0][0] if gi + 1 < len(groups) else 1e9
        texts = [_esc(w[2].upper() if upper else w[2]) for w in g]
        for wi, w in enumerate(g):
            start = w[0]
            end = g[wi + 1][0] if wi + 1 < len(g) else min(w[1] + 0.25, next_start)
            if end <= start:
                end = start + 0.15
            parts = []
            for j, tx in enumerate(texts):
                if j == wi:
                    parts.append(r"{\1c" + hi + r"\fscx118\fscy118}" + tx + r"{\r}")
                else:
                    parts.append(tx)
            body = r"{\pos(" + f"{OUT_W // 2},{seam_y}" + r")}" + " ".join(parts)
            lines.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Cap,,0,0,0,,{body}")
    Path(path).write_text(head + "\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


# --------------------------------------------------------------------------
# Layout + render
# --------------------------------------------------------------------------
def even(v) -> int:
    return max(2, int(v) // 2 * 2)


def wrap_title(text: str, max_chars: int = 26):
    """Word-wrap a clip title into short lines for the overlay box."""
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = f"{cur} {w}".strip()
        if len(trial) > max_chars and cur:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines or [""]


def find_title_font():
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
              "C:\\Windows\\Fonts\\arialbd.ttf"):
        if Path(p).exists():
            return p
    return None


def parse_face(s):
    if s.strip().lower() == "none":
        return None
    x, y, w, h = [float(v) for v in s.split(",")]
    x, y = min(max(x, 0), 0.98), min(max(y, 0), 0.98)
    w, h = min(w, 1 - x), min(h, 1 - y)
    return x, y, w, h


# --------------------------------------------------------------------------
# Facecam auto-detection (--face auto): find the streamer's face in the
# stream itself, so every clip's face panel looks like the demo picture
# (face centred, filling the panel edge-to-edge).
# --------------------------------------------------------------------------
YUNET_URL = ("https://github.com/opencv/opencv_zoo/raw/main/models/"
               "face_detection_yunet/face_detection_yunet_2023mar.onnx")
YUNET_MODEL = Path(__file__).resolve().parent / "face_detection_yunet_2023mar.onnx"


def ensure_yunet_model():
    """Download the tiny YuNet face model once (228 KB) if it is missing."""
    if YUNET_MODEL.exists() and YUNET_MODEL.stat().st_size > 100_000:
        return YUNET_MODEL
    log("  downloading YuNet face model (once, 228 KB) ...")
    import urllib.request
    urllib.request.urlretrieve(YUNET_URL, str(YUNET_MODEL))
    if YUNET_MODEL.stat().st_size < 100_000:
        raise RuntimeError("YuNet model download looked wrong (too small)")
    return YUNET_MODEL


def detect_faces_cv2(jpg_path):
    """Faces in a frame as (x, y, w, h) pixel boxes, via YuNet (OpenCV 5).
    Haar cascades are gone in OpenCV 5, and YuNet is more accurate anyway
    (glasses, angled faces). Returns [] when nothing is found."""
    import cv2
    model = ensure_yunet_model()
    img = cv2.imread(str(jpg_path))
    if img is None:
        return []
    h, w = img.shape[:2]
    det = cv2.FaceDetectorYN.create(str(model), "", (w, h))
    det.setInputSize((w, h))
    _n, faces = det.detect(img)
    out = []
    if faces is not None:
        for f in faces:
            x, y, fw, fh, score = (float(v) for v in f[:5])
            if score >= 0.6:
                out.append((int(x), int(y), int(fw), int(fh)))
    return out


def detect_facecam(args, work, outdir, is_file, duration):
    """Sample frames across the stream, find the streamer's face, and return
    the crop as fractions (x, y, w, h) fitted to the face panel's aspect.
    Returns None when no face is found (caller falls back to a manual crop)."""
    try:
        import cv2  # noqa: F401
    except ImportError:
        log("  (face auto-detection needs opencv-python-headless: pip install opencv-python-headless)")
        return None
    if not duration:
        log("  (cannot auto-detect face: unknown duration)")
        return None
    fmt = f"bv*[height<={args.max_height}]+ba/b[height<={args.max_height}]/b"
    boxes, frame_size, last_jpg = [], None, None
    for frac in (0.1, 0.5, 0.9):
        t = duration * frac
        jpg = work / f"autoface_{int(t)}.jpg"
        try:
            if is_file:
                run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.1f}", "-i", args.source,
                     "-frames:v", "1", "-q:v", "4", str(jpg)])
            else:
                seg = download_segment(args.source, t, t + 3, fmt,
                                       str(work / f"autoface_{int(t)}"), args.cookies)
                run(["ffmpeg", "-y", "-v", "error", "-i", seg,
                     "-frames:v", "1", "-q:v", "4", str(jpg)])
        except Exception as e:
            log(f"  (face sample at {fmt_time(t)} failed: {str(e)[:100]})")
            continue
        if not jpg.exists():
            continue
        (w, h), _ = probe(str(jpg))
        frame_size = (w, h)
        last_jpg = jpg
        try:
            faces = detect_faces_cv2(jpg)
        except Exception as e:
            log(f"  (face detection failed: {e})")
            return None
        if faces:
            # Largest face = the streamer's cam (game NPC faces are smaller).
            boxes.append((t, max(faces, key=lambda b: b[2] * b[3])))
            log(f"  face found at {fmt_time(t)}: {boxes[-1][1]}")
    if not boxes:
        log("  no face detected in samples")
        return None
    w0, h0 = frame_size
    xs = [b[1][0] + b[1][2] / 2 for b in boxes]
    ys = [b[1][1] + b[1][3] / 2 for b in boxes]
    spread = (max(xs) - min(xs)) / w0 + (max(ys) - min(ys)) / h0
    if spread > 0.25:
        log("  WARNING: facecam moved during the stream — using the latest position; "
            "for early moments use a manual --face crop instead")
        box = boxes[-1][1]
    else:
        import statistics
        box = tuple(int(statistics.median([b[1][i] for b in boxes])) for i in range(4))
    # Expand to the face panel's aspect (1080x768 = 1.406). A streamer cam
    # shows head + shoulders — roughly 3x the face width — so a tight box
    # around just the face upscales into a blurry headshot with the head cut.
    # Widen to 3x the face width, then fit the panel aspect, keeping the
    # face centred, so the panel fills edge-to-edge like the demo picture.
    x, y, w, h = box
    cx, cy = x + w / 2, y + h / 2
    target = OUT_W / FACE_PANEL_H
    w2 = w * 3.0
    h2 = w2 / target
    w2, h2 = min(w2, w0), min(h2, h0)
    x2 = min(max(cx - w2 / 2, 0), w0 - w2)
    y2 = min(max(cy - h2 / 2, 0), h0 - h2)
    frac = (x2 / w0, y2 / h0, w2 / w0, h2 / h0)
    # Save a preview with the red box so the user can see what was detected.
    if last_jpg is not None:
        out = outdir / "face_preview_auto.jpg"
        vf = (f"drawbox=x={int(frac[0] * w0)}:y={int(frac[1] * h0)}:"
              f"w={int(frac[2] * w0)}:h={int(frac[3] * h0)}:color=red:t=6")
        try:
            run(["ffmpeg", "-y", "-v", "error", "-i", str(last_jpg), "-vf", vf, str(out)])
        except Exception:
            pass
    return frac


def build_filter(src_w, src_h, face, game_fit, game_x, ass_name, title_file=None, title_pos="center"):
    game_h = OUT_H - FACE_PANEL_H if face else OUT_H
    contain = game_fit == "contain"
    labels = (["g1", "g2"] if contain else ["g"]) + (["f"] if face else [])
    chains = []
    if len(labels) == 1:
        chains.append(f"[0:v]null[{labels[0]}]")
    else:
        chains.append(f"[0:v]split={len(labels)}" + "".join(f"[{l}]" for l in labels))

    if contain:
        chains.append(f"[g1]scale={OUT_W}:{game_h}:force_original_aspect_ratio=increase,"
                      f"crop={OUT_W}:{game_h},boxblur=30:5[bg]")
        chains.append(f"[g2]scale={OUT_W}:-2[fg]")
        chains.append("[bg][fg]overlay=(W-w)/2:(H-h)/2[game]")
    else:
        cw = min(src_w, even(src_h * OUT_W / game_h))
        x = even((src_w - cw) * min(max(game_x, 0), 1))
        chains.append(f"[g]crop={cw}:{src_h}:{x}:0,scale={OUT_W}:{game_h}[game]")

    tail = "setsar=1,format=yuv420p" + (f",ass={ass_name}" if ass_name else "")
    if title_file:
        # Title banner: black bold text on a white box, centred over the gameplay
        # panel (like the "Carry Steals A Car From Police Impound" reels).
        # The title lives in a file (textfile=) so multi-line wrapping works:
        # a backslash-n inside text='...' is eaten by the filter parser and
        # the whole title lands on one overflowing line.
        fontfile = find_title_font()
        font_opt = f"fontfile={fontfile}" if fontfile else "font='DejaVu Sans Bold'"
        fpath = str(title_file).replace("\\", "\\\\").replace(":", "\\:")
        if title_pos == "top":
            y = "120"
        else:  # centre of the gameplay panel
            y = f"({game_h}-text_h)/2"
        tail += (f",drawtext={font_opt}:textfile={fpath}:expansion=none:"
                 f"fontsize=64:fontcolor=black:"
                 f"box=1:boxcolor=white:boxborderw=22:x=(w-text_w)/2:y={y}")
    if face:
        fx, fy, fw, fh = face
        cx, cy = even(fx * src_w), even(fy * src_h)
        cwid, chei = even(fw * src_w), even(fh * src_h)
        chains.append(f"[f]crop={cwid}:{chei}:{cx}:{cy},"
                      f"scale={OUT_W}:{FACE_PANEL_H}:force_original_aspect_ratio=increase,"
                      f"crop={OUT_W}:{FACE_PANEL_H}[face]")
        chains.append(f"[game][face]vstack=inputs=2,{tail}[vout]")
    else:
        chains.append(f"[game]{tail}[vout]")
    return ";".join(chains)


def render(src, offset, dur, out_path, work, face, game_fit, game_x, ass_name,
           title=None, title_pos="center"):
    src = str(Path(src).resolve())      # absolute: ffmpeg runs with cwd=work
    out_path = str(Path(out_path).resolve())
    (w, h), _ = probe(src)
    title_file = None
    if title:
        title_file = Path(work) / "title.txt"
        title_file.write_text("\n".join(wrap_title(title)) + "\n", encoding="utf-8")
    fc = build_filter(w, h, face, game_fit, game_x, ass_name, title_file, title_pos)
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{offset:.2f}", "-t", f"{dur:.2f}",
           "-i", src, "-filter_complex", fc, "-map", "[vout]", "-map", "0:a:0?",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-threads", "2",
           "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out_path]
    run(cmd, cwd=work)   # cwd=work so the .ass file is found by relative name (Windows-safe)


# --------------------------------------------------------------------------
# Download helpers
# --------------------------------------------------------------------------
def first_file(pattern):
    files = [f for f in glob.glob(pattern) if not f.endswith((".part", ".ytdl"))]
    return files[0] if files else None


def get_info(url, cookies):
    p = ytdlp(["--dump-single-json", "--skip-download", "--no-playlist", url], cookies)
    return json.loads(p.stdout)


def download_segment(url, start, end, fmt, out_stem, cookies):
    ytdlp(["--no-playlist", "-f", fmt,
           "--download-sections", f"*{start:.0f}-{end:.0f}",
           "--force-keyframes-at-cuts", "--merge-output-format", "mp4",
           "-o", f"{out_stem}.%(ext)s", url], cookies, prefer_android=True)
    f = first_file(f"{out_stem}.*")
    if not f:
        raise RuntimeError("segment download produced no file")
    return f


def preview_face(args, work, outdir, is_file):
    at = args.at
    if is_file:
        src, off = args.source, at
    else:
        end = at + 3
        fmt = f"bv*[height<={args.max_height}]+ba/b[height<={args.max_height}]/b"
        src, off = download_segment(args.source, at, end, fmt, str(work / "preview"), args.cookies), 0
    (w, h), _ = probe(src)
    if args.face.strip().lower() == "auto":
        sys.exit("--preview-face needs a manual --face crop (e.g. 0.75,0.62,0.25,0.35); "
                 "--face auto saves face_preview_auto.jpg during a render run.")
    face = parse_face(args.face)
    out = outdir / "face_preview.jpg"
    if face:
        fx, fy, fw, fh = face
        vf = f"drawbox=x={int(fx*w)}:y={int(fy*h)}:w={int(fw*w)}:h={int(fh*h)}:color=red:t=6"
    else:
        vf = "null"
    run(["ffmpeg", "-y", "-v", "error", "-ss", str(off), "-i", src, "-frames:v", "1", "-vf", vf, out])
    log(f"Preview saved: {out}\nRed box = facecam crop ({args.face}). Adjust --face x,y,w,h (fractions 0-1) until the box fits the face.")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# v7: checkpoint/resume, auto-search, auto-verify — real code, not just prose.
# If the agent/server restarts mid-run, state.json in the output folder holds
# every completed stage; a re-run with the same source + --out resumes where
# it stopped instead of starting over.
# ---------------------------------------------------------------------------

def source_key(source, is_file):
    if is_file:
        p = Path(source).resolve()
        return f"file:{p}:{p.stat().st_size}"
    return f"url:{source.strip()}"


def load_state(outdir, key):
    """Saved checkpoint for this exact source, or None."""
    try:
        st = json.loads((outdir / "state.json").read_text(encoding="utf-8"))
        if st.get("source_key") == key:
            return st
        log("  (state file is for a different source — starting fresh)")
    except Exception:
        pass
    return None


def save_state(outdir, state):
    (outdir / "state.json").write_text(json.dumps(state, indent=2), encoding="utf-8")


def load_processed(outdir):
    """Video IDs already clipped from this output folder (daily mode)."""
    try:
        return json.loads((outdir / "processed.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def mark_processed(outdir, video_id, title, n_clips):
    p = load_processed(outdir)
    p[video_id] = {"title": title, "date": datetime.now().strftime("%Y-%m-%d"),
                   "clips": n_clips}
    (outdir / "processed.json").write_text(json.dumps(p, indent=2), encoding="utf-8")


def search_videos(query, days, count, processed):
    """Top-viewed recent videos for a query, via yt-dlp ytsearch (no API key).
    Keeps ENDED lives/uploads from the last `days` days, duration >= 10 min,
    sorts by view count. Full (non-flat) search is used on purpose: flat
    search results have no upload date or view count. Raises RuntimeError
    if YouTube blocks the search."""
    n = max(count * 4, 20)
    p = ytdlp(["--dump-single-json", "--no-playlist", f"ytsearch{n}:{query}"], None)
    data = json.loads(p.stdout)
    today = datetime.now().date()
    out = []
    for e in data.get("entries") or []:
        if not e or not e.get("id"):
            continue
        if e.get("live_status") in ("is_live", "is_upcoming", "post_live"):
            continue  # only ended streams / uploads
        vid, dur, views = e["id"], e.get("duration") or 0, e.get("view_count") or 0
        ud = e.get("upload_date") or ""
        try:
            age = (today - datetime.strptime(ud, "%Y%m%d").date()).days
        except Exception:
            age = 999
        if age > days or dur < 600:
            continue
        out.append({"id": vid, "title": e.get("title", ""), "views": views,
                    "date": ud, "duration": dur,
                    "url": e.get("webpage_url") or f"https://www.youtube.com/watch?v={vid}",
                    "done": vid in processed})
    out.sort(key=lambda r: r["views"], reverse=True)
    return out[:count]


# --- auto-verify: the viral-moment rubric, as code --------------------------
# Heuristic auto-scores (transcript markers + audio shape + chat + face).
# They are an approximation of the human rubric, not a replacement for it:
# the table is labelled "auto" and the agent reviews it before publishing.

REACTION_WORDS = {
    "rage": ["fuck", "shit", "damn", "bitch", "idiot", "hate", "broken", "chutiya", "bakwas", "saala", "bc", "mc"],
    "panic": ["no no", "sorry", "please", "help", "go away", "oh no", "run", "bhaag", "nahi nahi", "arre arre"],
    "laughter": ["haha", "hahaha", "lol", "lmao", "hehe", "ha ha"],
    "shock": ["oh my god", "omg", "what", "kya", "no way", "unbelievable", "wow", "arre", "aiyyo", "what the"],
    "triumph": ["yes", "won", "finally", "let's go", "come on", "jeet", "chalo", "got it"],
}
EVENT_WORDS = ["police", "chase", "kill", "killed", "died", "dead", "crash", "crashed",
               "win", "won", "caught", "escape", "glitch", "explosion", "bomb", "jump",
               "fell", "stole", "rob", "fight", "shoot", "shot", "gun", "wasted", "busted",
               "helicopter", "chopper", "tank", "plane"]


def _window_audio_stats(wav_path):
    """(mean_db, max_db, first_2s_silent) for one window wav."""
    mean = maxv = None
    # NOTE (2026-11-21): volumedetect logs at info level; -v error suppressed
    # it so mean/max were always None. Use -v info here (run() only raises on
    # non-zero returncode, so the extra lines are harmless).
    try:
        p = run(["ffmpeg", "-v", "info", "-i", str(wav_path), "-vn",
                 "-af", "volumedetect", "-f", "null", "-"])
        for line in (p.stderr or "").splitlines():
            if "mean_volume" in line:
                mean = float(line.split("mean_volume:")[1].split("dB")[0])
            if "max_volume" in line:
                maxv = float(line.split("max_volume:")[1].split("dB")[0])
    except Exception:
        pass
    silent = True
    try:
        import numpy as np
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(wav_path), "-t", "2",
                              "-f", "s16le", "-ac", "1", "-ar", "16000", "-"],
                             capture_output=True, check=True).stdout
        a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
        silent = not (len(a) and np.max(np.abs(a)) > 500)
    except Exception:
        pass
    return mean, maxv, silent


def _face_at_peak(args, work, is_file, duration, t):
    """True if a face is visible at time t (YuNet on one frame)."""
    try:
        jpg = work / "verify_face.jpg"
        if is_file:
            run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.1f}", "-i", args.source,
                 "-frames:v", "1", "-q:v", "3", str(jpg)])
        else:
            fmt = f"bv*[height<={args.max_height}]+ba/b[height<={args.max_height}]/b"
            seg, _off = download_segment(args.source, max(0.0, t - 1.5),
                                         min(duration, t + 1.5), fmt,
                                         str(work / "verify_face"), args.cookies)
            run(["ffmpeg", "-y", "-v", "error", "-ss", "1.5", "-i", seg,
                 "-frames:v", "1", "-q:v", "3", str(jpg)])
        return bool(detect_faces_cv2(jpg))
    except Exception as e:
        log(f"    (face check skipped: {str(e)[:80]})")
        return False


def verify_moments(args, work, outdir, is_file, duration, moments, model):
    """Score each candidate /100 (heuristic, auto) and reject weak ones.
    Returns (kept, rejected). Saves verified.json and prints the table."""
    kept, rejected = [], []
    for idx, m in enumerate(moments, 1):
        t = m["t"]
        w0 = max(0.0, t - 30)
        w1 = min(duration, t + 15) if duration else t + 15
        log(f"  [{idx}/{len(moments)}] verifying {fmt_time(t)} ...")
        words, wav = [], None
        try:
            wav = work / f"verify_{idx:02d}.wav"
            if is_file:
                run(["ffmpeg", "-y", "-v", "error", "-ss", f"{w0:.2f}", "-t", f"{w1 - w0:.2f}",
                     "-i", args.source, "-vn", "-ac", "1", "-ar", "16000", wav])
            else:
                seg = download_segment(args.source, w0, w1, "worstaudio/worst",
                                       str(work / f"verify_{idx:02d}"), args.cookies)
                run(["ffmpeg", "-y", "-v", "error", "-i", seg, "-vn", "-ac", "1",
                     "-ar", "16000", wav])
            words = transcribe(model, wav, args.lang,
                               "translate" if args.translate else "transcribe")
        except Exception as e:
            log(f"    (verify failed: {str(e)[:100]})")
            words = []
        text = " ".join(w[2] for w in words).strip()
        n_words = len(text.split())
        low = text.lower()
        hits = {k: sum(low.count(w) for w in ws) for k, ws in REACTION_WORDS.items()}
        total_hits = sum(hits.values())
        emotion = max(hits, key=hits.get) if total_hits else "none"
        mean_db, max_db, silent2 = (None, None, True)
        if wav is not None and wav.exists():
            mean_db, max_db, silent2 = _window_audio_stats(wav)
        # reaction (30): marker hits + loudness
        reaction = 0
        if total_hits >= 4:
            reaction = 26
        elif total_hits == 3:
            reaction = 22
        elif total_hits == 2:
            reaction = 18
        elif total_hits == 1:
            reaction = 12
        if max_db is not None and max_db > -6:
            reaction = min(30, reaction + 4)
        elif max_db is not None and max_db > -12:
            reaction = min(30, reaction + 2)
        # Klipz Ai: questions and numbers are engagement markers in
        # speech-heavy content — a passage that asks or quantifies holds
        # attention even without shouting. Without this, even-paced narration
        # caps at ~59/100 and can never pass the 70 threshold.
        n_questions = text.count("?")
        n_numbers = len(re.findall(r"\d+", text))
        if n_questions:
            reaction = min(30, reaction + 8)
        if n_numbers:
            reaction = min(30, reaction + 4)
        if n_words == 0:
            reaction = 0
        # cause (20): a real event + enough speech
        ev = [w for w in EVENT_WORDS if w in low]
        cause = (12 if ev else 0) + (8 if n_words >= 15 else (4 if n_words >= 8 else 0))
        # concrete, specific content (numbers / questions) strengthens the cause
        if n_questions or n_numbers >= 2:
            cause = min(20, cause + 4)
        # story (15): speech in both halves of the window
        mid = (w1 - w0) / 2
        in_first = any(w[0] < mid for w in words)
        in_second = any(w[0] >= mid for w in words)
        story = 15 if (in_first and in_second) else (8 if (in_first or in_second) else 0)
        # chat (15): burst at the peak, from detection
        chat = m.get("chat") or 0
        chat_pts = 15 if chat >= 20 else (10 if chat >= 10 else (6 if chat >= 5 else (3 if chat > 0 else 0)))
        # quotable (10): a short exclamatory line
        quote, quotable = "", 0
        if text:
            sents = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
            markers = ("oh", "what", "fuck", "shit", "no", "yes", "wow", "haha",
                       "come on", "let's go", "kya", "arre")
            cands = [s for s in sents if 2 <= len(s.split()) <= 8
                     and any(mk in s.lower() for mk in markers)]
            if cands:
                quote = max(cands, key=lambda s: sum(s.lower().count(mk) for mk in markers))
                quotable = 10
            else:
                quotable = 4
        # technical (10): audible, loud enough, first 2s not silent
        tech = (5 if (mean_db is not None and mean_db > -32) else 0) \
             + (3 if (max_db is not None and max_db > -10) else 0) \
             + (2 if not silent2 else 0)
        # signals: need at least 2 independent ones
        face_present = _face_at_peak(args, work, is_file, duration, t) \
            if args.face.strip().lower() != "none" else False
        audio_shape = bool(max_db is not None and max_db > -8) or \
            bool(mean_db is not None and mean_db > -24)
        signals = sum([reaction > 0, audio_shape, chat > 0, face_present])
        total = reaction + cause + story + chat_pts + quotable + tech
        auto_title = quote.strip().capitalize()[:45] if quote else (
            f"{emotion.capitalize()}: {ev[0]}" if ev else f"{emotion.capitalize()} moment")
        rec = {"t": t, "emotion": emotion, "score": total, "reaction": reaction,
               "cause": cause, "story": story, "chat": chat_pts, "quotable": quotable,
               "technical": tech, "signals": signals, "face": face_present,
               "quote": quote, "title": auto_title, "words": n_words,
               "mean_db": mean_db, "max_db": max_db, "events": ev}
        # Klipz Ai adaptation: the intro/outro rejection only applies to long
        # videos (>= 10 min, e.g. streams/VODs whose intros and outros are
        # countdowns and sign-offs). For short uploads the whole video is
        # content — applying a 2-minute exclusion would reject everything in
        # a sub-4-minute video.
        if duration and duration >= 600 and (t < 120 or t > duration - 120):
            rec["verdict"] = "REJECTED (intro/outro)"
            rejected.append(rec)
        elif n_words == 0:
            rec["verdict"] = "REJECTED (no speech)"
            rejected.append(rec)
        elif signals < 2:
            rec["verdict"] = "REJECTED (single signal)"
            rejected.append(rec)
        elif total < 70:
            rec["verdict"] = f"REJECTED (score {total} < 70)"
            rejected.append(rec)
        else:
            rec["verdict"] = "KEPT"
            kept.append(rec)
    # dedupe: same emotion within 10 min of a higher pick — keep the higher one
    kept.sort(key=lambda r: r["score"], reverse=True)
    final, dropped = [], []
    for r in kept:
        if any(r["emotion"] == k["emotion"] and abs(r["t"] - k["t"]) < 600 for k in final):
            r["verdict"] = "REJECTED (same kind within 10 min of a higher pick)"
            dropped.append(r)
        else:
            final.append(r)
    rejected.extend(dropped)
    final.sort(key=lambda r: r["t"])
    (outdir / "verified.json").write_text(
        json.dumps({"kept": final, "rejected": rejected}, indent=2), encoding="utf-8")
    log("\nVerified moments (auto-scored, heuristic — agent reviews before publishing):")
    log("| # | Time | Emotion | Score | Signals | Quote | Verdict |")
    for i, r in enumerate(final, 1):
        log(f"| {i} | {fmt_time(r['t'])} | {r['emotion']} | {r['score']}/100 | "
            f"{r['signals']} | {r['quote'][:40]} | KEPT |")
    for r in rejected:
        log(f"| - | {fmt_time(r['t'])} | {r['emotion']} | {r['score']}/100 | "
            f"{r['signals']} | {r['quote'][:40]} | {r['verdict']} |")
    return final, rejected


def main():
    ap = argparse.ArgumentParser(description="Make vertical shorts from a YouTube stream VOD or local video.")
    ap.add_argument("source", nargs="?", help="YouTube URL (ended stream/VOD) or path to a local video file")
    ap.add_argument("--check", action="store_true", help="check dependencies and exit")
    ap.add_argument("--search", help="find top-viewed recent videos instead of a URL, e.g. 'GTA 6 live Hindi' (include the language in the query)")
    ap.add_argument("--pick", type=int, default=None, help="with --search: run the pipeline on result #N")
    ap.add_argument("--search-days", type=int, default=2, help="with --search: only uploads from the last N days")
    ap.add_argument("--search-count", type=int, default=5, help="with --search: how many results to list")
    ap.add_argument("--daily", action="store_true", help="with --search: hide videos already clipped (processed.json)")
    ap.add_argument("--no-verify", action="store_true", help="skip auto-verification/scoring of moments")
    ap.add_argument("--fresh", action="store_true", help="ignore the saved checkpoint (state.json) and start over")
    ap.add_argument("--out", default="shorts_output", help="output folder")
    ap.add_argument("--count", type=int, default=5, help="how many shorts to make")
    ap.add_argument("--pre", type=float, default=15, help="seconds before the peak")
    ap.add_argument("--post", type=float, default=20, help="seconds after the peak")
    ap.add_argument("--min-gap", type=float, default=90, help="minimum seconds between two picked moments")
    ap.add_argument("--times", help="skip detection; comma-separated peak times like 1:23:45,2:10:00")
    ap.add_argument("--detect-only", action="store_true", help="only list the moments, do not render")
    ap.add_argument("--face", default="auto",
                    help="facecam rectangle as fractions x,y,w,h of the stream frame, 'none' (no facecam), or 'auto' (detect the streamer's face automatically, default)")
    ap.add_argument("--title", default=None,
                    help="title text burned onto every clip (white box, black bold text), e.g. 'Carry Steals A Car From Police Impound'")
    ap.add_argument("--title-position", choices=["center", "top"], default="top",
                    help="where the title box sits over the gameplay panel (default: top)")
    ap.add_argument("--game-fit", choices=["cover", "contain"], default="cover",
                    help="cover = crop sides to fill top panel; contain = whole frame over blurred background")
    ap.add_argument("--game-x", type=float, default=0.5, help="cover mode: horizontal crop position 0=left 1=right")
    ap.add_argument("--preview-face", action="store_true", help="save face_preview.jpg with the crop box and exit")
    ap.add_argument("--at", type=float, default=300, help="preview: time in seconds to grab a frame from")
    ap.add_argument("--max-height", type=int, default=720, help="download resolution cap (720 is good for 6 GB RAM)")
    ap.add_argument("--whisper-model", default="base", help="tiny | base | small (small is better, slower)")
    ap.add_argument("--lang", default=None, help="speech language code (ur, hi, en...). Default: auto-detect")
    ap.add_argument("--translate", action="store_true", help="captions translated to English")
    ap.add_argument("--font", default="Arial", help="caption font (use a font that has your script, e.g. 'Noto Nastaliq Urdu')")
    ap.add_argument("--font-size", type=int, default=84)
    ap.add_argument("--no-upper", action="store_true", help="do not uppercase captions")
    ap.add_argument("--no-captions", action="store_true")
    ap.add_argument("--chat-json", help="existing .live_chat.json file (skips chat download)")
    ap.add_argument("--no-chat", action="store_true", help="do not download chat replay")
    ap.add_argument("--cookies", help="browser name for yt-dlp cookies, e.g. chrome, firefox, edge")
    ap.add_argument("--keep-temp", action="store_true")
    args = ap.parse_args()

    if args.check:
        sys.exit(0 if check_deps() else 1)

    # ---- auto-search (Step 0 in code): find the most-viewed recent lives --
    if args.search:
        outdir = Path(args.out).resolve()
        outdir.mkdir(parents=True, exist_ok=True)
        processed = load_processed(outdir) if args.daily else {}
        try:
            results = search_videos(args.search, args.search_days, args.search_count, processed)
        except Exception as e:
            sys.exit(f"Search failed (YouTube may be blocking this machine — try again later, "
                     f"or pass a link directly): {str(e)[:200]}")
        if not results:
            sys.exit(f"No videos found for '{args.search}' in the last {args.search_days} day(s).")
        log(f"\nTop-viewed '{args.search}' (last {args.search_days} day(s)):")
        for i, r in enumerate(results, 1):
            done = " [already clipped]" if r["done"] else ""
            log(f"  {i}. {r['title'][:70]}  |  {r['views']:,} views  |  {r['date']}  |  "
                f"{fmt_time(r['duration'])}{done}\n     {r['url']}")
        if not args.pick:
            log("\nRe-run with --pick N to clip one of these.")
            return
        if not (1 <= args.pick <= len(results)):
            sys.exit(f"--pick must be 1..{len(results)}")
        args.source = results[args.pick - 1]["url"]
        log(f"\nPicked #{args.pick}: {results[args.pick - 1]['title']}")
    if not args.source:
        ap.error("source (URL or file) is required (or use --search)")
    if not shutil.which("ffmpeg"):
        sys.exit("ffmpeg not found. Install it and add it to PATH (see SKILL.md).")

    outdir = Path(args.out).resolve()
    work = outdir / "_work"
    outdir.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    is_file = Path(args.source).exists()

    # ---- checkpoint: resume from state.json if this source was started ----
    key = source_key(args.source, is_file)
    state = None if args.fresh else load_state(outdir, key)
    if state:
        log(f"Resuming from checkpoint (stage: {state.get('stage', '?')}) — "
            "completed stages will be skipped.")
    if not state:
        state = {"version": 7, "source_key": key, "source": args.source,
                 "stage": "started", "moments": [], "verified": [],
                 "rendered": [], "face": None, "title": "", "duration": 0}
    if args.fresh and (outdir / "state.json").exists():
        (outdir / "state.json").unlink()

    if args.preview_face:
        preview_face(args, work, outdir, is_file)
        return

    # ---- source info (skipped on resume) ---------------------------------
    title = Path(args.source).stem if is_file else ""
    if state.get("duration") and state.get("title"):
        duration = float(state["duration"])
        title = state["title"]
        log(f"Source: {title}  |  length {fmt_time(duration)}  (from checkpoint)")
    elif is_file:
        _, duration = probe(args.source)
        state["duration"] = duration
        state["title"] = title
        state["stage"] = "info"
        save_state(outdir, state)
    else:
        log("[1/5] Reading video info ...")
        info = get_info(args.source, args.cookies)
        status = info.get("live_status")
        if info.get("is_live") or status in ("is_live", "is_upcoming", "post_live"):
            sys.exit(f"This stream is not finished yet (live_status={status}). "
                     "Wait until the stream ends and YouTube finishes processing, then run again.")
        duration = float(info.get("duration") or 0)
        title = info.get("title", "")
        state["duration"] = duration
        state["title"] = title
        state["video_id"] = info.get("id", "")
        state["stage"] = "info"
        save_state(outdir, state)
    log(f"Source: {title or args.source}  |  length {fmt_time(duration)}")

    # ---- find moments (skipped on resume) --------------------------------
    # The Whisper model is loaded lazily — the transcript supplement (below)
    # may load it during detection, and verify reuses it.
    model = None
    if args.times:
        moments = [{"t": int(parse_time(t)), "score": None, "audio": None, "chat": None}
                   for t in args.times.split(",")]
        state["moments"] = moments
        save_state(outdir, state)  # keep stage as-is (a later stage may exist)
    elif state.get("moments"):
        moments = state["moments"]
        log(f"  (resuming: {len(moments)} saved moments from checkpoint)")
    else:
        log("[2/5] Finding shocking moments (audio spikes + chat bursts) ...")
        if is_file:
            audio_src, chat_path = args.source, args.chat_json
        else:
            audio_src = first_file(str(work / "audio.*"))
            if audio_src:
                log("  (reusing downloaded audio from checkpoint)")
            else:
                ytdlp(["--no-playlist", "-f", "worstaudio/worst",
                       "-o", str(work / "audio.%(ext)s"), args.source], args.cookies,
                      prefer_android=True)
                audio_src = first_file(str(work / "audio.*"))
            chat_path = args.chat_json
            if not chat_path and not args.no_chat:
                try:
                    ytdlp(["--skip-download", "--write-subs", "--sub-langs", "live_chat",
                           "--no-playlist", "-o", str(work / "chat"), args.source], args.cookies)
                    chat_path = first_file(str(work / "chat*.live_chat.json"))
                except Exception as e:
                    log(f"  (chat replay not available, using audio only: {str(e)[:120]})")
        if not audio_src:
            sys.exit("Could not get audio for analysis.")
        log(f"  chat replay: {'yes' if chat_path else 'no (audio only)'}")
        moments = detect_moments(audio_src, duration, chat_path, args.count, args.min_gap)
        # Supplement: speech-heavy content with even loudness (podcasts,
        # documentaries) produces few loudness spikes. For short videos
        # (<= 30 min) a single full transcription is cheap, so add the most
        # marker-dense passages as extra candidates. Long streams skip this
        # (full transcription is too slow; loudness works there).
        if duration and duration <= 1800 and len(moments) < args.count * 2:
            try:
                log("  (few loudness spikes — adding transcript-marker candidates ...)")
                if model is None:
                    model = load_whisper(args.whisper_model)
                extra = transcript_marker_moments(
                    model, audio_src, duration, args.lang, args.translate,
                    args.count * 2 - len(moments), args.min_gap, moments, work)
                if extra:
                    moments = moments + extra
                    log(f"  (+{len(extra)} transcript-marker candidates)")
            except Exception as e:
                log(f"  (transcript supplement skipped: {str(e)[:100]})")
        state["moments"] = moments
        state["stage"] = "detected"
        save_state(outdir, state)

    log("\nMoments found:")
    for i, m in enumerate(moments, 1):
        extra = "" if m["score"] is None else f"  score {m['score']} (audio {m['audio']}, chat {m['chat']})"
        log(f"  #{i}  {fmt_time(m['t'])}{extra}")
    (outdir / "moments.json").write_text(json.dumps(moments, indent=2), encoding="utf-8")
    if args.detect_only:
        log(f"\nSaved {outdir / 'moments.json'}. Re-run with --times to render chosen ones.")
        return

    # ---- verify + score moments (default on; skipped on resume) ----------
    verify = not args.no_verify
    if verify:
        if model is None:
            log("[3/5] Loading Whisper model for verification (first run downloads it) ...")
            model = load_whisper(args.whisper_model)
        saved = {round(v["t"]): v for v in state.get("verified", [])}
        to_verify = [m for m in moments if round(m["t"]) not in saved]
        if to_verify:
            log("[4/5] Verifying moments (transcript + audio shape + chat + face) ...")
            kept, rejected = verify_moments(args, work, outdir, is_file, duration,
                                            to_verify, model)
            merged = list(state.get("verified", [])) + kept + rejected
            state["verified"] = merged
            state["stage"] = "verified"
            save_state(outdir, state)
        else:
            log("  (resuming: using verified moments from checkpoint)")
        # render only the KEPT verified moments from THIS run's list, top --count
        by_t = {round(v["t"]): v for v in state.get("verified", [])
                if v.get("verdict") == "KEPT"}
        render_moments = []
        for m in moments:
            v = by_t.get(round(m["t"]))
            if v:
                render_moments.append({"t": v["t"], "score": v["score"], "audio": None,
                                       "chat": None, "title": v["title"],
                                       "emotion": v["emotion"]})
        render_moments.sort(key=lambda r: r["score"], reverse=True)
        moments = render_moments[:args.count]
        moments.sort(key=lambda m: m["t"])
        if not moments:
            log("\nNo moment passed verification (all rejected). Nothing to render.")
            return
        log(f"\nRendering {len(moments)} verified moment(s).")
    elif not args.no_captions:
        log("[3/5] Loading Whisper model (first run downloads it) ...")
        model = load_whisper(args.whisper_model)

    # ---- facecam (reused from checkpoint on resume) ----------------------
    if state.get("face"):
        face = tuple(state["face"])
        log(f"Facecam from checkpoint: {','.join(f'{v:.3f}' for v in face)}")
    elif args.face.strip().lower() == "auto":
        log("Auto-detecting facecam ...")
        auto = detect_facecam(args, work, outdir, is_file, duration)
        if auto:
            face = auto
            state["face"] = list(auto)
            state["stage"] = "face"
            save_state(outdir, state)
            log(f"  facecam detected: {','.join(f'{v:.3f}' for v in auto)} "
                f"(preview: {outdir / 'face_preview_auto.jpg'})")
        else:
            face = parse_face("0.75,0.62,0.25,0.35")
            state["face"] = list(face)
            save_state(outdir, state)
            log("  face auto-detection failed — using default crop 0.75,0.62,0.25,0.35")
    else:
        face = parse_face(args.face)
        state["face"] = list(face) if face else None
        save_state(outdir, state)
    fmt = f"bv*[height<={args.max_height}]+ba/b[height<={args.max_height}]/b"
    results = []
    rendered_times = {round(r["t"]) for r in state.get("rendered", [])}
    for i, m in enumerate(moments, 1):
        start = max(0.0, m["t"] - args.pre)
        end = min(duration, m["t"] + args.post) if duration else m["t"] + args.post
        dur = end - start
        out_path = outdir / f"short_{i:02d}_{fmt_time(m['t']).replace(':', 'h', 1).replace(':', 'm') }s.mp4"
        if round(m["t"]) in rendered_times and out_path.exists():
            log(f"\n[{i}/{len(moments)}] {fmt_time(m['t'])} — already rendered, skipping (resume)")
            results.append(str(out_path))
            continue
        clip_title = args.title or m.get("title")
        log(f"\n[{i}/{len(moments)}] clip around {fmt_time(m['t'])}  ({fmt_time(start)} - {fmt_time(end)})"
            + (f"  title: {clip_title}" if clip_title else ""))
        try:
            if is_file:
                seg, off = args.source, start
            else:
                log("  downloading segment ...")
                seg, off = download_segment(args.source, start, end, fmt, str(work / f"seg_{i:02d}"), args.cookies), 0.0

            ass_name = None
            if model:
                log("  transcribing for captions ...")
                wav = work / f"seg_{i:02d}.wav"
                run(["ffmpeg", "-y", "-v", "error", "-ss", f"{off:.2f}", "-t", f"{dur:.2f}", "-i", seg,
                     "-vn", "-ac", "1", "-ar", "16000", wav])
                words = transcribe(model, wav, args.lang, "translate" if args.translate else "transcribe")
                if words:
                    seam = (OUT_H - FACE_PANEL_H) if face else int(OUT_H * 0.72)
                    ass_name = f"cap_{i:02d}.ass"
                    build_ass(words, work / ass_name, font=args.font, size=args.font_size,
                              seam_y=seam, upper=not args.no_upper)
                else:
                    log("  no speech found, rendering without captions")

            log("  rendering ...")
            render(seg, off, dur, str(out_path), str(work), face, args.game_fit, args.game_x,
                   ass_name, clip_title, args.title_position)
            results.append(str(out_path))
            state["rendered"] = [r for r in state.get("rendered", [])
                                 if round(r["t"]) != round(m["t"])]
            state["rendered"].append({"t": m["t"], "file": out_path.name,
                                     "title": clip_title or ""})
            state["stage"] = "rendered"
            save_state(outdir, state)
            log(f"  done -> {out_path.name}")
        except Exception as e:
            log(f"  FAILED: {e}")

    if not args.keep_temp:
        shutil.rmtree(work, ignore_errors=True)
    if state.get("video_id"):
        mark_processed(outdir, state["video_id"], title, len(results))
    log(f"\nFinished. {len(results)} short(s) in {outdir}")
    for r in results:
        log(f"  {r}")


if __name__ == "__main__":
    main()
