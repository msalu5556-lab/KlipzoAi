import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {
  buildVideoFilterGraph,
  detectAudioActivityPeaks,
  extractCategoryProbeVideo,
  extractProxySegment,
  generateSampleVideo,
  probeVideo,
  renderClipMp4,
} from './ffmpegTools.ts';

test('buildVideoFilterGraph configures Gameplay-Top + Facecam-Bottom (1080x1920) and zero-cut Full Frame', () => {
  const splitFilter = buildVideoFilterGraph({
    aspectRatio: '9:16',
    layoutMode: 'split_cam_gameplay',
    webcamPosition: 'top_right',
  });
  // Facecam is a corner crop (top_right) scaled to the 768px bottom panel;
  // gameplay is cover-cropped to the 1152px top panel, stacked game-over-face.
  assert.ok(splitFilter.includes('crop=iw*0.25:ih*0.30:iw*0.75:0'));
  assert.ok(splitFilter.includes('scale=1080:768'));
  assert.ok(splitFilter.includes('scale=1080:1152'));
  assert.ok(splitFilter.includes('vstack=inputs=2'));
  assert.ok(splitFilter.includes('[topgame][botcam]'));

  // Exact face-crop fractions (from YuNet detection) override the corner guess.
  const exactFilter = buildVideoFilterGraph({
    aspectRatio: '9:16',
    layoutMode: 'split_cam_gameplay',
    webcamPosition: 'bottom_left',
    faceCrop: { x: 0.1, y: 0.2, w: 0.3, h: 0.4 },
  });
  assert.ok(exactFilter.includes('crop=iw*0.300:ih*0.400:iw*0.100:ih*0.200'));

  // Title banner: drawtext with a text file, black bold on a white box.
  const titledFilter = buildVideoFilterGraph({
    aspectRatio: '9:16',
    layoutMode: 'full_frame',
    titleFilePath: '/tmp/klipz-test-title.txt',
  });
  assert.ok(titledFilter.includes('drawtext='));
  assert.ok(titledFilter.includes('textfile='));
  assert.ok(titledFilter.includes('fontsize=64'));
  assert.ok(titledFilter.includes('boxcolor=white'));

  const dualSpeakerFilter = buildVideoFilterGraph({
    aspectRatio: '9:16',
    layoutMode: 'dual_speaker',
  });
  assert.ok(dualSpeakerFilter.includes('crop=iw*0.5:ih:0:0'));
  assert.ok(dualSpeakerFilter.includes('crop=iw*0.5:ih:iw*0.5:0'));
  assert.ok(dualSpeakerFilter.includes('vstack=inputs=2'));

  const fullFrameFilter = buildVideoFilterGraph({
    aspectRatio: '9:16',
    layoutMode: 'full_frame',
  });
  assert.ok(fullFrameFilter.includes('force_original_aspect_ratio=decrease'));
  assert.ok(fullFrameFilter.includes('boxblur=20:5'));
});

test('generateSampleVideo + renderClipMp4 + proxy extraction work cleanly across all layouts', async () => {
  const gamingSample = await generateSampleVideo('gaming');
  const podcastSample = await generateSampleVideo('podcast');
  const eduSample = await generateSampleVideo('educational');

  const [gamingProbe, podcastProbe, eduProbe] = await Promise.all([
    probeVideo(gamingSample),
    probeVideo(podcastSample),
    probeVideo(eduSample),
  ]);

  assert.ok(gamingProbe.duration >= 35, 'Gaming sample should be ~36s');
  assert.ok(podcastProbe.duration >= 35, 'Podcast sample should be ~36s');
  assert.ok(eduProbe.duration >= 35, 'Educational sample should be ~36s');

  const tmpOutDir = path.join(os.tmpdir(), 'klipz-test-renders');
  await fs.mkdir(tmpOutDir, { recursive: true });

  // 1. Gaming 9:16 Gameplay Top + Facecam Bottom with top_right webcam
  const gamingClipOut = path.join(tmpOutDir, 'gaming_split_cam.mp4');
  await renderClipMp4({
    sourcePath: gamingSample,
    outputPath: gamingClipOut,
    clipId: 'test_gaming_split',
    startTime: 10,
    endTime: 22,
    aspectRatio: '9:16',
    layoutMode: 'split_cam_gameplay',
    webcamPosition: 'top_right',
    captionStyle: 'bold_kinetic',
    captions: [{ start: 0.5, end: 3.5, text: '4-star pursuit near miss!' }],
    hasAudio: true,
  });
  const gamingClipProbe = await probeVideo(gamingClipOut);
  assert.equal(gamingClipProbe.width, 1080);
  assert.equal(gamingClipProbe.height, 1920);
  assert.ok(gamingClipProbe.duration >= 11 && gamingClipProbe.duration <= 13);

  // 2. Podcast 9:16 dual_speaker split (left speaker top, right speaker bottom, zero cut)
  const podcastClipOut = path.join(tmpOutDir, 'podcast_dual.mp4');
  await renderClipMp4({
    sourcePath: podcastSample,
    outputPath: podcastClipOut,
    clipId: 'test_podcast_dual',
    startTime: 4,
    endTime: 16,
    aspectRatio: '9:16',
    layoutMode: 'dual_speaker',
    captionStyle: 'clean_editorial',
    captions: [{ start: 0.2, end: 4.0, text: 'Short-form hooks fail without full context.' }],
    hasAudio: true,
  });
  const podcastClipProbe = await probeVideo(podcastClipOut);
  assert.equal(podcastClipProbe.width, 1080);
  assert.equal(podcastClipProbe.height, 1920);
  assert.ok(podcastClipProbe.duration >= 11 && podcastClipProbe.duration <= 13);

  // 3. Educational 9:16 Exact Full Frame (uncropped 16:9 inside 9:16 studio canvas)
  const eduClipOut = path.join(tmpOutDir, 'edu_full_frame.mp4');
  await renderClipMp4({
    sourcePath: eduSample,
    outputPath: eduClipOut,
    clipId: 'test_edu_full',
    startTime: 12,
    endTime: 24,
    aspectRatio: '9:16',
    layoutMode: 'full_frame',
    captionStyle: 'high_contrast_box',
    captions: [{ start: 0.5, end: 4.5, text: 'Demonstrate with concrete visual contrast.' }],
    hasAudio: true,
  });
  const eduClipProbe = await probeVideo(eduClipOut);
  assert.equal(eduClipProbe.width, 1080);
  assert.equal(eduClipProbe.height, 1920);
  assert.ok(eduClipProbe.duration >= 11 && eduClipProbe.duration <= 13);

  // 3b. Title banner + word-by-word karaoke captions on the split layout
  const karaokeClipOut = path.join(tmpOutDir, 'gaming_karaoke_title.mp4');
  await renderClipMp4({
    sourcePath: gamingSample,
    outputPath: karaokeClipOut,
    clipId: 'test_gaming_karaoke',
    startTime: 2,
    endTime: 12,
    aspectRatio: '9:16',
    layoutMode: 'split_cam_gameplay',
    webcamPosition: 'top_right',
    captionStyle: 'bold_kinetic',
    captions: [],
    title: 'Four Star Pursuit Near Miss',
    wordCues: [
      { start: 0.5, end: 0.8, text: 'four' },
      { start: 0.8, end: 1.1, text: 'star' },
      { start: 1.1, end: 1.5, text: 'pursuit' },
      { start: 1.5, end: 1.9, text: 'near' },
      { start: 1.9, end: 2.3, text: 'miss' },
    ],
    hasAudio: true,
  });
  const karaokeClipProbe = await probeVideo(karaokeClipOut);
  assert.equal(karaokeClipProbe.width, 1080);
  assert.equal(karaokeClipProbe.height, 1920);
  assert.ok(karaokeClipProbe.duration >= 9 && karaokeClipProbe.duration <= 11);

  // 4. Compact proxy extraction & category probe creation
  const proxyOut = path.join(tmpOutDir, 'proxy_window.mp4');
  await extractProxySegment({
    sourcePath: gamingSample,
    outputPath: proxyOut,
    startTime: 5,
    duration: 15,
    hasAudio: true,
  });
  const proxyProbe = await probeVideo(proxyOut);
  assert.equal(proxyProbe.width, 480);
  assert.ok(proxyProbe.sizeBytes > 0 && proxyProbe.sizeBytes < 2 * 1024 * 1024);

  const probeVidOut = path.join(tmpOutDir, 'cat_probe.mp4');
  await extractCategoryProbeVideo({
    sourcePath: gamingSample,
    outputPath: probeVidOut,
    totalDuration: gamingProbe.duration,
    hasAudio: true,
  });
  const catProbeStat = await fs.stat(probeVidOut);
  assert.ok(catProbeStat.size > 0);

  const peaks = await detectAudioActivityPeaks({
    sourcePath: gamingSample,
    totalDuration: 150,
    hasAudio: true,
    maxPeaks: 3,
  });
  assert.ok(Array.isArray(peaks));

  await fs.rm(tmpOutDir, { recursive: true, force: true });
});
