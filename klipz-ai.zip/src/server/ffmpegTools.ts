import { execFile } from 'node:child_process';
import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import {
  generateAssSubtitles,
  generateKaraokeAss,
  type AspectRatio,
  type CaptionCue,
  type CaptionStyleId,
  type ClipLayoutMode,
  type DetectedWebcamPosition,
  type WordCue,
} from '../lib/clipEngine.ts';

const execFileAsync = promisify(execFile);

// Work root: KLIPZ_WORK_ROOT overrides the default (os.tmpdir()/klipz-studio).
// Set it on machines where /tmp is a small tmpfs (containers, small VMs) —
// a single large upload can otherwise fill /tmp and fail every job.
export const WORK_ROOT = process.env.KLIPZ_WORK_ROOT
  ? path.resolve(process.env.KLIPZ_WORK_ROOT)
  : path.join(os.tmpdir(), 'klipz-studio');
export const UPLOADS_DIR = path.join(WORK_ROOT, 'uploads');
export const CLIPS_DIR = path.join(WORK_ROOT, 'clips');
export const SUBS_DIR = path.join(WORK_ROOT, 'subs');
export const SAMPLES_DIR = path.join(WORK_ROOT, 'samples');
export const PROXIES_DIR = path.join(WORK_ROOT, 'proxies');

export async function ensureMediaDirs(): Promise<void> {
  await Promise.all([
    fs.mkdir(UPLOADS_DIR, { recursive: true }),
    fs.mkdir(CLIPS_DIR, { recursive: true }),
    fs.mkdir(SUBS_DIR, { recursive: true }),
    fs.mkdir(SAMPLES_DIR, { recursive: true }),
    fs.mkdir(PROXIES_DIR, { recursive: true }),
  ]);
}

export interface VideoProbeInfo {
  duration: number;
  width: number;
  height: number;
  fps: number;
  hasAudio: boolean;
  codec: string;
  sizeBytes: number;
}

export async function probeVideo(filePath: string): Promise<VideoProbeInfo> {
  const isRemote = /^https?:\/\//i.test(filePath);
  const [probeResult, stat] = await Promise.all([
    execFileAsync('ffprobe', [
      '-v',
      'quiet',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      filePath,
    ]),
    isRemote ? Promise.resolve({ size: 0 }) : fs.stat(filePath),
  ]);

  const parsed = JSON.parse(probeResult.stdout || '{}') as {
    format?: { duration?: string };
    streams?: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
      r_frame_rate?: string;
    }>;
  };

  const streams = parsed.streams ?? [];
  const videoStream = streams.find((s) => s.codec_type === 'video');
  const audioStream = streams.find((s) => s.codec_type === 'audio');

  let fps = 30;
  if (videoStream?.r_frame_rate && videoStream.r_frame_rate.includes('/')) {
    const [num, den] = videoStream.r_frame_rate.split('/').map(Number);
    if (den > 0 && Number.isFinite(num / den)) {
      fps = Math.round((num / den) * 100) / 100;
    }
  }

  const duration = Number(parsed.format?.duration ?? 0);

  return {
    duration: Number.isFinite(duration) && duration > 0 ? duration : 0,
    width: videoStream?.width ?? 1280,
    height: videoStream?.height ?? 720,
    fps,
    hasAudio: Boolean(audioStream),
    codec: videoStream?.codec_name ?? 'h264',
    sizeBytes: stat.size,
  };
}

function getRenderDimensions(aspectRatio: AspectRatio): { width: number; height: number } {
  switch (aspectRatio) {
    case '9:16':
      return { width: 1080, height: 1920 };
    case '16:9':
      return { width: 1920, height: 1080 };
    case '1:1':
      return { width: 1080, height: 1080 };
    case '4:5':
      return { width: 1080, height: 1350 };
  }
}

/** Word-wrap a clip title into short lines for the overlay box (max 26 chars/line). */
export function wrapTitle(text: string, maxChars = 26): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const trial = cur ? `${cur} ${w}` : w;
    if (trial.length > maxChars && cur) {
      lines.push(cur);
      cur = w;
    } else {
      cur = trial;
    }
  }
  if (cur) lines.push(cur);
  return lines;
}

/** Bold font for the drawtext title banner. KLIPZ_FONT overrides the search. */
export function findTitleFont(): string | null {
  const candidates = [
    process.env.KLIPZ_FONT,
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
    'C:\\Windows\\Fonts\\arialbd.ttf',
  ].filter(Boolean) as string[];
  for (const p of candidates) {
    if (existsSync(p)) return p;
  }
  return null;
}

function escapeFilterPath(filePath: string): string {
  return filePath
    .replace(/\\/g, '\\\\')
    .replace(/:/g, '\\:')
    .replace(/'/g, "\\'");
}

function getWebcamCropExpression(position: DetectedWebcamPosition): string {
  switch (position) {
    case 'top_left':
      return 'crop=iw*0.25:ih*0.30:0:0';
    case 'top_right':
      return 'crop=iw*0.25:ih*0.30:iw*0.75:0';
    case 'bottom_left':
      return 'crop=iw*0.25:ih*0.30:0:ih*0.70';
    case 'bottom_right':
      return 'crop=iw*0.25:ih*0.30:iw*0.75:ih*0.70';
    case 'top_center':
      return 'crop=iw*0.28:ih*0.30:iw*0.36:0';
    case 'none':
    default:
      return 'crop=iw*0.42:ih*0.42:iw*0.29:ih*0.08';
  }
}

export function buildVideoFilterGraph(params: {
  aspectRatio: AspectRatio;
  layoutMode: ClipLayoutMode;
  webcamPosition?: DetectedWebcamPosition;
  assPath?: string | null;
  /** Exact face crop fractions {x, y, w, h} (0..1), from face detection. */
  faceCrop?: { x: number; y: number; w: number; h: number } | null;
  /** Path to a text file holding the wrapped title (one line per row). */
  titleFilePath?: string | null;
  titlePosition?: 'top' | 'center';
}): string {
  const { aspectRatio, layoutMode, webcamPosition = 'none', assPath, faceCrop, titleFilePath, titlePosition = 'top' } = params;
  const { width, height } = getRenderDimensions(aspectRatio);
  const subSuffix = assPath ? `,ass='${escapeFilterPath(assPath)}'` : '';
  // Title banner: black bold text on a white box, over the gameplay panel
  // (the proven pipeline's look). The title lives in a file (textfile=) so
  // multi-line wrapping works. Skipped when no font is available.
  let titleSuffix = '';
  if (titleFilePath) {
    const fontfile = findTitleFont();
    const fontOpt = fontfile ? `fontfile=${escapeFilterPath(fontfile)}` : `font='DejaVu Sans Bold'`;
    const fpath = escapeFilterPath(titleFilePath);
    const y = titlePosition === 'top' ? '120' : `(${Math.floor(height * 0.6)}-text_h)/2`;
    titleSuffix = `,drawtext=${fontOpt}:textfile=${fpath}:expansion=none:fontsize=64:fontcolor=black:box=1:boxcolor=white:boxborderw=22:x=(w-text_w)/2:y=${y}`;
  }

  // 1. Gameplay TOP (60% = 1152px) + Facecam BOTTOM (40% = 768px) — the
  // proven layout. The face crop is the exact detected face when available,
  // otherwise a corner guess from the webcam position.
  if (layoutMode === 'split_cam_gameplay' && aspectRatio === '9:16' && webcamPosition !== 'none') {
    const gameH = 1152;
    const camH = height - gameH;
    const camCrop = faceCrop
      ? `crop=iw*${faceCrop.w.toFixed(3)}:ih*${faceCrop.h.toFixed(3)}:iw*${faceCrop.x.toFixed(3)}:ih*${faceCrop.y.toFixed(3)}`
      : getWebcamCropExpression(webcamPosition);

    return (
      `[0:v]split=2[camraw][gameraw];` +
      `[camraw]${camCrop},scale=${width}:${camH}:force_original_aspect_ratio=increase,crop=${width}:${camH}[botcam];` +
      `[gameraw]scale=${width}:${gameH}:force_original_aspect_ratio=increase,crop=${width}:${gameH}[topgame];` +
      `[topgame][botcam]vstack=inputs=2${subSuffix}${titleSuffix}[vout]`
    );
  }

  // 2. Dual Speaker Split (Left speaker TOP + Right speaker BOTTOM, uncropped within each half)
  if (layoutMode === 'dual_speaker' && aspectRatio === '9:16') {
    const halfH = Math.floor(height / 2);
    return (
      `[0:v]split=2[lraw][rraw];` +
      `[lraw]crop=iw*0.5:ih:0:0,split=2[lbg][lfg];` +
      `[lbg]scale=${width}:${halfH}:force_original_aspect_ratio=increase,crop=${width}:${halfH},boxblur=16:4,colorchannelmixer=rr=0.35:gg=0.35:bb=0.38[lblur];` +
      `[lfg]scale=${width}:${halfH}:force_original_aspect_ratio=decrease[lfit];` +
      `[lblur][lfit]overlay=(W-w)/2:(H-h)/2[topspk];` +
      `[rraw]crop=iw*0.5:ih:iw*0.5:0,split=2[rbg][rfg];` +
      `[rbg]scale=${width}:${halfH}:force_original_aspect_ratio=increase,crop=${width}:${halfH},boxblur=16:4,colorchannelmixer=rr=0.35:gg=0.35:bb=0.38[rblur];` +
      `[rfg]scale=${width}:${halfH}:force_original_aspect_ratio=decrease[rfit];` +
      `[rblur][rfit]overlay=(W-w)/2:(H-h)/2[botspk];` +
      `[topspk][botspk]vstack=inputs=2${subSuffix}${titleSuffix}[vout]`
    );
  }

  // 3. Exact Full Frame (Zero border cutting — preserves 100% of original video frame)
  if (
    layoutMode === 'full_frame' ||
    layoutMode === 'picture_in_picture' ||
    (layoutMode === 'split_cam_gameplay' && webcamPosition === 'none')
  ) {
    if (aspectRatio === '16:9') {
      return (
        `[0:v]scale=${width}:${height}:force_original_aspect_ratio=decrease,` +
        `pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:#05070B${subSuffix}${titleSuffix}[vout]`
      );
    }

    return (
      `[0:v]split=2[bg][fg];` +
      `[bg]scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},boxblur=20:5,colorchannelmixer=rr=0.38:gg=0.38:bb=0.40[blurred];` +
      `[fg]scale=${width}:${height}:force_original_aspect_ratio=decrease[scaled];` +
      `[blurred][scaled]overlay=(W-w)/2:(H-h)/2${subSuffix}${titleSuffix}[vout]`
    );
  }

  // 4. Smart Center / Speaker Focus Crop (only when explicitly selected)
  return (
    `[0:v]scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height}${subSuffix}${titleSuffix}[vout]`
  );
}

export interface RenderClipParams {
  sourcePath: string;
  outputPath: string;
  clipId: string;
  startTime: number;
  endTime: number;
  aspectRatio: AspectRatio;
  layoutMode: ClipLayoutMode;
  webcamPosition?: DetectedWebcamPosition;
  captionStyle: CaptionStyleId;
  captions: CaptionCue[];
  hasAudio: boolean;
  /** Clip title — burned as a banner (black bold text on a white box). */
  title?: string;
  titlePosition?: 'top' | 'center';
  /** Word-level timings — when present, captions render as word-by-word
   * karaoke instead of sentence captions. */
  wordCues?: WordCue[];
  /** Exact face crop fractions {x, y, w, h} (0..1) from face detection. */
  faceCrop?: { x: number; y: number; w: number; h: number } | null;
}

export async function renderClipMp4(params: RenderClipParams): Promise<void> {
  await ensureMediaDirs();
  const {
    sourcePath,
    outputPath,
    clipId,
    startTime,
    endTime,
    aspectRatio,
    layoutMode,
    webcamPosition = 'none',
    captionStyle,
    captions,
    hasAudio,
    title,
    titlePosition = 'top',
    wordCues,
    faceCrop,
  } = params;

  const duration = Math.max(0.5, endTime - startTime);
  const { width, height } = getRenderDimensions(aspectRatio);
  const isRemote = /^https?:\/\//i.test(sourcePath);

  let assPath: string | null = null;
  if (captionStyle !== 'none' && (wordCues?.length || captions.length > 0)) {
    const isSplit = layoutMode === 'split_cam_gameplay' && aspectRatio === '9:16' && webcamPosition !== 'none';
    const seamY = isSplit ? 1152 : Math.round(height * 0.72);
    const assContent = wordCues?.length
      ? generateKaraokeAss(wordCues, width, height, seamY)
      : generateAssSubtitles(captions, captionStyle, width, height);
    if (assContent) {
      assPath = path.join(SUBS_DIR, `${clipId}_${Date.now()}.ass`);
      await fs.writeFile(assPath, assContent, 'utf8');
    }
  }

  let titleFilePath: string | null = null;
  if (title?.trim()) {
    titleFilePath = path.join(SUBS_DIR, `${clipId}_${Date.now()}_title.txt`);
    await fs.writeFile(titleFilePath, wrapTitle(title.trim()).join('\n') + '\n', 'utf8');
  }

  const filterComplex = buildVideoFilterGraph({
    aspectRatio,
    layoutMode,
    webcamPosition,
    assPath,
    faceCrop,
    titleFilePath,
    titlePosition,
  });

  const args: string[] = ['-y'];
  if (isRemote) {
    args.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5');
  }
  args.push(
    '-ss',
    startTime.toFixed(3),
    '-i',
    sourcePath,
    '-t',
    duration.toFixed(3),
    '-filter_complex',
    filterComplex,
    '-map',
    '[vout]'
  );

  if (hasAudio) {
    args.push('-map', '0:a:0?', '-c:a', 'aac', '-b:a', '128k', '-ac', '2');
  } else {
    args.push('-an');
  }

  args.push(
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '22',
    '-pix_fmt',
    'yuv420p',
    '-movflags',
    '+faststart',
    outputPath
  );

  try {
    await execFileAsync('ffmpeg', args, { maxBuffer: 25 * 1024 * 1024, timeout: 180_000 });
  } finally {
    if (assPath) {
      await fs.unlink(assPath).catch(() => undefined);
    }
    if (titleFilePath) {
      await fs.unlink(titleFilePath).catch(() => undefined);
    }
  }
}

export async function extractProxySegment(params: {
  sourcePath: string;
  outputPath: string;
  startTime: number;
  duration: number;
  hasAudio?: boolean;
  maxWidth?: number;
  fps?: number;
}): Promise<string> {
  await ensureMediaDirs();
  const {
    sourcePath,
    outputPath,
    startTime,
    duration,
    hasAudio = true,
    maxWidth = 480,
    fps = 2,
  } = params;

  const isRemote = /^https?:\/\//i.test(sourcePath);
  const args: string[] = ['-y'];
  if (isRemote) {
    args.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5');
  }

  args.push(
    '-ss',
    Math.max(0, startTime).toFixed(2),
    '-i',
    sourcePath,
    '-t',
    Math.max(3, duration).toFixed(2),
    '-vf',
    `scale='min(${maxWidth},iw)':-2,fps=${fps}`,
    '-c:v',
    'libx264',
    '-preset',
    'ultrafast',
    '-crf',
    '32',
    '-pix_fmt',
    'yuv420p'
  );

  if (hasAudio) {
    args.push('-c:a', 'aac', '-b:a', '48k', '-ac', '1', '-ar', '22050');
  } else {
    args.push('-an');
  }

  args.push('-movflags', '+faststart', outputPath);

  await execFileAsync('ffmpeg', args, { maxBuffer: 15 * 1024 * 1024, timeout: 120_000 });
  return outputPath;
}

export async function extractCategoryProbeVideo(params: {
  sourcePath: string;
  outputPath: string;
  totalDuration: number;
  hasAudio?: boolean;
}): Promise<string> {
  await ensureMediaDirs();
  const { sourcePath, outputPath, totalDuration, hasAudio = true } = params;

  if (totalDuration <= 45) {
    return extractProxySegment({
      sourcePath,
      outputPath,
      startTime: 0,
      duration: Math.max(4, totalDuration),
      hasAudio,
      maxWidth: 480,
      fps: 2,
    });
  }

  const clipLen = 9;
  const offsets = [
    Math.max(0, Math.min(totalDuration - clipLen, totalDuration * 0.08)),
    Math.max(0, Math.min(totalDuration - clipLen, totalDuration * 0.48)),
    Math.max(0, Math.min(totalDuration - clipLen, totalDuration * 0.82)),
  ];

  const tempParts: string[] = [];
  const concatListPath = `${outputPath}.concat.txt`;

  try {
    for (let i = 0; i < offsets.length; i++) {
      const partPath = `${outputPath}.part${i}.mp4`;
      await extractProxySegment({
        sourcePath,
        outputPath: partPath,
        startTime: offsets[i],
        duration: clipLen,
        hasAudio,
        maxWidth: 480,
        fps: 2,
      });
      tempParts.push(partPath);
    }

    const listBody = tempParts.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n');
    await fs.writeFile(concatListPath, listBody, 'utf8');

    await execFileAsync(
      'ffmpeg',
      ['-y', '-f', 'concat', '-safe', '0', '-i', concatListPath, '-c', 'copy', outputPath],
      { maxBuffer: 10 * 1024 * 1024, timeout: 60_000 }
    );
    return outputPath;
  } finally {
    await Promise.all([
      fs.unlink(concatListPath).catch(() => undefined),
      ...tempParts.map((p) => fs.unlink(p).catch(() => undefined)),
    ]);
  }
}

export async function detectAudioActivityPeaks(params: {
  sourcePath: string;
  totalDuration: number;
  hasAudio: boolean;
  maxPeaks?: number;
}): Promise<number[]> {
  const { sourcePath, totalDuration, hasAudio, maxPeaks = 6 } = params;
  if (!hasAudio || totalDuration < 120 || /^https?:\/\//i.test(sourcePath)) {
    return [];
  }

  const sampleCount = totalDuration > 3600 ? 12 : 8;
  const sampleDur = 12;
  const usable = Math.max(1, totalDuration - sampleDur);

  const offsets = Array.from({ length: sampleCount }, (_, i) => {
    const ratio = (i + 0.5) / sampleCount;
    return Number((ratio * usable).toFixed(1));
  });

  const scored = await Promise.all(
    offsets.map(async (offset) => {
      try {
        const { stderr } = await execFileAsync(
          'ffmpeg',
          [
            '-ss',
            offset.toFixed(1),
            '-t',
            String(sampleDur),
            '-i',
            sourcePath,
            '-vn',
            '-af',
            'volumedetect',
            '-f',
            'null',
            '-',
          ],
          { maxBuffer: 4 * 1024 * 1024, timeout: 15_000 }
        );
        const meanMatch = /mean_volume:\s*([-\d.]+)\s*dB/i.exec(stderr);
        const maxMatch = /max_volume:\s*([-\d.]+)\s*dB/i.exec(stderr);
        const meanDb = meanMatch ? Number(meanMatch[1]) : -60;
        const maxDb = maxMatch ? Number(maxMatch[1]) : -60;
        const energy =
          (Number.isFinite(meanDb) ? meanDb : -60) +
          (Number.isFinite(maxDb) ? maxDb * 0.4 : -24);
        return { offset: offset + sampleDur / 2, energy };
      } catch {
        return { offset, energy: -999 };
      }
    })
  );

  return scored
    .filter((s) => s.energy > -90)
    .sort((a, b) => b.energy - a.energy)
    .slice(0, maxPeaks)
    .map((s) => Math.round(s.offset));
}

export type SampleKind = 'gaming' | 'podcast' | 'educational';

export async function generateSampleVideo(kind: SampleKind): Promise<string> {
  await ensureMediaDirs();
  const outPath = path.join(SAMPLES_DIR, `sample_${kind}.mp4`);

  try {
    await fs.access(outPath);
    return outPath;
  } catch {
    // Generate if missing
  }

  let videoFilter = '';
  let audioSource = '';
  const duration = 36;

  if (kind === 'gaming') {
    videoFilter =
      `color=c=#0f172a:s=1280x720:d=${duration}:r=30,` +
      `drawbox=x=40:y=40:w=1200:h=640:color=#1e293b@0.9:t=fill,` +
      `drawbox=x='100+400*abs(sin(t*1.2))':y='260+90*cos(t*2.1)':w=180:h=90:color=#ef4444@0.95:t=fill,` +
      `drawbox=x='860-260*abs(sin(t*0.9))':y='360':w=140:h=70:color=#3b82f6@0.95:t=fill,` +
      `drawbox=x=960:y=0:w=320:h=216:color=#0b1220@0.96:t=fill,` +
      `drawbox=x=1070:y=40:w=100:h=100:color=#f59e0b@0.9:t=fill,` +
      `drawtext=font='DejaVu Sans':text='STREAMER CAM':fontcolor=#e2e8f0:fontsize=20:x=1025:y=168,` +
      `drawtext=font='DejaVu Sans':text='VICE DISTRICT PURSUIT — SAMPLE GAMEPLAY':fontcolor=white:fontsize=28:x=72:y=78,` +
      `drawtext=font='DejaVu Sans':text='SCENE 1\\: PATROL CRUISING':fontcolor=#94a3b8:fontsize=24:x=72:y=600:enable='between(t,0,10)',` +
      `drawtext=font='DejaVu Sans':text='SCENE 2\\: 4-STAR POLICE CHASE & NEAR-MISS':fontcolor=#fbbf24:fontsize=26:x=72:y=600:enable='between(t,10,23)',` +
      `drawtext=font='DejaVu Sans':text='SCENE 3\\: STUNT RAMP ESCAPE & PAYOFF':fontcolor=#34d399:fontsize=26:x=72:y=600:enable='between(t,23,36)'`;
    audioSource = `sine=frequency=220:sample_rate=44100:duration=${duration}`;
  } else if (kind === 'podcast') {
    videoFilter =
      `color=c=#111827:s=1280x720:d=${duration}:r=30,` +
      `drawbox=x=80:y=110:w=520:h=460:color=#1f2937:t=fill,` +
      `drawbox=x=680:y=110:w=520:h=460:color=#1f2937:t=fill,` +
      `drawtext=font='DejaVu Sans':text='HOST\\: ALEX':fontcolor=#e2e8f0:fontsize=30:x=120:y=150,` +
      `drawtext=font='DejaVu Sans':text='GUEST\\: MAYA':fontcolor=#e2e8f0:fontsize=30:x=720:y=150,` +
      `drawtext=font='DejaVu Sans':text='EPISODE 42 — CREATOR ECONOMY DEBATE':fontcolor=#94a3b8:fontsize=24:x=80:y=54,` +
      `drawtext=font='DejaVu Sans':text='\"Short-form hooks fail without full context.\"':fontcolor=#60a5fa:fontsize=26:x=80:y=615:enable='between(t,3,17)',` +
      `drawtext=font='DejaVu Sans':text='\"Disagree — retention begins in the first 3 seconds!\"':fontcolor=#f59e0b:fontsize=26:x=80:y=615:enable='between(t,18,34)'`;
    audioSource = `sine=frequency=180:sample_rate=44100:duration=${duration}`;
  } else {
    videoFilter =
      `color=c=#0b1320:s=1280x720:d=${duration}:r=30,` +
      `drawbox=x=90:y=120:w=1100:h=480:color=#162032:t=fill,` +
      `drawtext=font='DejaVu Sans':text='EXPLAINER — HOW ATTENTION CURVES WORK':fontcolor=white:fontsize=32:x=120:y=160,` +
      `drawtext=font='DejaVu Sans':text='1. Establish one clear question immediately':fontcolor=#cbd5e1:fontsize=26:x=120:y=280:enable='between(t,1,12)',` +
      `drawtext=font='DejaVu Sans':text='2. Demonstrate with a concrete visual contrast':fontcolor=#60a5fa:fontsize=26:x=120:y=350:enable='between(t,12,24)',` +
      `drawtext=font='DejaVu Sans':text='3. Deliver a standalone takeaway before cutting':fontcolor=#34d399:fontsize=26:x=120:y=420:enable='between(t,24,36)'`;
    audioSource = `sine=frequency=260:sample_rate=44100:duration=${duration}`;
  }

  await execFileAsync('ffmpeg', [
    '-y',
    '-f',
    'lavfi',
    '-i',
    videoFilter,
    '-f',
    'lavfi',
    '-i',
    audioSource,
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '24',
    '-pix_fmt',
    'yuv420p',
    '-c:a',
    'aac',
    '-b:a',
    '96k',
    '-shortest',
    '-movflags',
    '+faststart',
    outPath,
  ]);

  return outPath;
}
