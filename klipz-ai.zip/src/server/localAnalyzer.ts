/**
 * Klipz Ai — Local clipping engine.
 *
 * Drives the proven Python pipeline (`src/server/python/clip_stream.py`) as a
 * subprocess. That pipeline is the one that produced the verified 10x IShowSpeed
 * GTA 6 Shorts on 2026-11-21: yt-dlp download (web client + android fallback,
 * `--download-sections` so a 23h VOD is never downloaded in full), faster-whisper
 * word-level transcription, loudness-spike + transcript-marker detection, a
 * /100 verification rubric with a two-signal evidence rule and hard rejection of
 * weak moments, and an ffmpeg render (1080x1920, gameplay top / facecam bottom,
 * title banner, word-by-word karaoke captions).
 *
 * This engine needs NO API keys. Gemini stays available as an opt-in enhancement
 * only (KLIPZ_USE_GEMINI=1 + GEMINI_API_KEY); a missing key never blocks clipping.
 *
 * Python resolution order:
 *   1. KLIPZ_PYTHON env var
 *   2. <project root>/.venv/bin/python  (or .venv/Scripts/python.exe on Windows)
 *   3. python3, then python on PATH
 * The interpreter must be able to `import faster_whisper, yt_dlp, numpy, cv2`.
 * See src/server/python/requirements-python.txt for the exact dependencies.
 */

import { spawn, execFile } from 'node:child_process';
import { copyFile, mkdir, readdir, readFile, stat, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, join, resolve, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { AnalyzeVideoResult } from './geminiAnalyzer.js';
import type {
  AspectRatio,
  CaptionCue,
  CaptionStyleId,
  ClipDurationPreset,
  ClipLayoutMode,
  ConcreteCategoryId,
  DetectedWebcamPosition,
  LayoutPreference,
  NormalizedClip,
  VideoCategoryId,
  WebcamPosition,
  WordCue,
} from '../lib/clipEngine.js';
import { WORK_ROOT, CLIPS_DIR, ensureMediaDirs } from './ffmpegTools.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const PYTHON_DIR = join(__dirname, 'python');
const CLIP_STREAM = join(PYTHON_DIR, 'clip_stream.py');
const PROJECT_ROOT = resolve(__dirname, '..', '..', '..');

export const LOCAL_ENGINE_TIMEOUT_MS = 25 * 60 * 1000; // matches the UI's 25-min job cap

export class LocalEngineError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'LocalEngineError';
    this.code = code;
  }
}

export interface LocalEngineStatus {
  available: boolean;
  python?: string;
  detail: string;
}

export interface LocalAnalyzeRequest {
  videoPath: string; // local file path OR YouTube URL
  isYouTube: boolean;
  videoDuration: number;
  hasAudio?: boolean;
  selectedCategory: VideoCategoryId;
  numberOfClips: number;
  durationPreset: ClipDurationPreset;
  aspectRatio: AspectRatio;
  captionLanguage: string;
  captionStyle: CaptionStyleId;
  layoutPreference?: LayoutPreference;
  webcamPreference?: WebcamPosition;
  jobTag: string; // unique id — becomes the job work dir
  onProgress?: (stage: string, progress: number) => void;
}

/**
 * One moment as written by the pipeline's verify step (verified.json).
 * Field names match the real file: `score` is the /100 total, and the six
 * sub-scores are FLAT fields (reaction /30, cause /20, story /15, chat /15,
 * quotable /10, technical /10). `mean_db`/`max_db` are the window loudness.
 */
interface VerifiedMoment {
  t: number;
  emotion?: string;
  title?: string;
  quote?: string;
  score?: number;
  reaction?: number;
  cause?: number;
  story?: number;
  chat?: number;
  quotable?: number;
  technical?: number;
  signals?: number;
  face?: boolean;
  words?: number;
  mean_db?: number;
  max_db?: number;
  events?: string[];
  verdict?: string;
}

interface StateFile {
  source?: string;
  duration?: number;
  face?: [number, number, number, number] | null;
  face_source?: string;
  rendered?: Array<{ t: number; file: string; title: string }>;
  moments?: Array<{ t: number; score: number }>;
}

/** Preset → (pre, post) seconds around the detected moment. */
export function presetToWindow(preset: ClipDurationPreset): { pre: number; post: number } {
  if (preset === 'short') return { pre: 10, post: 15 };
  if (preset === 'deep') return { pre: 30, post: 45 };
  return { pre: 15, post: 20 }; // balanced → 35s clips, as delivered
}

/** UI caption-language label → faster-whisper language code. `null` = auto. */
export function mapCaptionLanguage(label: string): string | null {
  const map: Record<string, string> = {
    English: 'en',
    Urdu: 'ur',
    Hindi: 'hi',
    Spanish: 'es',
    French: 'fr',
    German: 'de',
    Arabic: 'ar',
    Portuguese: 'pt',
    Japanese: 'ja',
  };
  return map[label] ?? null;
}

/** Corner preference → clip_stream.py --face crop fractions (x,y,w,h). */
export function webcamCornerToCrop(corner: WebcamPosition): string {
  const map: Record<WebcamPosition, string> = {
    top_left: '0,0,0.25,0.35',
    top_right: '0.75,0,0.25,0.35',
    bottom_left: '0,0.65,0.25,0.35',
    bottom_right: '0.75,0.65,0.25,0.35',
    top_center: '0.36,0,0.28,0.35',
    auto: 'auto',
    none: 'none',
  };
  return map[corner] ?? 'auto';
}

/** Detected face crop fractions → nearest UI corner label. */
export function mapFaceCropToCorner(crop: [number, number, number, number] | null | undefined): DetectedWebcamPosition {
  if (!crop) return 'none';
  const [x, y] = crop;
  const cx = x + crop[2] / 2;
  const cy = y + crop[3] / 2;
  if (cy < 0.5) return cx < 0.5 ? 'top_left' : 'top_right';
  return cx < 0.5 ? 'bottom_left' : 'bottom_right';
}

let cachedPython: { python: string; detail: string } | null = null;
let cachedPythonError: string | null = null;

async function execFileAsync(
  cmd: string,
  args: string[],
  opts: { timeout?: number; maxBuffer?: number } = {},
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolvePromise, rejectPromise) => {
    execFile(cmd, args, { timeout: opts.timeout ?? 30_000, maxBuffer: opts.maxBuffer ?? 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) rejectPromise(err);
      else resolvePromise({ stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
    });
  });
}

/**
 * Resolve the Python interpreter for the local engine, verifying that the
 * required dependencies import. Result is cached for the process lifetime.
 * Throws LocalEngineError with setup instructions when unavailable.
 */
const WHISPER_MODELS = ['tiny', 'base', 'small'] as const;

/**
 * Whisper model for the local engine. Default `base` (~400 MB RAM to load).
 * On a small container (Railway's 512 MB default) `base` gets OOM-killed
 * before it prints anything ("exit null", "no output"). Set
 * KLIPZ_WHISPER_MODEL=tiny (~260 MB to load) to fit a 512 MB–1 GB box;
 * captions are slightly less accurate than base. Invalid values fall back
 * to `base`.
 */
export function resolveWhisperModel(): string {
  const m = (process.env.KLIPZ_WHISPER_MODEL ?? 'base').trim().toLowerCase();
  return (WHISPER_MODELS as readonly string[]).includes(m) ? m : 'base';
}

export async function resolvePython(): Promise<{ python: string; detail: string }> {
  if (cachedPython) return cachedPython;
  if (cachedPythonError) throw new LocalEngineError('PYTHON_UNAVAILABLE', cachedPythonError);

  const candidates: string[] = [];
  if (process.env.KLIPZ_PYTHON) candidates.push(process.env.KLIPZ_PYTHON);
  const venvPy = process.platform === 'win32'
    ? join(PROJECT_ROOT, '.venv', 'Scripts', 'python.exe')
    : join(PROJECT_ROOT, '.venv', 'bin', 'python');
  if (existsSync(venvPy)) candidates.push(venvPy);
  candidates.push('python3', 'python');

  const setupHint =
    'Local clipping engine needs Python 3.10+ with faster-whisper, yt-dlp, numpy, opencv-python-headless and av==14.2.0. ' +
    'From the project root run: python3 -m venv .venv && .venv/bin/pip install -r src/server/python/requirements-python.txt ' +
    '(on Windows use .venv\\Scripts\\pip). Or set KLIPZ_PYTHON to a Python with those packages installed.';

  for (const candidate of candidates) {
    try {
      const { stdout } = await execFileAsync(candidate, [
        '-c',
        'import sys, faster_whisper, yt_dlp, numpy, cv2; print(sys.version.split()[0])',
      ], { timeout: 30_000 });
      const version = stdout.trim();
      cachedPython = { python: candidate, detail: `Python ${version} (faster-whisper, yt-dlp, numpy, opencv)` };
      return cachedPython;
    } catch {
      // try the next candidate
    }
  }
  cachedPythonError = setupHint;
  throw new LocalEngineError('PYTHON_UNAVAILABLE', setupHint);
}

/** Health-check view of the local engine — never throws. */
export async function getLocalEngineStatus(): Promise<LocalEngineStatus> {
  try {
    const { python, detail } = await resolvePython();
    return { available: true, python, detail };
  } catch (err) {
    return { available: false, detail: err instanceof Error ? err.message : String(err) };
  }
}

/**
 * YouTube metadata via yt-dlp (no download). Falls back to null on any failure
 * so the caller can try the youtubei.js ingestor.
 */
export async function downloadYouTubeMetadata(url: string): Promise<{
  youtubeId: string;
  title: string;
  channelTitle: string;
  description: string;
  durationSeconds: number;
  thumbnailUrl: string;
  viewCount?: number;
} | null> {
  const { python } = await resolvePython();
  const runOnce = (extraArgs: string[]) => execFileAsync(python, [
    '-m', 'yt_dlp',
    '--dump-single-json',
    '--skip-download',
    '--no-playlist',
    '--no-warnings',
    '--socket-timeout', '20',
    ...extraArgs,
    url,
  ], { timeout: 60_000, maxBuffer: 20 * 1024 * 1024 });
  try {
    // YouTube throttles the default (web) client hard on some networks;
    // retry once with the android player client (~300 KB/s).
    let stdout: string;
    try {
      ({ stdout } = await runOnce([]));
    } catch {
      ({ stdout } = await runOnce(['--extractor-args', 'youtube:player_client=android']));
    }
    const info = JSON.parse(stdout);
    return {
      youtubeId: String(info.id ?? ''),
      title: String(info.title ?? 'YouTube Video'),
      channelTitle: String(info.channel ?? info.uploader ?? 'Unknown Channel'),
      description: String(info.description ?? ''),
      durationSeconds: Number(info.duration ?? 0),
      thumbnailUrl: String(info.thumbnail ?? ''),
      viewCount: typeof info.view_count === 'number' ? info.view_count : undefined,
    };
  } catch {
    return null;
  }
}

/**
 * Download one short segment of a YouTube video with yt-dlp
 * (--download-sections). Used by the clip editor re-render path so a YouTube
 * clip can be re-rendered from a local file. Returns the local path and the
 * absolute start time the segment covers.
 */
export async function downloadSegment(
  url: string,
  start: number,
  end: number,
  workDir: string,
): Promise<{ path: string; segmentStart: number }> {
  const { python } = await resolvePython();
  await mkdir(workDir, { recursive: true });
  const segmentStart = Math.max(0, Math.floor(start) - 5);
  const segmentEnd = Math.ceil(end) + 5;
  const outTemplate = join(workDir, `seg-${Math.round(segmentStart)}-${Math.round(segmentEnd)}.mp4`);
  if (existsSync(outTemplate)) return { path: outTemplate, segmentStart };
  const section = `*${segmentStart}-${segmentEnd}`;
  const runOnce = (extraArgs: string[]) => execFileAsync(python, [
    '-m', 'yt_dlp',
    '--no-playlist',
    '--no-warnings',
    '--socket-timeout', '20',
    ...extraArgs,
    '--download-sections', section,
    '-f', 'bv[height<=720]+ba/b[height<=720]/18',
    '-o', outTemplate,
    url,
  ], { timeout: 10 * 60_000, maxBuffer: 10 * 1024 * 1024 });
  // Downloads prefer the android player client (~160 KB/s here vs ~5 KB/s
  // for the default web client); fall back to web if android fails.
  const androidArgs = ['--extractor-args', 'youtube:player_client=android'];
  try {
    await runOnce(androidArgs);
  } catch {
    await runOnce([]);
  }
  if (!existsSync(outTemplate)) {
    throw new LocalEngineError('SEGMENT_DOWNLOAD_FAILED', `Could not download the ${segmentStart}s–${segmentEnd}s segment of the YouTube video (yt-dlp). The video may be restricted or YouTube may be blocking downloads from this server.`);
  }
  return { path: outTemplate, segmentStart };
}

/**
 * Parse a v7 karaoke ASS file (cap_XX.ass) into per-word cues. Each Dialogue
 * line highlights exactly one word with `{\1c&H00FFFF&\fscx118\fscy118}word{\r}`.
 * Falls back to whole-line cues when no highlighted word is found.
 */
export function parseAssFileToWordCues(assText: string): WordCue[] {
  const words: WordCue[] = [];
  for (const line of assText.split(/\r?\n/)) {
    if (!line.startsWith('Dialogue:')) continue;
    const fields = line.split(',');
    // Dialogue: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
    if (fields.length < 10) continue;
    const start = assTimeToSeconds(fields[1]?.trim() ?? '');
    const end = assTimeToSeconds(fields[2]?.trim() ?? '');
    const text = fields.slice(9).join(',');
    const match = text.match(/\{[^}]*\\1c&H00FFFF&[^}]*\}([^{}]+)\{\\r\}/);
    const word = (match?.[1] ?? text.replace(/\{[^}]*\}/g, '')).trim();
    if (!word || Number.isNaN(start) || Number.isNaN(end)) continue;
    words.push({ start, end, text: word });
  }
  return words;
}

export function assTimeToSeconds(t: string): number {
  const m = t.match(/^(?:(\d+):)?(\d{1,2}):(\d{1,2})\.(\d{1,2})$/);
  if (!m) return Number.NaN;
  const h = Number(m[1] ?? 0);
  const min = Number(m[2]);
  const sec = Number(m[3]);
  const cs = Number(m[4]);
  return h * 3600 + min * 60 + sec + cs / 100;
}

/** Group consecutive word cues into 3-word CaptionCue groups (v7's grouping). */
export function groupWordCuesToCaptions(words: WordCue[]): CaptionCue[] {
  const cues: CaptionCue[] = [];
  let current: WordCue[] = [];
  const flush = () => {
    if (current.length === 0) return;
    cues.push({
      start: current[0].start,
      end: current[current.length - 1].end,
      text: current.map((w) => w.text).join(' '),
    });
    current = [];
  };
  for (const w of words) {
    if (current.length > 0 && (current.length >= 3 || w.start - current[current.length - 1].end > 0.7)) flush();
    current.push(w);
  }
  flush();
  return cues;
}

/**
 * Map a v7 verified moment's flat sub-scores (reaction/30, cause/20,
 * story/15, chat/15, quotable/10, technical/10) onto the app's 8-factor
 * ScoreBreakdown (each 0-100). `overallScore` stays the v7 total — the
 * verified /100.
 */
export function mapSubScores(m: Pick<VerifiedMoment, 'reaction' | 'cause' | 'story' | 'chat' | 'quotable' | 'technical'> | undefined): {
  hookStrength: number;
  contextCompleteness: number;
  emotionalIntensity: number;
  valueScore: number;
  visualInterest: number;
  audioInterest: number;
  standaloneQuality: number;
  retentionPotential: number;
} {
  const s = (v: number | undefined, max: number) => Math.max(0, Math.min(100, Math.round(((v ?? 0) / max) * 100)));
  return {
    hookStrength: s(m?.quotable, 10),
    contextCompleteness: s(m?.story, 15),
    emotionalIntensity: s(m?.reaction, 30),
    valueScore: s(m?.cause, 20),
    visualInterest: s(m?.cause, 20),
    audioInterest: s(m?.reaction, 30),
    standaloneQuality: s(m?.story, 15),
    retentionPotential: Math.max(0, Math.min(100, Math.round((((m?.chat ?? 0) + (m?.quotable ?? 0)) / 25) * 100))),
  };
}

function describeEvidence(m: VerifiedMoment): string {
  const parts: string[] = [];
  if (m.emotion && m.emotion !== 'none') parts.push(`emotion: ${m.emotion}`);
  if (typeof m.mean_db === 'number' && typeof m.max_db === 'number') parts.push(`loudness mean ${m.mean_db.toFixed(1)} dB / max ${m.max_db.toFixed(1)} dB`);
  if (typeof m.signals === 'number') parts.push(`${m.signals} independent signals`);
  if (m.face) parts.push('face on screen');
  if (m.events?.length) parts.push(`events: ${m.events.join(', ')}`);
  if (typeof m.words === 'number') parts.push(`${m.words} words spoken`);
  if (m.quote) parts.push(`"${m.quote}"`);
  return parts.join(' · ');
}

/** Map one verified moment + its rendered file into a NormalizedClip.
 * The clip is already rendered by the Python pipeline, so outputPath /
 * outputFilename are set and the server must skip its own re-render. */
export function verifiedMomentToClip(
  m: VerifiedMoment,
  opts: {
    renderedFile: string;
    outputFilename: string;
    pre: number;
    post: number;
    videoDuration: number;
    category: ConcreteCategoryId;
    captionLanguage: string;
    captionStyle: CaptionStyleId;
    faceCrop: [number, number, number, number] | null;
    captions: CaptionCue[];
    wordCues: WordCue[];
    segmentPath?: string;
    segmentStart?: number;
    index: number;
  },
): NormalizedClip {
  const startTime = Math.max(0, m.t - opts.pre);
  const endTime = Math.min(opts.videoDuration || m.t + opts.post, m.t + opts.post);
  const total = typeof m.score === 'number' ? m.score : 0;
  return {
    id: `local-${opts.index}-${Math.round(m.t)}`,
    index: opts.index,
    title: m.title || m.quote || `Moment at ${Math.round(m.t)}s`,
    startTime,
    endTime,
    duration: endTime - startTime,
    detectedCategory: opts.category,
    reason: describeEvidence(m),
    layoutMode: opts.faceCrop ? 'split_cam_gameplay' : 'full_frame',
    webcamPosition: mapFaceCropToCorner(opts.faceCrop),
    aspectRatio: '9:16', // the local engine renders 9:16 Shorts; the editor can re-render other ratios
    captionStyle: opts.captionStyle,
    captionLanguage: opts.captionLanguage,
    scores: mapSubScores(m),
    overallScore: total,
    captions: opts.captions,
    wordCues: opts.wordCues,
    renderUrl: `/api/media/clips/${encodeURIComponent(opts.outputFilename)}`,
    outputPath: opts.renderedFile,
    outputFilename: opts.outputFilename,
    segmentPath: opts.segmentPath,
    segmentStart: opts.segmentStart,
    renderedAt: new Date().toISOString(),
  };
}

function parseProgressLine(line: string, req: LocalAnalyzeRequest, totalClips: number): { stage: string; progress: number } | null {
  const m = line.match(/^\[(\d)\/5\]/);
  if (m) {
    const step = Number(m[1]);
    const stages: Record<number, [string, number]> = {
      1: ['Reading video info', 8],
      2: ['Finding moments', 22],
      3: ['Transcribing audio', 42],
      4: ['Verifying moments', 58],
      5: ['Rendering clips', 74],
    };
    const [stage, progress] = stages[step] ?? ['Working', 50];
    return { stage, progress };
  }
  if (/done -> short_\d+\.mp4/.test(line)) {
    const n = Number(line.match(/short_(\d+)\.mp4/)?.[1] ?? 0);
    return { stage: `Rendered clip ${n} of ${totalClips}`, progress: 74 + Math.min(24, Math.round((n / Math.max(1, totalClips)) * 24)) };
  }
  if (/^Finished\./.test(line)) return { stage: 'Finishing', progress: 99 };
  return null;
}

/**
 * Run the local engine end to end: detect + verify + render. Returns the same
 * AnalyzeVideoResult shape as the Gemini analyzer so the UI needs no changes.
 */
export async function analyzeVideoLocal(req: LocalAnalyzeRequest): Promise<AnalyzeVideoResult> {
  const { python } = await resolvePython();
  await ensureMediaDirs();
  const { pre, post } = presetToWindow(req.durationPreset);
  const jobDir = join(WORK_ROOT, 'jobs', req.jobTag);
  await mkdir(jobDir, { recursive: true });

  const lang = mapCaptionLanguage(req.captionLanguage);
  const faceArg = req.webcamPreference ? webcamCornerToCrop(req.webcamPreference) : 'auto';
  const args = [
    CLIP_STREAM,
    req.videoPath,
    '--out', jobDir,
    '--count', String(Math.max(1, Math.min(10, req.numberOfClips))),
    '--face', faceArg,
    '--pre', String(pre),
    '--post', String(post),
    '--whisper-model', resolveWhisperModel(),
    '--title-position', 'top',
    '--max-height', '720',
    '--keep-temp',
  ];
  if (lang) args.push('--lang', lang);

  req.onProgress?.('Starting local engine', 4);
  await new Promise<void>((resolvePromise, rejectPromise) => {
    const child = spawn(python, args, { cwd: PROJECT_ROOT });
    let stderrTail = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      rejectPromise(new LocalEngineError('ENGINE_TIMEOUT', 'Local clipping took longer than 25 minutes and was stopped. Try a shorter video or fewer clips.'));
    }, LOCAL_ENGINE_TIMEOUT_MS);
    child.stdout.on('data', (chunk: Buffer) => {
      for (const line of String(chunk).split(/\r?\n/)) {
        const p = parseProgressLine(line.trim(), req, req.numberOfClips);
        if (p) req.onProgress?.(p.stage, p.progress);
      }
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderrTail = (stderrTail + String(chunk)).slice(-4000);
    });
    child.on('error', (err) => {
      clearTimeout(timer);
      rejectPromise(new LocalEngineError('ENGINE_SPAWN_FAILED', `Could not start the local clipping engine (Python): ${err.message}`));
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolvePromise();
      else {
        const hint = /yt-dlp|Bot|HTTP Error 4\d\d|Sign in to confirm/i.test(stderrTail)
          ? ' YouTube may be blocking downloads from this server (bot check). Wait 1–2 hours, or upload the video file instead.'
          : '';
        rejectPromise(new LocalEngineError('ENGINE_FAILED', `Local clipping engine failed (exit ${code}).${hint} Details: ${stderrTail.trim().slice(-1500) || 'no output'}`));
      }
    });
  });

  const readJson = async <T>(name: string): Promise<T | null> => {
    try {
      return JSON.parse(await readFile(join(jobDir, name), 'utf-8')) as T;
    } catch {
      return null;
    }
  };
  const verified = await readJson<{ kept: VerifiedMoment[]; rejected: unknown[] }>('verified.json');
  const state = await readJson<StateFile>('state.json');
  const kept = (verified?.kept ?? []).slice().sort((a, b) => (b.score ?? 0) - (a.score ?? 0)).slice(0, req.numberOfClips);
  const faceCrop = state?.face ?? null;

  const clips: NormalizedClip[] = [];
  // Render order is moments sorted by t; cap/seg files are indexed in that order.
  const byTime = [...kept].sort((a, b) => a.t - b.t);
  for (const m of kept) {
    const renderIndex = byTime.indexOf(m); // 0-based; files are 1-based
    const rendered = state?.rendered?.find((r) => Math.abs(r.t - m.t) < 1.5);
    if (!rendered) continue;
    const renderedPath = join(jobDir, rendered.file);
    if (!existsSync(renderedPath)) continue;
    const outputFilename = `${req.jobTag}-${basename(rendered.file)}`;
    const outputPath = join(CLIPS_DIR, outputFilename);
    await copyFile(renderedPath, outputPath);

    // Captions from the karaoke ASS written for this render (kept by --keep-temp).
    let wordCues: WordCue[] = [];
    try {
      const assName = `cap_${String(renderIndex + 1).padStart(2, '0')}.ass`;
      const assText = await readFile(join(jobDir, '_work', assName), 'utf-8');
      wordCues = parseAssFileToWordCues(assText);
    } catch {
      wordCues = [];
    }
    const captions = groupWordCuesToCaptions(wordCues);

    // The downloaded segment (YouTube) for editor re-renders.
    let segmentPath: string | undefined;
    let segmentStart: number | undefined;
    try {
      const segName = `seg_${String(renderIndex + 1).padStart(2, '0')}.mp4`;
      const segPath = join(jobDir, '_work', segName);
      if (existsSync(segPath)) {
        const st = await stat(segPath);
        if (st.size > 0) {
          segmentPath = segPath;
          segmentStart = Math.max(0, m.t - pre);
        }
      }
    } catch {
      // re-render falls back to the source URL/file
    }

    clips.push(verifiedMomentToClip(m, {
      renderedFile: outputPath,
      outputFilename,
      pre,
      post,
      videoDuration: req.videoDuration,
      category: req.selectedCategory === 'auto' ? 'other' : req.selectedCategory,
      captionLanguage: req.captionLanguage,
      captionStyle: req.captionStyle,
      faceCrop,
      captions,
      wordCues,
      segmentPath,
      segmentStart,
      index: kept.indexOf(m),
    }));
  }

  const summary = kept.length === 0
    ? 'Local engine checked the video and no moment passed verification (score 70+ with at least two independent signals: loudness, transcript markers, chat, or a quotable line). Try a busier section of the video, or a different video.'
    : `Local engine (yt-dlp + faster-whisper) analyzed the full video, scored candidate moments out of 100 with a two-signal evidence rule, and kept the ${clips.length} strongest. ` +
      (req.aspectRatio !== '9:16' ? 'Auto-clips are rendered 9:16 (Shorts); use the clip editor to re-render a different ratio. ' : '') +
      'No API key was needed.';
  const reasoning = kept.length === 0
    ? 'Verification rejected every candidate. The local engine does not guess: a moment must score 70+ and show at least two signals (loudness spike, transcript markers, chat burst, quotable line, clear speech).'
    : `Moments were detected from loudness spikes and transcript markers across the full timeline, then verified against the /100 rubric. Category is set to your selection${req.selectedCategory === 'auto' ? ' (auto → other; add a Gemini key with KLIPZ_USE_GEMINI=1 for automatic category detection)' : ''}.`;

  const category: ConcreteCategoryId = req.selectedCategory === 'auto' ? 'other' : req.selectedCategory;
  return {
    primaryCategory: category,
    secondaryCategories: [],
    categoryConfidence: 70,
    categoryReasoning: reasoning,
    contentSummary: summary,
    detectedWebcamPosition: mapFaceCropToCorner(faceCrop),
    clips,
  };
}
