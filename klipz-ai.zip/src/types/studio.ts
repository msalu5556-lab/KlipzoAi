import type {
  AspectRatio,
  CaptionStyleId,
  ClipDurationPreset,
  ConcreteCategoryId,
  DetectedWebcamPosition,
  LayoutPreference,
  NormalizedClip,
  VideoCategoryId,
  WebcamPosition,
} from '../lib/clipEngine';

export interface VideoProbe {
  duration: number;
  width: number;
  height: number;
  fps: number;
  hasAudio: boolean;
  codec: string;
  sizeBytes: number;
}

export interface UploadedVideoInfo {
  videoId: string;
  filename: string;
  originalName: string;
  mimeType: string;
  previewUrl: string;
  probe: VideoProbe;
  isSample: boolean;
  sourceType?: 'upload' | 'sample' | 'youtube';
  youtubeId?: string;
  youtubeUrl?: string;
  youtubeChannel?: string;
  thumbnailUrl?: string;
  isLive?: boolean;
  streamAvailable?: boolean;
  streamWarning?: string;
  usedYouTubeDataApi?: boolean;
  transcriptCuesCount?: number;
  heatmapPeaksCount?: number;
}

export interface AutoClipSettings {
  autoDetectCategory: boolean;
  selectedCategory: VideoCategoryId;
  autoDetectBestClips: boolean;
  numberOfClips: number;
  durationPreset: ClipDurationPreset;
  aspectRatio: AspectRatio;
  captionLanguage: string;
  captionStyle: CaptionStyleId;
  layoutPreference: LayoutPreference;
  webcamPreference: WebcamPosition;
}

export interface AnalysisResponse {
  primaryCategory: ConcreteCategoryId;
  primaryCategoryLabel: string;
  secondaryCategories: ConcreteCategoryId[];
  categoryConfidence: number;
  categoryReasoning: string;
  contentSummary: string;
  detectedWebcamPosition?: DetectedWebcamPosition;
  streamWarning?: string;
  clips: NormalizedClip[];
}

export type ActiveTab = 'workspace' | 'library' | 'categories';
